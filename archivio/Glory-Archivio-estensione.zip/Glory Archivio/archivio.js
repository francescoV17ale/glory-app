
"use strict";
/* Archivio dei rapportini arrivati dall'app Glory 2.0 ("Archivio per il PC").
   I dati restano su questo PC: nel browser (IndexedDB) e, se collegata, in una cartella (un file per lavoro). */
var DB=null,L=[],SEL=null,F={q:"",v:"",t:""},DIR=null;
var TIT={inst:"Installazione",prep:"Preparazione",rip:"Riparazione",loc:"In loco",altro:"Altra attività",rit:"Ritiro"};
var PX={"CI-5":"50","CI-10":"100","CI-10X":"200"};
function $(i){return document.getElementById(i)}
function el(t,c,x){var e=document.createElement(t);if(c)e.className=c;if(x!=null)e.textContent=x;return e}
function btn(c,x,fn){var b=el("button",c,x);b.type="button";b.onclick=fn;return b}
function p2(n){return n<10?"0"+n:""+n}
function dIt(t){var d=new Date(t);return p2(d.getDate())+"/"+p2(d.getMonth()+1)+"/"+d.getFullYear()}
function dLav(r){var m=/^(\d{4})-(\d\d)-(\d\d)$/.exec((r.s&&r.s.dt)||"");return m?m[3]+"/"+m[2]+"/"+m[1]:dIt(r.d)}
function tLav(r){var m=/^(\d{4})-(\d\d)-(\d\d)$/.exec((r.s&&r.s.dt)||"");return m?new Date(+m[1],+m[2]-1,+m[3]).getTime():r.d}
function g(s,k){return String(s[k]==null?"":s[k]).trim()}
function say(t,ko){var m=$("msg");m.textContent=t;m.className="msg"+(ko?" ko":"");m.hidden=!t;clearTimeout(say.t);if(t)say.t=setTimeout(function(){m.hidden=true},9000)}

/* ---------- matricole e codici impianto di un lavoro ---------- */
function mats(r){var s=r.s||{},o=[],i,v=r.v;
 function add(k,pre,n){n=String(n||"").trim();if(n)o.push({k:k,v:(pre||"")+n,n:n})}
 function dev(n){for(i=1;i<=n;i++){var px=PX[s["m"+i]]||"";add("Banconote","RBW"+px+"-",s["a"+i]);add("Monete","RCW"+px+"-",s["c"+i]);add("Impianto","",s["mt"+i])}}
 if(v==="inst"||v==="rit")dev(+s.n||(s.m1||s.a1||s.c1?1:0));
 else if(v==="rip"){for(i=1;i<=(+s.rn||1);i++){var p="r"+i+"_",t=s[p+"tp"]==="Banconote"?"B":s[p+"tp"]==="Monete"?"C":"",px=PX[s[p+"md"]]||"";add(t==="B"?"Banconote":t==="C"?"Monete":"Modulo",t&&px?"R"+t+"W"+px+"-":"",s[p+"mat"])}}
 else if(v==="loc"){var q=PX[s.md]||"";add("Banconote",q?"RBW"+q+"-":"",s.r1_mat);add("Monete",q?"RCW"+q+"-":"",s.r2_mat);add("Impianto","",s.mt)}
 else if(v==="prep"){var z=PX[s.m]||"50";add("Banconote","RBW"+z+"-",s.mtB);add("Monete","RCW"+z+"-",s.mtM);for(i=2;i<=(+s.dn||1);i++)add("Monete","RCW50-",s["mtM"+i]);add("Impianto","",s.mtD)}
 else add("Matricola","",s.ma);
 return o}
function cliente(r){var s=r.s||{};return g(s,"cl")||g(s,"rvn")}
function rif(r){var s=r.s||{},o=[];if(g(s,"rma"))o.push("RMA "+g(s,"rma"));if(g(s,"cv"))o.push("CV "+g(s,"cv"));if(g(s,"cvc"))o.push("CV "+g(s,"cvc"));if(g(s,"rf"))o.push(g(s,"rf"));if(g(s,"rc"))o.push((s.rf||"")+" "+g(s,"rc"));return o.join(" · ")}
function testo(r){var s=r.s||{};return [r.n,r.tec,TIT[r.v],cliente(r),g(s,"rvn"),g(s,"se"),rif(r),r.nt].concat(mats(r).map(function(m){return m.v+" "+m.n})).join(" ").toLowerCase()}

/* ---------- archivio locale (IndexedDB) ---------- */
function dbOpen(){return new Promise(function(ok,ko){var q=indexedDB.open("glory_pc",1);q.onupgradeneeded=function(){var d=q.result;d.createObjectStore("lav",{keyPath:"u"});d.createObjectStore("cfg")};q.onsuccess=function(){DB=q.result;ok()};q.onerror=function(){ko(q.error)}})}
function dbAll(){return new Promise(function(ok){var t=DB.transaction("lav").objectStore("lav").getAll();t.onsuccess=function(){ok(t.result||[])};t.onerror=function(){ok([])}})}
function dbPut(arr){return new Promise(function(ok,ko){if(!arr.length){ok();return}var t=DB.transaction("lav","readwrite"),st=t.objectStore("lav");arr.forEach(function(r){st.put(r)});t.oncomplete=ok;t.onerror=t.onabort=function(){ko(t.error)}})}
function cfg(k,v){return new Promise(function(ok){var t=DB.transaction("cfg",v===undefined?"readonly":"readwrite"),st=t.objectStore("cfg"),q=v===undefined?st.get(k):st.put(v,k);q.onsuccess=function(){ok(q.result)};q.onerror=function(){ok(null)}})}

/* ---------- cartella sul PC (Chrome/Edge): un file .json per lavoro ---------- */
var FSA=!!window.showDirectoryPicker;
function dirLabel(){var b=$("dirb");if(!FSA){b.hidden=true;return}b.hidden=false;b.textContent=DIR?(DIR.ok?"Cartella: "+DIR.h.name:"Riapri la cartella "+DIR.h.name):"Collega una cartella";$("sync").hidden=!(DIR&&DIR.ok)}
function dirPick(){if(DIR&&!DIR.ok){DIR.h.requestPermission({mode:"readwrite"}).then(function(p){if(p==="granted"){DIR.ok=1;dirSync()}dirLabel()});return}
 window.showDirectoryPicker({mode:"readwrite",id:"glory-archivio"}).then(function(h){DIR={h:h,ok:1};SEEN={};cfg("seen",SEEN);cfg("dir",h);dirSync();dirLabel()},function(){})}
function dirInit(){if(!FSA)return Promise.resolve();return cfg("seen").then(function(x){SEEN=x||{}}).then(function(){return cfg("dir")}).then(function(h){if(!h)return;DIR={h:h,ok:0};return h.queryPermission({mode:"readwrite"}).then(function(p){if(p==="granted"){DIR.ok=1;return dirSync()}})}).catch(function(){})}
/* nella cartella (anche una cartella condivisa di Google Drive):
   - i file "Archivio Glory …" che arrivano dai tecnici vengono importati da soli
   - in _archivio ogni PC scrive solo il suo file _team-<codice>.json (etichette e commenti di squadra)
   - le copie dei lavori in _archivio (versione precedente) vengono ancora lette, non più scritte */
var SUB="_archivio",SEEN={};
function subDir(){return DIR.h.getDirectoryHandle(SUB,{create:true})}
function dirWrite(arr){if(!DIR||!DIR.ok||!arr.length)return Promise.resolve();
 return subDir().then(function(sd){return arr.reduce(function(pr,r){return pr.then(function(){return sd.getFileHandle(fnSafe(r.u)+".json",{create:true}).then(function(fh){return fh.createWritable()}).then(function(w){return w.write(JSON.stringify(r)).then(function(){return w.close()})})})},Promise.resolve())}).catch(function(){say("Non riesco a scrivere nella cartella: ricollegala.",1)})}
function fnSafe(t){return String(t).replace(/[^A-Za-z0-9_-]/g,"_")}
var syncing=0;
function dirSync(){if(!DIR||!DIR.ok||syncing)return Promise.resolve();syncing=1;var got={},inc=[],nf=0,tms=[],mtOld=null;
 return (async function(){
  for await (var e of DIR.h.values()){if(e.kind!=="file"||!/\.(txt|json)$/i.test(e.name))continue;
   var f=await e.getFile(),key=e.name+"|"+f.size+"|"+f.lastModified;if(SEEN[key])continue;
   var o=null;try{o=JSON.parse(await f.text())}catch(x){}SEEN[key]=1;
   if(o&&o.u&&o.s&&o.v){got[o.u]=o;continue}            /* copia di un lavoro lasciata nella cartella principale (versione precedente) */
   var A=o?norm(o):[];if(A.length){nf++;inc=inc.concat(A)}}
  try{var imd=await DIR.h.getDirectoryHandle("_importati",{create:false});for await (var e3 of imd.values()){if(e3.kind!=="file"||!/\.(txt|json)$/i.test(e3.name))continue;var f3=await e3.getFile(),k3="_importati/"+e3.name+"|"+f3.size;if(SEEN[k3])continue;SEEN[k3]=1;try{var o3=JSON.parse(await f3.text());var A3=norm(o3);if(A3.length)inc=inc.concat(A3)}catch(x){}}}catch(x){}
  var sd=await subDir();
  for await (var e2 of sd.values()){if(e2.kind!=="file"||!/\.json$/.test(e2.name))continue;var f2=await e2.getFile(),k2=SUB+"/"+e2.name+"|"+f2.size+"|"+f2.lastModified;if(SEEN[k2])continue;SEEN[k2]=1;try{var r=JSON.parse(await f2.text());if(e2.name==="_meta.json"){mtOld=r}else if(/^_team-/.test(e2.name)){tms.push(r)}else if(r&&r.u)got[r.u]=r}catch(x){}}
 })().then(function(){
  var M={},toDb=[],nu=0,ag=0;L.forEach(function(r){M[r.u]=r});
  Object.keys(got).forEach(function(u){var r=got[u];if(!M[u]||r.d>M[u].d){toDb.push(r);M[u]=r}});
  inc.forEach(function(r){var e=M[r.u];if(!e){nu++;r.imp=Date.now();M[r.u]=r;toDb.push(r)}else if(r.d>e.d){ag++;r.imp=Date.now();M[r.u]=passa(r,e);toDb.push(r)}});
  L=Object.keys(M).map(function(u){return M[u]});
  var tch=0;tms.forEach(function(t){if(teamMerge(t))tch=1});if(mtOld&&metaToTeam(mtOld))tch=1;if(tch)cfg("team",TEAM);
  return dbPut(toDb).then(teamDir).then(pulisci).then(function(){cfg("seen",SEEN);
   if(nu||ag)say("Dalla cartella: "+nu+(nu===1?" nuovo":" nuovi")+(ag?", "+ag+(ag===1?" aggiornato":" aggiornati"):"")+".");if(nu||ag||tch||toDb.length)draw();else dirLabel()})})
 .catch(function(){say("Lettura della cartella non riuscita: ricollegala.",1)}).then(function(){syncing=0})}
/* PC principale: i file dei tecnici già importati da più di 30 giorni vanno in _importati (una volta al giorno) */
var MAIN=0,PULITO=0;
function pulisci(){if(!MAIN||!DIR||!DIR.ok||Date.now()-PULITO<864e5)return Promise.resolve();PULITO=Date.now();cfg("pulito",PULITO);var lim=Date.now()-30*864e5,n=0;
 return (async function(){var imd=await DIR.h.getDirectoryHandle("_importati",{create:true}),da=[];
  for await (var e of DIR.h.values()){if(e.kind!=="file"||!/\.(txt|json)$/i.test(e.name)||/^_/.test(e.name))continue;var f=await e.getFile();if(f.lastModified<lim&&SEEN[e.name+"|"+f.size+"|"+f.lastModified])da.push([e,f])}
  for(var i=0;i<da.length;i++){var e=da[i][0],f=da[i][1],nn=e.name;try{try{await imd.getFileHandle(nn)}catch(x){nn=nn}var w=await (await imd.getFileHandle(nn,{create:true})).createWritable();await w.write(await f.arrayBuffer());await w.close();SEEN["_importati/"+nn+"|"+f.size]=1;await DIR.h.removeEntry(e.name);n++}catch(x){}}
 })().then(function(){if(n)say(n+(n===1?" file vecchio spostato":" file vecchi spostati")+" in _importati.")}).catch(function(){})}
/* torna sulla finestra o tocca Aggiorna: rilegge la cartella */
window.addEventListener("focus",function(){if(DIR&&DIR.ok)dirSync()});

/* ---------- etichette e commenti di squadra ----------
   Ogni PC scrive solo il suo file _archivio/_team-<codice PC>.json e legge quelli degli altri:
   nessuno sovrascrive il lavoro di un collega. Per ogni voce vince la modifica più recente. */
var COL=["#c23b22","#d97706","#ca8a04","#1f7a4d","#0f766e","#1f5f99","#6d28d9","#be185d","#5b6770"];
var TEAM={defs:{},tg:{},cm:{},hid:{}},PCID="",NOME="";
function teamFix(t){t=t&&typeof t==="object"?t:{};function o(k){return t[k]&&typeof t[k]==="object"?t[k]:{}}return {defs:o("defs"),tg:o("tg"),cm:o("cm"),hid:o("hid")}}
function teamDef(){var n=["Da fatturare","Garanzia","Cliente critico","Da richiamare","Ricambio in ordine","Macchina problematica"],c=[1,5,0,2,6,7],d={};
 n.forEach(function(x,i){d["t"+(i+1)]={n:x,c:COL[c[i]],o:i,ts:0}});return {defs:d,tg:{},cm:{},hid:{}}}
/* unisce due stati: per ogni voce tiene quella con ts più recente; restituisce 1 se è cambiato qualcosa */
function teamMerge(o){o=teamFix(o);var ch=0;["defs","tg","cm","hid"].forEach(function(k){Object.keys(o[k]).forEach(function(id){var a=TEAM[k][id],b=o[k][id];if(b&&(!a||(+b.ts||0)>(+a.ts||0))){TEAM[k][id]=b;ch=1}})});return ch}
/* versione precedente: etichette e note personali (_meta.json / cfg "meta") diventano etichette e commenti di squadra */
function metaToTeam(m){if(!m||typeof m!=="object")return 0;var t={defs:{},tg:{},cm:{}},ts=+m.ts||1,i=0;
 (m.tags||[]).forEach(function(x){t.defs[x.id]={n:x.n,c:x.c,o:i++,ts:ts}});
 ["L","M"].forEach(function(K){Object.keys(m[K]||{}).forEach(function(k){var o=m[K][k]||{};(o.t||[]).forEach(function(id){t.tg[K+"|"+k+"|"+id]={on:1,ts:ts}});
  if(String(o.n||"").trim())t.cm["old-"+K+"-"+k]={k:K+"|"+k,a:NOME||"(nota precedente)",t:String(o.n).trim(),ts:ts}})});
 return teamMerge(t)}
var tmT=null;
function teamSave(){cfg("team",TEAM);clearTimeout(tmT);tmT=setTimeout(teamDir,800)}
function teamDir(){if(!DIR||!DIR.ok||!PCID)return Promise.resolve();return subDir().then(function(sd){return sd.getFileHandle("_team-"+PCID+".json",{create:true})}).then(function(fh){return fh.createWritable()}).then(function(w){return w.write(JSON.stringify(TEAM)).then(function(){return w.close()})}).catch(function(){})}
var PREV=0;function nuovo(r){return (+r.imp||0)>PREV}
function hid(r){var x=TEAM.hid[r.u];return !!(x&&x.on)}
function vis(){return L.filter(function(r){return !hid(r)})}
function mk(v){return String(v||"").toUpperCase().replace(/\s+/g,"")}
function tags(){return Object.keys(TEAM.defs).filter(function(id){return !TEAM.defs[id].del}).map(function(id){var d=TEAM.defs[id];return {id:id,n:d.n,c:d.c,o:+d.o||0}}).sort(function(a,b){return a.o-b.o||a.n.localeCompare(b.n)})}
function tagOf(id){var d=TEAM.defs[id];return d&&!d.del?{id:id,n:d.n,c:d.c}:null}
function hasTag(kind,k,id){var x=TEAM.tg[kind+"|"+k+"|"+id];return !!(x&&x.on)}
function tagsK(kind,k){return tags().filter(function(t){return hasTag(kind,k,t.id)}).map(function(t){return t.id})}
function tagsL(r){var o=tagsK("L",r.u);mats(r).forEach(function(m){tagsK("M",mk(m.v)).forEach(function(t){if(o.indexOf(t)<0)o.push(t)})});return o}
function comms(kind,k){var key=kind+"|"+k;return Object.keys(TEAM.cm).map(function(id){var c=TEAM.cm[id];return {id:id,k:c.k,a:c.a,t:c.t,ts:+c.ts||0,del:c.del,f:c.f}}).filter(function(c){return c.k===key&&!c.del}).sort(function(a,b){return (a.f||a.ts)-(b.f||b.ts)})}
function commTxt(r){return comms("L",r.u).map(function(c){return c.a+": "+c.t}).join(" · ")}
function tagRow(kind,k){var w=el("div","tgs"),T=tags();
 if(!T.length){w.append(el("span","st","Nessuna etichetta: creale con il tasto Etichette."));return w}
 T.forEach(function(t){var on=hasTag(kind,k,t.id),b=btn("tg"+(on?" on":""),null,function(){TEAM.tg[kind+"|"+k+"|"+t.id]={on:on?0:1,ts:Date.now(),a:NOME};teamSave();draw()});
  var d=el("i");d.style.background=t.c;b.append(d,document.createTextNode(t.n));if(on)b.style.borderColor=t.c;b.setAttribute("aria-pressed",on?"true":"false");w.append(b)});return w}
function chiediNome(ok){var n=prompt("Il tuo nome (compare sui commenti che scrivi):",NOME||"");if(n==null)return;n=n.trim();if(!n){alert("Il nome è obbligatorio per commentare.");return}NOME=n;cfg("nome",NOME);nomeLab();if(ok)ok()}
function nomeLab(){var b=$("setb");if(b)b.textContent=NOME?"⚙ "+NOME:"⚙ Impostazioni"}
function impostazioni(){var ov=el("div","ov"),d=el("div","dlg");ov.setAttribute("role","dialog");ov.setAttribute("aria-modal","true");function close(){ov.remove();draw()}ov.onclick=function(e){if(e.target===ov)close()};
 d.append(el("h2",0,"Impostazioni"));var r1=el("div","er"),inp=document.createElement("input");inp.type="text";inp.value=NOME;inp.placeholder="Nome e cognome";inp.setAttribute("aria-label","Il tuo nome");
 inp.onchange=function(){var v=inp.value.trim();if(v){NOME=v;cfg("nome",NOME);nomeLab()}};r1.append(el("b",0,"Il tuo nome"),inp);d.append(r1,el("p","st","Compare sui commenti che scrivi. Obbligatorio per commentare."));
 var lb=el("label","er"),cb=document.createElement("input");cb.type="checkbox";cb.checked=!!MAIN;cb.onchange=function(){MAIN=cb.checked?1:0;cfg("main",MAIN);PULITO=0};lb.append(cb,document.createTextNode(" PC principale: sposta in «_importati» i file dei tecnici già importati da più di 30 giorni"));d.append(lb,el("p","st","Attivalo su un solo PC."));
 if(location.protocol!=="chrome-extension:"){var a=el("a","b sm","Scarica l'estensione Chrome");a.href="Glory-Archivio-estensione.zip";a.setAttribute("download","");d.append(a)}
 else d.append(el("p","st","Estensione versione "+chrome.runtime.getManifest().version));
 var row=el("div","er");row.style.marginTop="12px";row.append(btn("b ac","Chiudi",close));d.append(row);ov.append(d);document.body.append(ov);inp.focus()}
function dataOra(t){var d=new Date(t);return dIt(t)+" "+p2(d.getHours())+":"+p2(d.getMinutes())}
function commBox(kind,k){var w=el("div","cms"),C=comms(kind,k);
 C.forEach(function(c){var it=el("div","cm"),h=el("div","cmh");h.append(el("b",0,c.a),el("span",0,dataOra(c.f||c.ts)));
  if(c.a===NOME){var x=btn("cmx","Elimina",function(){if(!confirm("Eliminare questo commento?"))return;var o=TEAM.cm[c.id];o.del=1;o.ts=Date.now();teamSave();draw()});h.append(x)}
  it.append(h,el("div","cmt",c.t));w.append(it)});
 var ta=el("textarea","mynote");ta.placeholder="Scrivi un commento…";ta.setAttribute("aria-label","Nuovo commento");
 var add=btn("b sm ac","Aggiungi commento",function(){var t=ta.value.trim();if(!t){ta.focus();return}
  function go(){var now=Date.now(),id=(PCID||"pc")+"-"+now.toString(36);TEAM.cm[id]={k:kind+"|"+k,a:NOME,t:t,ts:now,f:now};teamSave();draw()}
  if(!NOME)chiediNome(go);else go()});
 w.append(ta,add,el("span","st",NOME?" come "+NOME:" ti chiederà il nome"));return w}

/* ---------- editor delle etichette (di squadra) ---------- */
function tagEditor(){var ov=el("div","ov"),d=el("div","dlg");ov.setAttribute("role","dialog");ov.setAttribute("aria-modal","true");
 function close(){ov.remove();draw()}
 ov.onclick=function(e){if(e.target===ov)close()};
 function upd(id,ch){var o=TEAM.defs[id];Object.keys(ch).forEach(function(k){o[k]=ch[k]});o.ts=Date.now();teamSave()}
 function body(){d.textContent="";d.append(el("h2",0,"Etichette"),el("p","st","Valgono per tutta la squadra: le vedono tutti i PC collegati alla cartella."));
  tags().forEach(function(t){var r=el("div","er"),inp=document.createElement("input"),sel=document.createElement("select"),dot=el("span","dot");
   inp.type="text";inp.value=t.n;inp.setAttribute("aria-label","Nome etichetta");inp.onchange=function(){if(inp.value.trim())upd(t.id,{n:inp.value.trim()})};
   dot.style.background=t.c;COL.forEach(function(c,j){var op=new Option("Colore "+(j+1),c);op.style.background=c;op.style.color="#fff";if(c===t.c)op.selected=true;sel.append(op)});sel.style.background=t.c;sel.style.color="#fff";sel.setAttribute("aria-label","Colore");
   sel.onchange=function(){upd(t.id,{c:sel.value});sel.style.background=sel.value;dot.style.background=sel.value};
   var x=btn("x","✕",function(){if(!confirm("Eliminare l'etichetta «"+t.n+"» per tutta la squadra?"))return;upd(t.id,{del:1});body()});x.setAttribute("aria-label","Elimina "+t.n);
   r.append(dot,inp,sel,x);d.append(r)});
  var row=el("div","er");row.style.marginTop="12px";row.append(btn("b ac","+ Nuova etichetta",function(){var id="t"+(PCID||"")+Date.now().toString(36);TEAM.defs[id]={n:"Nuova etichetta",c:COL[tags().length%COL.length],o:tags().length,ts:Date.now()};teamSave();body();var ii=d.querySelectorAll("input[type=text]");if(ii.length){ii[ii.length-1].focus();ii[ii.length-1].select()}}),btn("b","Chiudi",close));d.append(row)}
 body();ov.append(d);document.body.append(ov)}

/* ---------- importazione: solo lavori nuovi o aggiornati ---------- */
function readFile(f){return new Promise(function(ok){var rd=new FileReader();rd.onload=function(){ok(String(rd.result||""))};rd.onerror=function(){ok("")};rd.readAsText(f)})}
function tecL(r){var t=(r.s&&Array.isArray(r.s._tp)?r.s._tp:[]).concat(r.tp||[]).filter(function(x){return x&&x!==r.tec}),u=[];t.forEach(function(x){if(u.indexOf(x)<0)u.push(x)});return r.tec?u.concat(r.tec):u}
function passa(r,e){if(e&&e.tec&&e.tec!==r.tec){var t=(e.tp||[]).concat(r.tp||[],[e.tec]);r.tp=t.filter(function(x,i){return x!==r.tec&&t.indexOf(x)===i})}return r}
function norm(o){var arr=[],dev=o.dev||"bk";
 if(o&&o.glory===2&&Array.isArray(o.arc))o.arc.forEach(function(r){if(!r||!r.v||!r.s)return;var x=JSON.parse(JSON.stringify(r));x.u=x.u||dev+"-"+(g(x.s,"tec")||"x")+"-"+x.id;x.tec=x.tec||g(x.s,"tec")||o.tec||"";x.d=+x.d||Date.now();x.sent=+o.saved||x.d;delete x.xd;arr.push(x)});
 if(o&&o.gloryPc===1&&Array.isArray(o.lav))o.lav.forEach(function(r){if(r&&r.u&&r.v&&r.s)arr.push(r)});
 return arr}
function importa(files){var M={},nu=0,ag=0,ug=0,bad=0,ch=[],mt=0;L.forEach(function(r){M[r.u]=r});
 Promise.all(Array.prototype.map.call(files,readFile)).then(function(T){
  T.forEach(function(t){var o=null;try{o=JSON.parse(t)}catch(e){}var A=o?norm(o):[];
   if(o&&o.gloryPc===1&&((o.team&&teamMerge(o.team))|(o.meta&&metaToTeam(o.meta))))mt=1
   if(!A.length&&!mt){bad++;return}
   A.forEach(function(r){var e=M[r.u];if(!e){nu++;r.imp=Date.now();M[r.u]=r;ch.push(r)}else if(r.d>e.d){ag++;r.imp=Date.now();M[r.u]=passa(r,e);ch.push(r)}else ug++})});
  if(mt)teamSave();
  return dbPut(ch).then(function(){L=Object.keys(M).map(function(u){return M[u]});
   say(bad&&!nu&&!ag&&!ug&&!mt?"File non riconosciuto: usa il file inviato dall'app (Invia al PC) o un «Salva tutto».":nu+(nu===1?" nuovo, ":" nuovi, ")+ag+(ag===1?" aggiornato, ":" aggiornati, ")+ug+" già present"+(ug===1?"e":"i")+(mt?", etichette e commenti uniti":"")+(bad?", "+bad+" file non validi":"")+".",bad&&!nu&&!ag&&!ug&&!mt);
   if(ch.length&&!F.sel)F.sel=ch[0].u;draw()})}).catch(function(){say("Importazione non riuscita.",1)})}

/* ---------- stato della vista e freccia Indietro ---------- */
var F={q:"",v:"",t:"",per:"",da:"",a:"",st:"",tag:"",sel:null,frq:0,nw:0},HIST=[];
function snap(){return JSON.parse(JSON.stringify(F))}
function go(ch){HIST.push(snap());if(HIST.length>40)HIST.shift();Object.keys(ch).forEach(function(k){F[k]=ch[k]});$("q").value=F.q;draw();window.scrollTo(0,0)}
function back(){if(!HIST.length)return;F=HIST.pop();$("q").value=F.q;draw()}
function apri(m){go({q:m,v:"",frq:0,sel:null})}

/* ---------- filtri ---------- */
var PER=[["","Sempre"],["m0","Questo mese"],["m1","Mese scorso"],["m3","Ultimi 3 mesi"],["y0","Quest'anno"],["x","Da… a…"]];
function range(){var n=new Date(),y=n.getFullYear(),m=n.getMonth();
 if(F.per==="m0")return [new Date(y,m,1).getTime(),Infinity];if(F.per==="m1")return [new Date(y,m-1,1).getTime(),new Date(y,m,1).getTime()];
 if(F.per==="m3")return [new Date(y,m-2,1).getTime(),Infinity];if(F.per==="y0")return [new Date(y,0,1).getTime(),Infinity];
 if(F.per==="x"){var a=F.da?new Date(F.da+"T00:00").getTime():-Infinity,b=F.a?new Date(F.a+"T00:00").getTime()+864e5:Infinity;return [a,b]}return null}
function stato(r){return (!r.st||r.st==="fatto")?"fatto":r.st}
function filtrati(){var q=F.q.toLowerCase().trim(),W=q.split(/\s+/).filter(Boolean),R=range();
 return (F.st==="del"?L.filter(hid):vis()).filter(function(r){if(F.nw&&!nuovo(r))return false;if(F.v&&r.v!==F.v)return false;if(F.t&&r.tec!==F.t)return false;if(F.st&&F.st!=="del"&&stato(r)!==F.st)return false;
  if(R){var t=tLav(r);if(t<R[0]||t>=R[1])return false}
  if(F.tag&&tagsL(r).indexOf(F.tag)<0)return false;
  if(!W.length)return true;var t2=testo(r)+" "+commTxt(r).toLowerCase();return W.every(function(w){return t2.indexOf(w)>=0})}).sort(function(a,b){return tLav(b)-tLav(a)||b.d-a.d})}
function matStoria(){var q=mk(F.q);if(q.length<3)return null;var hit=null;
 vis().some(function(r){return mats(r).some(function(m){if(mk(m.v)===q||mk(m.n)===q){hit=m;return true}})});return hit}

/* ---------- scheda macchina ---------- */
function macchina(h){var K=mk(h.v),Rs=vis().filter(function(r){return mats(r).some(function(m){return mk(m.v)===K})}).sort(function(a,b){return tLav(a)-tLav(b)}),
 part={},mod="",cli="",se="",ins=null,rit=null,int=[];
 Rs.forEach(function(r){var s=r.s||{},i,n;
  if(r.v==="inst"||r.v==="rit"){n=+s.n||1;for(i=1;i<=n;i++){var px=PX[s["m"+i]]||"",S=["RBW"+px+"-"+g(s,"a"+i),"RCW"+px+"-"+g(s,"c"+i),g(s,"mt"+i)];if(S.some(function(x){return mk(x)===K})){mod=s["m"+i]||mod;S.forEach(function(x){if(x&&!/-$/.test(x)&&mk(x)!==K)part[x]=1})}}}
  if(r.v==="loc"){mod=s.md||mod;mats(r).forEach(function(m){if(mk(m.v)!==K)part[m.v]=1})}
  if(r.v==="rip"){mod=s.r1_md||mod;if(s.rva)mats(r).forEach(function(m){if(mk(m.v)!==K)part[m.v]=1})}
  if(r.v==="inst")ins=r;if(r.v==="rit")rit=r;if(r.v==="loc"||r.v==="rip")int.push(r);
  if(cliente(r))cli=cliente(r);if(g(s,"se"))se=g(s,"se")});
 if(!mod){var m=/^R[BC]W(50|100|200)-/.exec(h.v);if(m)mod={"50":"CI-5","100":"CI-10","200":"CI-10X"}[m[1]]}
 var bx=el("div","mac");bx.append(el("div","st",h.k==="Impianto"?"Codice impianto":"Matricola "+h.k.toLowerCase()),el("h2",0,h.v),el("div",0,[mod?"Glory "+mod:"",cli,se].filter(Boolean).join(" · ")));
 var st=el("div","stats");function S(l,v){var d=el("div");d.append(el("b",0,v),document.createTextNode(l));st.append(d)}
 S("installazione",ins?dLav(ins):"—");S("interventi",String(int.length));S("ultimo intervento",int.length?dLav(int[int.length-1]):"—");if(rit)S("ritiro"+(rit.s&&rit.s.mo?" · "+rit.s.mo.toLowerCase():""),dLav(rit));bx.append(st);
 var P=Object.keys(part);if(P.length){bx.append(el("h3",0,"Stessa macchina"));var w=el("div","mats");P.forEach(function(x){w.append(btn("mat",x,function(){apri(x)}))});bx.append(w)}
 bx.append(el("h3",0,"Etichette della macchina"),tagRow("M",K),el("h3",0,"Commenti sulla macchina"),commBox("M",K));
 return bx}

/* ---------- macchine con più interventi (ultimi 6 mesi) ---------- */
function frequenti(){var lim=Date.now()-183*864e5,C={};
 vis().forEach(function(r){if((r.v!=="loc"&&r.v!=="rip")||tLav(r)<lim)return;var seen={};mats(r).forEach(function(m){if(m.k==="Impianto")return;var k=mk(m.v);if(seen[k])return;seen[k]=1;var c=C[k]||(C[k]={v:m.v,n:0,cl:"",last:0});c.n++;if(tLav(r)>c.last){c.last=tLav(r);c.cl=cliente(r)}})});
 return Object.keys(C).map(function(k){return C[k]}).filter(function(c){return c.n>=2}).sort(function(a,b){return b.n-a.n||b.last-a.last})}

/* ---------- disegno ---------- */
function draw(){
 var bk=$("bk");bk.textContent="";if(HIST.length)bk.append(btn("back","‹ Indietro",back));
 var LV=vis(),NW=LV.filter(nuovo).length;
 var fl=$("fl");fl.textContent="";if(NW||F.nw)fl.append(btn("ch nwc"+(F.nw?" on":""),"Nuovi "+NW,function(){go({nw:F.nw?0:1,frq:0})}));
 [["","Tutti"]].concat(Object.keys(TIT).map(function(k){return [k,TIT[k]]})).forEach(function(o){var n=o[0]?LV.filter(function(r){return r.v===o[0]}).length:LV.length;if(o[0]&&!n)return;fl.append(btn("ch"+(F.v===o[0]&&!F.frq?" on":""),o[1]+" "+n,function(){go({v:o[0],frq:0})}))});
 fl.append(btn("ch frq"+(F.frq?" on":""),"Macchine con più interventi",function(){go({frq:F.frq?0:1,sel:null})}));
 var fr=$("fr");fr.textContent="";
 function sel(lab,opts,val,fn){var se=el("select","sel");se.setAttribute("aria-label",lab);opts.forEach(function(o){var op=new Option(o[1],o[0]);if(o[0]===val)op.selected=true;se.append(op)});se.onchange=function(){fn(se.value)};fr.append(se)}
 sel("Periodo",PER,F.per,function(v){go({per:v})});
 if(F.per==="x"){[["da","Dal"],["a","Al"]].forEach(function(x){var i=document.createElement("input");i.type="date";i.value=F[x[0]];i.setAttribute("aria-label",x[1]);i.onchange=function(){F[x[0]]=i.value;draw()};fr.append(i)})}
 sel("Stato",[["","Tutti gli stati"],["fatto","Conclusi"],["corso","In corso"],["attesa","In attesa"]].concat(L.some(hid)?[["del","Eliminati"]]:[]),F.st,function(v){go({st:v})});
 if(tags().length)sel("Etichetta",[["","Tutte le etichette"]].concat(tags().map(function(t){return [t.id,t.n]})),F.tag,function(v){go({tag:v})});
 var tecs={};L.forEach(function(r){if(r.tec)tecs[r.tec]=1});var tk=Object.keys(tecs).sort();
 if(tk.length>1)sel("Tecnico",[["","Tutti i tecnici"]].concat(tk.map(function(t){return [t,t]})),F.t,function(v){go({t:v})});
 var it=$("its");it.textContent="";var mh=$("mh");mh.textContent="";var rie=$("rie");
 if(F.frq){var Q=frequenti();rie.hidden=true;$("cn").textContent=Q.length?Q.length+(Q.length===1?" matricola":" matricole")+" con 2 o più interventi negli ultimi 6 mesi":"";
  if(!Q.length)it.append(el("p","empty","Nessuna macchina con 2 o più interventi negli ultimi 6 mesi."));
  Q.forEach(function(c){var b=btn("it cor",null,function(){apri(c.v)}),l=el("b","fq");l.append(el("span",0,c.v),el("span",0,c.n+" interventi"));b.append(l,el("span",0,(c.cl?c.cl+" · ":"")+"ultimo "+dIt(c.last)));it.append(b)});
  dett(null);status(tecs);return}
 var R=filtrati(),h=matStoria();
 if(h){var b=el("div","mh");b.append(document.createTextNode("Storia di "),el("b",0,h.v),document.createTextNode(" · "+R.length+(R.length===1?" rapportino":" rapportini")+", dal più recente"));mh.append(b)}
 $("cn").textContent=L.length?R.length+" di "+LV.length+" lavori":"";
 /* ultimo invio di ogni tecnico */
 var inv=$("inv"),UI={};inv.textContent="";LV.forEach(function(r){if(r.tec){var t=+r.sent||r.d;if(!UI[r.tec]||t>UI[r.tec])UI[r.tec]=t}});
 var uk=Object.keys(UI).sort(function(a,b){return UI[a]-UI[b]});if(uk.length){inv.hidden=false;inv.append(el("span",0,"Ultimo invio: "));uk.forEach(function(t,i){var gg=Math.floor((Date.now()-UI[t])/864e5),x=el("span",gg>7?"old":"",t+" "+dIt(UI[t])+(gg>7?" ("+gg+" giorni)":""));if(i)inv.append(document.createTextNode(" · "));inv.append(x)})}else inv.hidden=true;
 /* riepilogo del periodo */
 if(R.length){var cnt={},ore=0,ot={};R.forEach(function(r){cnt[r.v]=(cnt[r.v]||0)+1;var o=+g(r.s||{},"ore")||0;ore+=o;if(r.tec&&o)ot[r.tec]=(ot[r.tec]||0)+o});
  rie.textContent="";rie.hidden=false;rie.append(el("b",0,R.length+(R.length===1?" lavoro":" lavori")),document.createTextNode(": "+Object.keys(TIT).filter(function(k){return cnt[k]}).map(function(k){return cnt[k]+" "+TIT[k].toLowerCase()}).join(", ")));
  if(ore){rie.append(document.createTextNode(" · "),el("b",0,ore+(ore===1?" ora":" ore")),document.createTextNode(" di manodopera"));var tt=Object.keys(ot);if(tt.length>1)rie.append(document.createTextNode(" ("+tt.map(function(t){return t+" "+ot[t]}).join(", ")+")"))}}
 else rie.hidden=true;
 if(!L.length){it.append(el("p","empty","Archivio vuoto. Importa i file inviati dall'app o collega la cartella dove arrivano."))}
 else if(!R.length)it.append(el("p","empty","Nessun risultato."));
 R.slice(0,400).forEach(function(r){var st=stato(r),c=btn("it"+(st==="fatto"?" fat":st==="corso"?" cor":"")+(nuovo(r)?" nw":"")+(F.sel===r.u?" on":""),null,function(){if(h&&!F.sel)go({sel:r.u});else{F.sel=r.u;draw()}if(innerWidth<860)$("det").scrollIntoView()});
  var tl=el("b",0,r.n||"Senza nome"),T=tagsL(r);if(nuovo(r))tl.prepend(el("em","nwb","Nuovo"));if(T.length){var dd=el("span","dots");T.forEach(function(id){var t=tagOf(id),d=el("i","dot");d.style.background=t.c;d.title=t.n;dd.append(d)});tl.append(dd)}
  var nn=comms("L",r.u).length;c.append(tl,el("span",0,TIT[r.v]+" · "+dLav(r)+(r.tec?" · "+r.tec:"")+(st==="corso"?" · in corso":st==="attesa"?" · in attesa":"")+(nn?" · 💬 "+nn:"")));it.append(c)});
 if(R.length>400)it.append(el("p","cnt","Mostrati i primi 400: affina la ricerca."));
 dett(h);status(tecs)}
function status(tecs){$("st").textContent=vis().length+" lavori · "+Object.keys(tecs).length+(Object.keys(tecs).length===1?" tecnico":" tecnici");dirLabel()}
function dett(h){var d=$("det");d.textContent="";var r=L.filter(function(x){return x.u===F.sel})[0];
 if(!r&&h){d.append(macchina(h),el("p","st","Scegli un rapportino dall'elenco per aprirlo."));return}
 if(!r){d.append(el("p","empty",L.length?"Scegli un lavoro dall'elenco, oppure cerca una matricola o un codice impianto per vedere la scheda della macchina.":"Qui vedrai il rapportino, le matricole e le foto."));return}
 var s=r.s||{};d.append(el("h2",0,r.n||"Senza nome"),el("div","sub",TIT[r.v]+" · "+(stato(r)==="fatto"?"concluso":stato(r)==="corso"?"in corso":"in attesa")+" · archiviato il "+dIt(r.d)+(hid(r)?" · eliminato da "+(TEAM.hid[r.u].a||"?"):"")));
 var az=el("div","az"),pv=el("div","pdfv");pv.hidden=true;az.append(btn("b sm","PDF",function(){pdfLav(r,pv)}),btn("b sm","Mail al magazzino",function(){mailLav(r)}));
 if(stato(r)!=="fatto")az.append(btn("b sm","Scheda da riprendere",function(){riprendi(r)}));
 az.append(
  hid(r)?btn("b sm","Ripristina",function(){TEAM.hid[r.u]={on:0,ts:Date.now(),a:NOME};teamSave();draw()}):btn("b sm dgb","Elimina",function(){if(!confirm("Eliminare «"+(r.n||"lavoro")+"» per tutta la squadra?\nSi può ripristinare da Stato › Eliminati."))return;TEAM.hid[r.u]={on:1,ts:Date.now(),a:NOME};teamSave();F.sel=null;draw()}));d.append(az,pv);
 var kv=el("dl","kv");function row(k,v){if(!v)return;kv.append(el("dt",0,k),el("dd",0,v))}
 var TL=tecL(r);row(TL.length>1?"Tecnici":"Tecnico",TL.join(" → "));row("Data intervento",dLav(r));row("Cliente",g(s,"cl"));if(s.rv)row("Rivenditore",g(s,"rvn"));row("Sede",g(s,"se"));row("Riferimento",rif(r));row("Manodopera",g(s,"ore")?g(s,"ore")+(g(s,"ore")==="1"?" ora":" ore"):"");d.append(kv);
 d.append(el("h3",0,"Etichette"),tagRow("L",r.u),el("h3",0,"Commenti"),commBox("L",r.u));
 var M=mats(r);if(M.length){d.append(el("h3",0,"Matricole · scheda macchina"));var w=el("div","mats");M.forEach(function(m){var b=btn("mat",null,function(){apri(m.v)});b.append(el("i",0,m.k),document.createTextNode(m.v));var mt=tagsK("M",mk(m.v));mt.forEach(function(id){var t=tagOf(id);if(t){var dd=el("i","dot");dd.style.background=t.c;dd.style.marginLeft="6px";dd.title=t.n;b.append(dd)}});w.append(b)});d.append(w)}
 if(r.nt){d.append(el("h3",0,"Note rapportino"));var p=el("pre","note",r.nt);d.append(p,btn("b sm","Copia note",function(e){var b=e.target;navigator.clipboard.writeText(r.nt).then(function(){b.textContent="Copiato";setTimeout(function(){b.textContent="Copia note"},1500)})}))}
 var nte=g(s,"nte");if(nte){d.append(el("h3",0,"Note tecniche"),el("pre","note",nte))}
 var P=(r.ph||[]).filter(function(f){return f&&typeof f.d==="string"&&f.d.indexOf("data:image/")===0});
 if(P.length){d.append(el("h3",0,"Foto · "+P.length));var ph=el("div","ph");P.forEach(function(f){var a=el("a");a.href="#";a.onclick=function(e){e.preventDefault();var wn=window.open();if(wn){wn.document.title=f.n||"foto";var im=wn.document.createElement("img");im.src=f.d;im.style.maxWidth="100%";wn.document.body.append(im)}};var im=document.createElement("img");im.src=f.d;im.alt=f.n||"";a.append(im,el("span",0,f.n||""));ph.append(a)});d.append(ph)}
 var det=el("details","raw");det.append(el("summary",0,"Tutti i dati della scheda"));var tb=el("table");Object.keys(s).sort().forEach(function(k){if(/^_/.test(k)||s[k]===""||s[k]===0||s[k]==null)return;var tr=el("tr");tr.append(el("td",0,k),el("td",0,typeof s[k]==="object"?JSON.stringify(s[k]):String(s[k])));tb.append(tr)});det.append(tb);d.append(el("h3",0,"Dettagli"),det)}

/* ---------- PDF e Mail al magazzino: si usa l'app Glory 2.0 in una finestra nascosta ---------- */
var APPW=null;
function appWin(){if(APPW)return APPW;APPW=new Promise(function(ok,ko){var f=document.createElement("iframe");f.style.cssText="position:absolute;width:10px;height:10px;left:-9999px;top:0;border:0";f.setAttribute("aria-hidden","true");
 f.src=location.protocol==="chrome-extension:"?"app.html":"../index.html";
 f.onload=function(){var n=0;(function t(){var w=f.contentWindow;if(w&&w.buildPdf&&w.magMail&&w.V&&w.mig){ok(w)}else if(++n>60){APPW=null;ko()}else setTimeout(t,100)})()};document.body.append(f)});return APPW}
function conApp(r,fn){return appWin().then(function(w){var v0=w.view,s0=w.S,p0=w.PH[r.v];w.view=r.v;w.S=w.mig(r.v,JSON.parse(JSON.stringify(r.s)));w.PH[r.v]=w.bkPh(r.ph);try{return fn(w)}finally{w.view=v0;w.S=s0;w.PH[r.v]=p0}})}
/* telefono: niente download, si condivide (WhatsApp, lettore PDF, Glory 2.0…) */
function tel(){return matchMedia("(pointer:coarse)").matches&&!!navigator.canShare}
function condividi(blob,fn,ko){var f;try{f=new File([blob],fn,{type:blob.type})}catch(e){}if(f&&navigator.canShare&&navigator.canShare({files:[f]})){navigator.share({files:[f],title:fn}).catch(function(){});return}(ko||scarica)(blob,fn)}
function pdfLav(r,pv){var fn=(r.n||"rapportino")+".pdf";say("Preparo il PDF…");var W;conApp(r,function(w){W=w;var bl=w.V[r.v].blocks(w.S),mt=w.pdfMeta(bl,r.d);mt.fn=fn;return w.buildPdf(mt,w.pdfRows(bl))})
 .then(function(u){say("");var b=new Blob([u],{type:"application/pdf"});if(!tel()||!pv){scarica(b,fn);return}
  pv.textContent="";pv.hidden=false;var bar=el("div","az");bar.append(btn("b ac sm","Condividi PDF",function(){condividi(b,fn)}),btn("b sm","Scarica",function(){scarica(b,fn)}),btn("b sm","Chiudi",function(){pv.hidden=true;pv.textContent=""}));pv.append(bar);
  W.loadPdfJs().then(function(lib){return lib.getDocument({data:new W.Uint8Array(u)}).promise}).then(function(doc){var ch=Promise.resolve();for(var n=1;n<=doc.numPages;n++)(function(n){ch=ch.then(function(){return doc.getPage(n)}).then(function(pg){var vp=pg.getViewport({scale:2}),c=document.createElement("canvas");c.width=vp.width;c.height=vp.height;pv.append(c);return pg.render({canvasContext:c.getContext("2d"),viewport:vp}).promise})})(n);return ch}).catch(function(){pv.append(el("p","st","Anteprima non disponibile: usa Condividi PDF."))});
  pv.scrollIntoView({behavior:"smooth"})},function(){say("PDF non riuscito: apri il programma con internet almeno una volta.",1)})}
/* scheda da riprendere: file «Scheda Glory» che un tecnico apre con Glory 2.0 e continua (stesso lavoro, codice u) */
function riprendi(r){var o=JSON.parse(JSON.stringify(r.s||{}));delete o._arc;o._u=r.u;var n=new Date(),t={glory:2,view:r.v,saved:n.getFullYear()+"-"+("0"+(n.getMonth()+1)).slice(-2)+"-"+("0"+n.getDate()).slice(-2),s:o,ph:r.ph||[]};
 var fn="Scheda Glory - "+(r.n||TIT[r.v])+".txt",b=new Blob([JSON.stringify(t)],{type:"text/plain"});
 if(tel())condividi(b,fn);else{scarica(b,fn);say("Mandalo al tecnico che continua: lo apre con Glory 2.0 (Condividi › Glory, oppure menù › Carica scheda).")}}
function mailLav(r){conApp(r,function(w){return w.magMail(w.S)}).then(function(u){location.href=u},function(){say("Mail non riuscita: apri il programma con internet almeno una volta.",1)})}

/* ---------- Excel (CSV con separatore ;) ---------- */
function oggi(){var n=new Date();return p2(n.getDate())+"-"+p2(n.getMonth()+1)+"-"+n.getFullYear()}
function scarica(blob,fn){var a=document.createElement("a"),u=URL.createObjectURL(blob);a.href=u;a.download=fn;document.body.append(a);a.click();a.remove();setTimeout(function(){URL.revokeObjectURL(u)},4000)}
function csv(){var R=filtrati();if(!R.length){say("Niente da esportare.",1);return}
 function q(v){v=String(v==null?"":v);return /[;"\n\r]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v}
 var H=["Data","Tipo","Stato","Tecnico","Cliente","Rivenditore","Sede","Riferimento","Matricole","Ore","Etichette","Commenti","Nome lavoro","Note rapportino"],rows=[H.join(";")];
 R.forEach(function(r){var s=r.s||{};rows.push([dLav(r),TIT[r.v],stato(r)==="fatto"?"Concluso":stato(r)==="corso"?"In corso":"In attesa",r.tec,g(s,"cl"),s.rv?g(s,"rvn"):"",g(s,"se"),rif(r),mats(r).map(function(m){return m.v}).join(", "),g(s,"ore"),tagsL(r).map(function(id){return tagOf(id).n}).join(", "),commTxt(r),r.n,r.nt||""].map(q).join(";"))});
 scarica(new Blob(["﻿"+rows.join("\r\n")],{type:"text/csv"}),"Glory archivio - "+oggi()+".csv")}
function salvaTutto(){if(!L.length){say("Archivio vuoto.",1);return}
 scarica(new Blob([JSON.stringify({gloryPc:1,saved:Date.now(),lav:L,team:TEAM})],{type:"application/json"}),"Glory archivio completo - "+oggi()+".json");say("Archivio, etichette e commenti salvati. Per ripristinarlo su questo o un altro PC usa Importa file.")}

/* ---------- avvio ---------- */
$("fi").onchange=function(){if(this.files.length)importa(this.files);this.value=""};
$("q").oninput=function(){F.q=this.value;F.sel=null;F.frq=0;draw()};
$("dirb").onclick=dirPick;$("sync").onclick=function(){dirSync()};$("csv").onclick=csv;$("tagb").onclick=tagEditor;$("setb").onclick=impostazioni;$("bak").onclick=salvaTutto;
/* estensione: avvisa se su GitHub c'è una versione più recente */
function verN(v){return String(v||"0").split(".").map(Number).reduce(function(a,b){return a*1000+(b||0)},0)}
if(location.protocol==="chrome-extension:")fetch("https://francescov17ale.github.io/glory-app/archivio/version.json?t="+Date.now(),{cache:"no-store"}).then(function(r){return r.json()}).then(function(j){var me=chrome.runtime.getManifest().version;if(verN(j.ext)>verN(me)){var u=$("upd");u.hidden=false;u.textContent="";u.append(document.createTextNode("È disponibile l'estensione "+j.ext+" (hai la "+me+"). "));var a=el("a",0,"Scarica lo zip");a.href="https://francescov17ale.github.io/glory-app/archivio/Glory-Archivio-estensione.zip";u.append(a,document.createTextNode(", estrailo sopra la stessa cartella e in chrome://extensions tocca Ricarica."))}}).catch(function(){});
document.addEventListener("keydown",function(e){if(e.key==="Escape"){var o=document.querySelector(".ov");if(o){o.remove();draw()}else if(HIST.length&&document.activeElement.tagName!=="INPUT"&&document.activeElement.tagName!=="TEXTAREA")back()}});
var dc=0;document.addEventListener("dragenter",function(e){e.preventDefault();dc++;$("drop").hidden=false});
document.addEventListener("dragleave",function(){if(--dc<=0){dc=0;$("drop").hidden=true}});
document.addEventListener("dragover",function(e){e.preventDefault()});
document.addEventListener("drop",function(e){e.preventDefault();dc=0;$("drop").hidden=true;if(e.dataTransfer.files.length)importa(e.dataTransfer.files)});
try{if(navigator.storage&&navigator.storage.persist)navigator.storage.persist()}catch(e){}
dbOpen().then(function(){return Promise.all([cfg("pcid"),cfg("nome"),cfg("team"),cfg("meta"),cfg("aperto"),cfg("main"),cfg("pulito")])}).then(function(a){
 PREV=+a[4]||0;cfg("aperto",Date.now());MAIN=+a[5]||0;PULITO=+a[6]||0;
 PCID=a[0]||Math.random().toString(36).slice(2,8);if(!a[0])cfg("pcid",PCID);NOME=a[1]||"";nomeLab();
 TEAM=a[2]?teamFix(a[2]):teamDef();if(!a[2]){if(a[3])metaToTeam(a[3]);cfg("team",TEAM)}}).then(dbAll).then(function(a){L=a;draw();return dirInit()}).then(draw).catch(function(){say("Questo browser non può salvare l'archivio: usa Chrome o Edge.",1)});

