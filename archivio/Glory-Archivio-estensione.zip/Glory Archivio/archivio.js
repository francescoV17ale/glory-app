
"use strict";
/* Archivio dei rapportini arrivati dall'app Glory 2.0 ("Archivio per il PC").
   I dati restano su questo PC: nel browser (IndexedDB) e, se collegata, in una cartella (un file per lavoro). */
var DB=null,L=[],SEL=null,F={q:"",v:"",t:""},DIR=null;
var TIT={inst:"Installazione",prep:"Preparazione",rip:"Riparazione",loc:"In loco",altro:"Altra attività",rit:"Ritiro"};
var PX={"CI-5":"50","CI-10":"100","CI-10X":"200"};
function $(i){return document.getElementById(i)}
function el(t,c,x){var e=document.createElement(t);if(c)e.className=c;if(x!=null)e.textContent=x;return e}
function btn(c,x,fn){var b=el("button",c,x);b.type="button";b.onclick=fn;return b}
function p2(n){return n<10?"0"+n:""+n}
function dIt(t){var d=new Date(t);return p2(d.getDate())+"/"+p2(d.getMonth()+1)+"/"+d.getFullYear()}
function dLav(r){var m=/^(\d{4})-(\d\d)-(\d\d)$/.exec((r.s&&r.s.dt)||"");return m?m[3]+"/"+m[2]+"/"+m[1]:dIt(r.d)}
function tLav(r){var m=/^(\d{4})-(\d\d)-(\d\d)$/.exec((r.s&&r.s.dt)||"");return m?new Date(+m[1],+m[2]-1,+m[3]).getTime():r.d}
function g(s,k){return String(s[k]==null?"":s[k]).trim()}
function say(t,ko){var m=$("msg");m.textContent=t;m.className="msg"+(ko?" ko":"");m.hidden=!t;clearTimeout(say.t);if(t)say.t=setTimeout(function(){m.hidden=true},9000)}

/* ---------- matricole e codici impianto di un lavoro ---------- */
function mats(r){var s=r.s||{},o=[],i,v=r.v;
 function add(k,pre,n){n=String(n||"").trim();if(n)o.push({k:k,v:(pre||"")+n,n:n})}
 function dev(n){for(i=1;i<=n;i++){var px=PX[s["m"+i]]||"";add("Banconote","RBW"+px+"-",s["a"+i]);add("Monete","RCW"+px+"-",s["c"+i]);add("Impianto","",s["mt"+i])}}
 if(v==="inst"||v==="rit")dev(+s.n||(s.m1||s.a1||s.c1?1:0));
 else if(v==="rip"){for(i=1;i<=(+s.rn||1);i++){var p="r"+i+"_",t=s[p+"tp"]==="Banconote"?"B":s[p+"tp"]==="Monete"?"C":"",px=PX[s[p+"md"]]||"";add(t==="B"?"Banconote":t==="C"?"Monete":"Modulo",t&&px?"R"+t+"W"+px+"-":"",s[p+"mat"])}}
 else if(v==="loc"){var q=PX[s.md]||"";add("Banconote",q?"RBW"+q+"-":"",s.r1_mat);add("Monete",q?"RCW"+q+"-":"",s.r2_mat);add("Impianto","",s.mt)}
 else if(v==="prep"){var z=PX[s.m]||"50";add("Banconote","RBW"+z+"-",s.mtB);add("Monete","RCW"+z+"-",s.mtM);for(i=2;i<=(+s.dn||1);i++)add("Monete","RCW50-",s["mtM"+i]);add("Impianto","",s.mtD)}
 else add("Matricola","",s.ma);
 return o}
function cliente(r){var s=r.s||{};return g(s,"cl")||g(s,"rvn")}
function rif(r){var s=r.s||{},o=[];if(g(s,"rma"))o.push("RMA "+g(s,"rma"));if(g(s,"cv"))o.push("CV "+g(s,"cv"));if(g(s,"cvc"))o.push("CV "+g(s,"cvc"));if(g(s,"rf"))o.push(g(s,"rf"));if(g(s,"rc"))o.push((s.rf||"")+" "+g(s,"rc"));return o.join(" · ")}
function testo(r){var s=r.s||{};return [r.n,r.tec,TIT[r.v],cliente(r),g(s,"rvn"),g(s,"se"),rif(r),r.nt].concat(mats(r).map(function(m){return m.v+" "+m.n})).join(" ").toLowerCase()}

/* ---------- archivio locale (IndexedDB) ---------- */
function dbOpen(){return new Promise(function(ok,ko){var q=indexedDB.open("glory_pc",1);q.onupgradeneeded=function(){var d=q.result;d.createObjectStore("lav",{keyPath:"u"});d.createObjectStore("cfg")};q.onsuccess=function(){DB=q.result;ok()};q.onerror=function(){ko(q.error)}})}
function dbAll(){return new Promise(function(ok){var t=DB.transaction("lav").objectStore("lav").getAll();t.onsuccess=function(){ok(t.result||[])};t.onerror=function(){ok([])}})}
function dbPut(arr){return new Promise(function(ok,ko){if(!arr.length){ok();return}var t=DB.transaction("lav","readwrite"),st=t.objectStore("lav");arr.forEach(function(r){st.put(r)});t.oncomplete=ok;t.onerror=t.onabort=function(){ko(t.error)}})}
function cfg(k,v){return new Promise(function(ok){var t=DB.transaction("cfg",v===undefined?"readonly":"readwrite"),st=t.objectStore("cfg"),q=v===undefined?st.get(k):st.put(v,k);q.onsuccess=function(){ok(q.result)};q.onerror=function(){ok(null)}})}

/* ---------- cartella sul PC (Chrome/Edge): un file .json per lavoro ---------- */
var FSA=!!window.showDirectoryPicker;
function dirLabel(){var b=$("dirb");if(!FSA){b.hidden=true;return}b.hidden=false;b.textContent=DIR?(DIR.ok?"Cartella: "+DIR.h.name:"Riapri la cartella "+DIR.h.name):"Collega una cartella";$("sync").hidden=!(DIR&&DIR.ok)}
function dirPick(){if(DIR&&!DIR.ok){DIR.h.requestPermission({mode:"readwrite"}).then(function(p){if(p==="granted"){DIR.ok=1;dirSync()}dirLabel()});return}
 window.showDirectoryPicker({mode:"readwrite",id:"glory-archivio"}).then(function(h){DIR={h:h,ok:1};SEEN={};cfg("seen",SEEN);cfg("dir",h);dirSync();dirLabel()},function(){})}
function dirInit(){if(!FSA)return Promise.resolve();return cfg("seen").then(function(x){SEEN=x||{}}).then(function(){return cfg("dir")}).then(function(h){if(!h)return;DIR={h:h,ok:0};return h.queryPermission({mode:"readwrite"}).then(function(p){if(p==="granted"){DIR.ok=1;return dirSync()}})}).catch(function(){})}
/* nella cartella (anche una cartella condivisa di Google Drive):
   - i file "Archivio Glory …" che arrivano dai tecnici vengono importati da soli
   - la copia dell'archivio va nella sottocartella _archivio (un file .json per lavoro) */
var SUB="_archivio",SEEN={};
function subDir(){return DIR.h.getDirectoryHandle(SUB,{create:true})}
function dirWrite(arr){if(!DIR||!DIR.ok||!arr.length)return Promise.resolve();
 return subDir().then(function(sd){return arr.reduce(function(pr,r){return pr.then(function(){return sd.getFileHandle(fnSafe(r.u)+".json",{create:true}).then(function(fh){return fh.createWritable()}).then(function(w){return w.write(JSON.stringify(r)).then(function(){return w.close()})})})},Promise.resolve())}).catch(function(){say("Non riesco a scrivere nella cartella: ricollegala.",1)})}
function fnSafe(t){return String(t).replace(/[^A-Za-z0-9_-]/g,"_")}
var syncing=0;
function dirSync(){if(!DIR||!DIR.ok||syncing)return Promise.resolve();syncing=1;var got={},inc=[],nf=0;
 return (async function(){
  for await (var e of DIR.h.values()){if(e.kind!=="file"||!/\.(txt|json)$/i.test(e.name))continue;
   var f=await e.getFile(),key=e.name+"|"+f.size+"|"+f.lastModified;if(SEEN[key])continue;
   var o=null;try{o=JSON.parse(await f.text())}catch(x){}SEEN[key]=1;
   if(o&&o.u&&o.s&&o.v){got[o.u]=o;continue}            /* copia di un lavoro lasciata nella cartella principale (versione precedente) */
   var A=o?norm(o):[];if(A.length){nf++;inc=inc.concat(A)}}
  var sd=await subDir();
  for await (var e2 of sd.values()){if(e2.kind!=="file"||!/\.json$/.test(e2.name))continue;var f2=await e2.getFile(),k2=SUB+"/"+e2.name+"|"+f2.size+"|"+f2.lastModified;if(SEEN[k2])continue;SEEN[k2]=1;try{var r=JSON.parse(await f2.text());if(e2.name==="_meta.json"){if(r&&+r.ts>(+META.ts||0)){META=metaFix(r);cfg("meta",META)}else if(r&&metaMerge(r))metaSave()}else if(r&&r.u)got[r.u]=r}catch(x){}}
 })().then(function(){
  var M={},toDb=[],nu=0,ag=0;L.forEach(function(r){M[r.u]=r});
  Object.keys(got).forEach(function(u){var r=got[u];if(!M[u]||r.d>M[u].d){toDb.push(r);M[u]=r}});
  var toDir=[];inc.forEach(function(r){var e=M[r.u];if(!e){nu++;M[r.u]=r;toDb.push(r);toDir.push(r)}else if(r.d>e.d){ag++;M[r.u]=r;toDb.push(r);toDir.push(r)}});
  L.forEach(function(r){if(!got[r.u]&&toDir.indexOf(r)<0&&!SEEN["w|"+r.u+"|"+r.d])toDir.push(r)});
  L=Object.keys(M).map(function(u){return M[u]});
  return dbPut(toDb).then(function(){return dirWrite(toDir)}).then(metaDir).then(function(){toDir.forEach(function(r){SEEN["w|"+r.u+"|"+r.d]=1});cfg("seen",SEEN);
   if(nu||ag)say("Dalla cartella: "+nu+(nu===1?" nuovo":" nuovi")+(ag?", "+ag+(ag===1?" aggiornato":" aggiornati"):"")+".");draw()})})
 .catch(function(){say("Lettura della cartella non riuscita: ricollegala.",1)}).then(function(){syncing=0})}
/* torna sulla finestra o tocca Aggiorna: rilegge la cartella */
window.addEventListener("focus",function(){if(DIR&&DIR.ok)dirSync()});

/* ---------- etichette e note personali (solo su questo PC e nella cartella collegata) ---------- */
var COL=["#c23b22","#d97706","#ca8a04","#1f7a4d","#0f766e","#1f5f99","#6d28d9","#be185d","#5b6770"];
var META={tags:[],L:{},M:{},ts:0};
function metaFix(m){m=m&&typeof m==="object"?m:{};return {tags:Array.isArray(m.tags)?m.tags:[],L:m.L&&typeof m.L==="object"?m.L:{},M:m.M&&typeof m.M==="object"?m.M:{},ts:+m.ts||0}}
function metaDef(){var n=["Da fatturare","Garanzia","Cliente critico","Da richiamare","Ricambio in ordine","Macchina problematica"],c=[1,5,0,2,6,7];
 return {tags:n.map(function(x,i){return {id:"t"+(i+1),n:x,c:COL[c[i]]}}),L:{},M:{},ts:0}}
/* unisce etichette e note di un altro archivio: aggiunge quelle che mancano, non cancella niente */
function metaMerge(m){m=metaFix(m);var ch=0;m.tags.forEach(function(t){var e=tagOf(t.id);if(!e){META.tags.push(t);ch=1}});
 ["L","M"].forEach(function(k){Object.keys(m[k]).forEach(function(x){var a=META[k][x],b=m[k][x];if(!a){META[k][x]=b;ch=1;return}
  (b.t||[]).forEach(function(id){if(a.t.indexOf(id)<0){a.t.push(id);ch=1}});if(b.n&&!a.n){a.n=b.n;ch=1}})});return ch}
var mdT=null;
function metaSave(){META.ts=Date.now();cfg("meta",META);clearTimeout(mdT);mdT=setTimeout(metaDir,800)}
function metaDir(){if(!DIR||!DIR.ok)return Promise.resolve();return subDir().then(function(sd){return sd.getFileHandle("_meta.json",{create:true})}).then(function(fh){return fh.createWritable()}).then(function(w){return w.write(JSON.stringify(META)).then(function(){return w.close()})}).catch(function(){})}
function mk(v){return String(v||"").toUpperCase().replace(/\s+/g,"")}
function slot(kind,k){var o=META[kind][k];if(!o){o={t:[],n:""};META[kind][k]=o}return o}
function clean(kind,k){var o=META[kind][k];if(o&&!o.t.length&&!String(o.n||"").trim())delete META[kind][k]}
function tagOf(id){return META.tags.filter(function(t){return t.id===id})[0]}
function tagsL(r){var o=(META.L[r.u]||{}).t||[],M=mats(r);M.forEach(function(m){((META.M[mk(m.v)]||{}).t||[]).forEach(function(t){if(o.indexOf(t)<0)o=o.concat(t)})});return o.filter(tagOf)}
function tagRow(kind,k){var w=el("div","tgs"),o=META[kind][k]||{t:[]};
 if(!META.tags.length){w.append(el("span","st","Nessuna etichetta: creale con il tasto Etichette."));return w}
 META.tags.forEach(function(t){var on=o.t.indexOf(t.id)>=0,b=btn("tg"+(on?" on":""),null,function(){var x=slot(kind,k),i=x.t.indexOf(t.id);if(i<0)x.t.push(t.id);else x.t.splice(i,1);clean(kind,k);metaSave();draw()});
  var d=el("i");d.style.background=t.c;b.append(d,document.createTextNode(t.n));if(on)b.style.borderColor=t.c;b.setAttribute("aria-pressed",on?"true":"false");w.append(b)});return w}
function noteBox(kind,k,ph){var ta=el("textarea","mynote");ta.placeholder=ph;ta.value=(META[kind][k]||{}).n||"";
 ta.oninput=function(){slot(kind,k).n=ta.value;clean(kind,k);metaSave()};ta.onblur=function(){draw()};return ta}

/* ---------- editor delle etichette ---------- */
function tagEditor(){var ov=el("div","ov"),d=el("div","dlg");ov.setAttribute("role","dialog");ov.setAttribute("aria-modal","true");
 function close(){ov.remove();draw()}
 ov.onclick=function(e){if(e.target===ov)close()};
 function body(){d.textContent="";d.append(el("h2",0,"Etichette"));
  META.tags.forEach(function(t,i){var r=el("div","er"),inp=document.createElement("input"),sel=document.createElement("select"),dot=el("span","dot");
   inp.type="text";inp.value=t.n;inp.setAttribute("aria-label","Nome etichetta");inp.oninput=function(){t.n=inp.value;metaSave()};
   dot.style.background=t.c;COL.forEach(function(c,j){var op=new Option("Colore "+(j+1),c);op.style.background=c;op.style.color="#fff";if(c===t.c)op.selected=true;sel.append(op)});sel.style.background=t.c;sel.style.color="#fff";sel.setAttribute("aria-label","Colore");
   sel.onchange=function(){t.c=sel.value;sel.style.background=t.c;dot.style.background=t.c;metaSave()};
   var x=btn("x","✕",function(){if(!confirm("Eliminare l'etichetta «"+t.n+"»? Viene tolta da tutti i lavori e le matricole."))return;META.tags.splice(i,1);["L","M"].forEach(function(kd){Object.keys(META[kd]).forEach(function(k){var o=META[kd][k];o.t=o.t.filter(function(z){return z!==t.id});clean(kd,k)})});metaSave();body()});x.setAttribute("aria-label","Elimina "+t.n);
   r.append(dot,inp,sel,x);d.append(r)});
  var row=el("div","er");row.style.marginTop="12px";row.append(btn("b ac","+ Nuova etichetta",function(){var id="t"+Date.now().toString(36);META.tags.push({id:id,n:"Nuova etichetta",c:COL[META.tags.length%COL.length]});metaSave();body();var ii=d.querySelectorAll("input[type=text]");if(ii.length){ii[ii.length-1].focus();ii[ii.length-1].select()}}),btn("b","Chiudi",close));d.append(row)}
 body();ov.append(d);document.body.append(ov)}

/* ---------- importazione: solo lavori nuovi o aggiornati ---------- */
function readFile(f){return new Promise(function(ok){var rd=new FileReader();rd.onload=function(){ok(String(rd.result||""))};rd.onerror=function(){ok("")};rd.readAsText(f)})}
function norm(o){var arr=[],dev=o.dev||"bk";
 if(o&&o.glory===2&&Array.isArray(o.arc))o.arc.forEach(function(r){if(!r||!r.v||!r.s)return;var x=JSON.parse(JSON.stringify(r));x.u=x.u||dev+"-"+(g(x.s,"tec")||"x")+"-"+x.id;x.tec=x.tec||g(x.s,"tec")||o.tec||"";x.d=+x.d||Date.now();delete x.xd;arr.push(x)});
 if(o&&o.gloryPc===1&&Array.isArray(o.lav))o.lav.forEach(function(r){if(r&&r.u&&r.v&&r.s)arr.push(r)});
 return arr}
function importa(files){var M={},nu=0,ag=0,ug=0,bad=0,ch=[],mt=0;L.forEach(function(r){M[r.u]=r});
 Promise.all(Array.prototype.map.call(files,readFile)).then(function(T){
  T.forEach(function(t){var o=null;try{o=JSON.parse(t)}catch(e){}var A=o?norm(o):[];
   if(o&&o.gloryPc===1&&o.meta&&metaMerge(o.meta))mt=1
   if(!A.length&&!mt){bad++;return}
   A.forEach(function(r){var e=M[r.u];if(!e){nu++;M[r.u]=r;ch.push(r)}else if(r.d>e.d){ag++;M[r.u]=r;ch.push(r)}else ug++})});
  if(mt)metaSave()
  return dbPut(ch).then(function(){return dirWrite(ch)}).then(function(){L=Object.keys(M).map(function(u){return M[u]});
   say(bad&&!nu&&!ag&&!ug&&!mt?"File non riconosciuto: usa il file inviato dall'app (Invia al PC) o un «Salva tutto».":nu+(nu===1?" nuovo, ":" nuovi, ")+ag+(ag===1?" aggiornato, ":" aggiornati, ")+ug+" già present"+(ug===1?"e":"i")+(mt?", etichette e note ripristinate":"")+(bad?", "+bad+" file non validi":"")+".",bad&&!nu&&!ag&&!ug&&!mt);
   if(ch.length&&!F.sel)F.sel=ch[0].u;draw()})}).catch(function(){say("Importazione non riuscita.",1)})}

/* ---------- stato della vista e freccia Indietro ---------- */
var F={q:"",v:"",t:"",per:"",da:"",a:"",st:"",tag:"",sel:null,frq:0},HIST=[];
function snap(){return JSON.parse(JSON.stringify(F))}
function go(ch){HIST.push(snap());if(HIST.length>40)HIST.shift();Object.keys(ch).forEach(function(k){F[k]=ch[k]});$("q").value=F.q;draw();window.scrollTo(0,0)}
function back(){if(!HIST.length)return;F=HIST.pop();$("q").value=F.q;draw()}
function apri(m){go({q:m,v:"",frq:0,sel:null})}

/* ---------- filtri ---------- */
var PER=[["","Sempre"],["m0","Questo mese"],["m1","Mese scorso"],["m3","Ultimi 3 mesi"],["y0","Quest'anno"],["x","Da… a…"]];
function range(){var n=new Date(),y=n.getFullYear(),m=n.getMonth();
 if(F.per==="m0")return [new Date(y,m,1).getTime(),Infinity];if(F.per==="m1")return [new Date(y,m-1,1).getTime(),new Date(y,m,1).getTime()];
 if(F.per==="m3")return [new Date(y,m-2,1).getTime(),Infinity];if(F.per==="y0")return [new Date(y,0,1).getTime(),Infinity];
 if(F.per==="x"){var a=F.da?new Date(F.da+"T00:00").getTime():-Infinity,b=F.a?new Date(F.a+"T00:00").getTime()+864e5:Infinity;return [a,b]}return null}
function stato(r){return (!r.st||r.st==="fatto")?"fatto":r.st}
function filtrati(){var q=F.q.toLowerCase().trim(),W=q.split(/\s+/).filter(Boolean),R=range();
 return L.filter(function(r){if(F.v&&r.v!==F.v)return false;if(F.t&&r.tec!==F.t)return false;if(F.st&&stato(r)!==F.st)return false;
  if(R){var t=tLav(r);if(t<R[0]||t>=R[1])return false}
  if(F.tag&&tagsL(r).indexOf(F.tag)<0)return false;
  if(!W.length)return true;var t2=testo(r)+" "+String((META.L[r.u]||{}).n||"").toLowerCase();return W.every(function(w){return t2.indexOf(w)>=0})}).sort(function(a,b){return tLav(b)-tLav(a)||b.d-a.d})}
function matStoria(){var q=mk(F.q);if(q.length<3)return null;var hit=null;
 L.some(function(r){return mats(r).some(function(m){if(mk(m.v)===q||mk(m.n)===q){hit=m;return true}})});return hit}

/* ---------- scheda macchina ---------- */
function macchina(h){var K=mk(h.v),Rs=L.filter(function(r){return mats(r).some(function(m){return mk(m.v)===K})}).sort(function(a,b){return tLav(a)-tLav(b)}),
 part={},mod="",cli="",se="",ins=null,rit=null,int=[];
 Rs.forEach(function(r){var s=r.s||{},i,n;
  if(r.v==="inst"||r.v==="rit"){n=+s.n||1;for(i=1;i<=n;i++){var px=PX[s["m"+i]]||"",S=["RBW"+px+"-"+g(s,"a"+i),"RCW"+px+"-"+g(s,"c"+i),g(s,"mt"+i)];if(S.some(function(x){return mk(x)===K})){mod=s["m"+i]||mod;S.forEach(function(x){if(x&&!/-$/.test(x)&&mk(x)!==K)part[x]=1})}}}
  if(r.v==="loc"){mod=s.md||mod;mats(r).forEach(function(m){if(mk(m.v)!==K)part[m.v]=1})}
  if(r.v==="rip"){mod=s.r1_md||mod;if(s.rva)mats(r).forEach(function(m){if(mk(m.v)!==K)part[m.v]=1})}
  if(r.v==="inst")ins=r;if(r.v==="rit")rit=r;if(r.v==="loc"||r.v==="rip")int.push(r);
  if(cliente(r))cli=cliente(r);if(g(s,"se"))se=g(s,"se")});
 if(!mod){var m=/^R[BC]W(50|100|200)-/.exec(h.v);if(m)mod={"50":"CI-5","100":"CI-10","200":"CI-10X"}[m[1]]}
 var bx=el("div","mac");bx.append(el("div","st",h.k==="Impianto"?"Codice impianto":"Matricola "+h.k.toLowerCase()),el("h2",0,h.v),el("div",0,[mod?"Glory "+mod:"",cli,se].filter(Boolean).join(" · ")));
 var st=el("div","stats");function S(l,v){var d=el("div");d.append(el("b",0,v),document.createTextNode(l));st.append(d)}
 S("installazione",ins?dLav(ins):"—");S("interventi",String(int.length));S("ultimo intervento",int.length?dLav(int[int.length-1]):"—");if(rit)S("ritiro"+(rit.s&&rit.s.mo?" · "+rit.s.mo.toLowerCase():""),dLav(rit));bx.append(st);
 var P=Object.keys(part);if(P.length){bx.append(el("h3",0,"Stessa macchina"));var w=el("div","mats");P.forEach(function(x){w.append(btn("mat",x,function(){apri(x)}))});bx.append(w)}
 bx.append(el("h3",0,"Etichette della macchina"),tagRow("M",K),el("h3",0,"Nota sulla macchina"),noteBox("M",K,"Es. sensore lega sostituito due volte, valutare il modulo"));
 return bx}

/* ---------- macchine con più interventi (ultimi 6 mesi) ---------- */
function frequenti(){var lim=Date.now()-183*864e5,C={};
 L.forEach(function(r){if((r.v!=="loc"&&r.v!=="rip")||tLav(r)<lim)return;var seen={};mats(r).forEach(function(m){if(m.k==="Impianto")return;var k=mk(m.v);if(seen[k])return;seen[k]=1;var c=C[k]||(C[k]={v:m.v,n:0,cl:"",last:0});c.n++;if(tLav(r)>c.last){c.last=tLav(r);c.cl=cliente(r)}})});
 return Object.keys(C).map(function(k){return C[k]}).filter(function(c){return c.n>=2}).sort(function(a,b){return b.n-a.n||b.last-a.last})}

/* ---------- disegno ---------- */
function draw(){
 var bk=$("bk");bk.textContent="";if(HIST.length)bk.append(btn("back","‹ Indietro",back));
 var fl=$("fl");fl.textContent="";[["","Tutti"]].concat(Object.keys(TIT).map(function(k){return [k,TIT[k]]})).forEach(function(o){var n=o[0]?L.filter(function(r){return r.v===o[0]}).length:L.length;if(o[0]&&!n)return;fl.append(btn("ch"+(F.v===o[0]&&!F.frq?" on":""),o[1]+" "+n,function(){go({v:o[0],frq:0})}))});
 fl.append(btn("ch frq"+(F.frq?" on":""),"Macchine con più interventi",function(){go({frq:F.frq?0:1,sel:null})}));
 var fr=$("fr");fr.textContent="";
 function sel(lab,opts,val,fn){var se=el("select","sel");se.setAttribute("aria-label",lab);opts.forEach(function(o){var op=new Option(o[1],o[0]);if(o[0]===val)op.selected=true;se.append(op)});se.onchange=function(){fn(se.value)};fr.append(se)}
 sel("Periodo",PER,F.per,function(v){go({per:v})});
 if(F.per==="x"){[["da","Dal"],["a","Al"]].forEach(function(x){var i=document.createElement("input");i.type="date";i.value=F[x[0]];i.setAttribute("aria-label",x[1]);i.onchange=function(){F[x[0]]=i.value;draw()};fr.append(i)})}
 sel("Stato",[["","Tutti gli stati"],["fatto","Conclusi"],["corso","In corso"],["attesa","In attesa"]],F.st,function(v){go({st:v})});
 if(META.tags.length)sel("Etichetta",[["","Tutte le etichette"]].concat(META.tags.map(function(t){return [t.id,t.n]})),F.tag,function(v){go({tag:v})});
 var tecs={};L.forEach(function(r){if(r.tec)tecs[r.tec]=1});var tk=Object.keys(tecs).sort();
 if(tk.length>1)sel("Tecnico",[["","Tutti i tecnici"]].concat(tk.map(function(t){return [t,t]})),F.t,function(v){go({t:v})});
 var it=$("its");it.textContent="";var mh=$("mh");mh.textContent="";var rie=$("rie");
 if(F.frq){var Q=frequenti();rie.hidden=true;$("cn").textContent=Q.length?Q.length+(Q.length===1?" matricola":" matricole")+" con 2 o più interventi negli ultimi 6 mesi":"";
  if(!Q.length)it.append(el("p","empty","Nessuna macchina con 2 o più interventi negli ultimi 6 mesi."));
  Q.forEach(function(c){var b=btn("it cor",null,function(){apri(c.v)}),l=el("b","fq");l.append(el("span",0,c.v),el("span",0,c.n+" interventi"));b.append(l,el("span",0,(c.cl?c.cl+" · ":"")+"ultimo "+dIt(c.last)));it.append(b)});
  dett(null);status(tecs);return}
 var R=filtrati(),h=matStoria();
 if(h){var b=el("div","mh");b.append(document.createTextNode("Storia di "),el("b",0,h.v),document.createTextNode(" · "+R.length+(R.length===1?" rapportino":" rapportini")+", dal più recente"));mh.append(b)}
 $("cn").textContent=L.length?R.length+" di "+L.length+" lavori":"";
 /* riepilogo del periodo */
 if(R.length){var cnt={},ore=0,ot={};R.forEach(function(r){cnt[r.v]=(cnt[r.v]||0)+1;var o=+g(r.s||{},"ore")||0;ore+=o;if(r.tec&&o)ot[r.tec]=(ot[r.tec]||0)+o});
  rie.textContent="";rie.hidden=false;rie.append(el("b",0,R.length+(R.length===1?" lavoro":" lavori")),document.createTextNode(": "+Object.keys(TIT).filter(function(k){return cnt[k]}).map(function(k){return cnt[k]+" "+TIT[k].toLowerCase()}).join(", ")));
  if(ore){rie.append(document.createTextNode(" · "),el("b",0,ore+(ore===1?" ora":" ore")),document.createTextNode(" di manodopera"));var tt=Object.keys(ot);if(tt.length>1)rie.append(document.createTextNode(" ("+tt.map(function(t){return t+" "+ot[t]}).join(", ")+")"))}}
 else rie.hidden=true;
 if(!L.length){it.append(el("p","empty","Archivio vuoto. Importa i file inviati dall'app o collega la cartella dove arrivano."))}
 else if(!R.length)it.append(el("p","empty","Nessun risultato."));
 R.slice(0,400).forEach(function(r){var st=stato(r),c=btn("it"+(st==="fatto"?" fat":st==="corso"?" cor":"")+(F.sel===r.u?" on":""),null,function(){if(h&&!F.sel)go({sel:r.u});else{F.sel=r.u;draw()}if(innerWidth<860)$("det").scrollIntoView()});
  var tl=el("b",0,r.n||"Senza nome"),T=tagsL(r);if(T.length){var dd=el("span","dots");T.forEach(function(id){var t=tagOf(id),d=el("i","dot");d.style.background=t.c;d.title=t.n;dd.append(d)});tl.append(dd)}
  var nn=(META.L[r.u]||{}).n;c.append(tl,el("span",0,TIT[r.v]+" · "+dLav(r)+(r.tec?" · "+r.tec:"")+(st==="corso"?" · in corso":st==="attesa"?" · in attesa":"")+(nn?" · 📝":"")));it.append(c)});
 if(R.length>400)it.append(el("p","cnt","Mostrati i primi 400: affina la ricerca."));
 dett(h);status(tecs)}
function status(tecs){$("st").textContent=L.length+" lavori · "+Object.keys(tecs).length+(Object.keys(tecs).length===1?" tecnico":" tecnici");dirLabel()}
function dett(h){var d=$("det");d.textContent="";var r=L.filter(function(x){return x.u===F.sel})[0];
 if(!r&&h){d.append(macchina(h),el("p","st","Scegli un rapportino dall'elenco per aprirlo."));return}
 if(!r){d.append(el("p","empty",L.length?"Scegli un lavoro dall'elenco, oppure cerca una matricola o un codice impianto per vedere la scheda della macchina.":"Qui vedrai il rapportino, le matricole e le foto."));return}
 var s=r.s||{};d.append(el("h2",0,r.n||"Senza nome"),el("div","sub",TIT[r.v]+" · "+(stato(r)==="fatto"?"concluso":stato(r)==="corso"?"in corso":"in attesa")+" · archiviato il "+dIt(r.d)));
 var kv=el("dl","kv");function row(k,v){if(!v)return;kv.append(el("dt",0,k),el("dd",0,v))}
 row("Tecnico",r.tec);row("Data intervento",dLav(r));row("Cliente",g(s,"cl"));if(s.rv)row("Rivenditore",g(s,"rvn"));row("Sede",g(s,"se"));row("Riferimento",rif(r));row("Manodopera",g(s,"ore")?g(s,"ore")+(g(s,"ore")==="1"?" ora":" ore"):"");d.append(kv);
 d.append(el("h3",0,"Etichette"),tagRow("L",r.u),el("h3",0,"Mia nota"),noteBox("L",r.u,"Nota personale su questo lavoro (non modifica il rapportino)"));
 var M=mats(r);if(M.length){d.append(el("h3",0,"Matricole · scheda macchina"));var w=el("div","mats");M.forEach(function(m){var b=btn("mat",null,function(){apri(m.v)});b.append(el("i",0,m.k),document.createTextNode(m.v));var mt=(META.M[mk(m.v)]||{}).t||[];mt.forEach(function(id){var t=tagOf(id);if(t){var dd=el("i","dot");dd.style.background=t.c;dd.style.marginLeft="6px";dd.title=t.n;b.append(dd)}});w.append(b)});d.append(w)}
 if(r.nt){d.append(el("h3",0,"Note rapportino"));var p=el("pre","note",r.nt);d.append(p,btn("b sm","Copia note",function(e){var b=e.target;navigator.clipboard.writeText(r.nt).then(function(){b.textContent="Copiato";setTimeout(function(){b.textContent="Copia note"},1500)})}))}
 var nte=g(s,"nte");if(nte){d.append(el("h3",0,"Note tecniche"),el("pre","note",nte))}
 var P=(r.ph||[]).filter(function(f){return f&&typeof f.d==="string"&&f.d.indexOf("data:image/")===0});
 if(P.length){d.append(el("h3",0,"Foto · "+P.length));var ph=el("div","ph");P.forEach(function(f){var a=el("a");a.href="#";a.onclick=function(e){e.preventDefault();var wn=window.open();if(wn){wn.document.title=f.n||"foto";var im=wn.document.createElement("img");im.src=f.d;im.style.maxWidth="100%";wn.document.body.append(im)}};var im=document.createElement("img");im.src=f.d;im.alt=f.n||"";a.append(im,el("span",0,f.n||""));ph.append(a)});d.append(ph)}
 var det=el("details","raw");det.append(el("summary",0,"Tutti i dati della scheda"));var tb=el("table");Object.keys(s).sort().forEach(function(k){if(/^_/.test(k)||s[k]===""||s[k]===0||s[k]==null)return;var tr=el("tr");tr.append(el("td",0,k),el("td",0,typeof s[k]==="object"?JSON.stringify(s[k]):String(s[k])));tb.append(tr)});det.append(tb);d.append(el("h3",0,"Dettagli"),det)}

/* ---------- Excel (CSV con separatore ;) ---------- */
function oggi(){var n=new Date();return p2(n.getDate())+"-"+p2(n.getMonth()+1)+"-"+n.getFullYear()}
function scarica(blob,fn){var a=document.createElement("a"),u=URL.createObjectURL(blob);a.href=u;a.download=fn;document.body.append(a);a.click();a.remove();setTimeout(function(){URL.revokeObjectURL(u)},4000)}
function csv(){var R=filtrati();if(!R.length){say("Niente da esportare.",1);return}
 function q(v){v=String(v==null?"":v);return /[;"\n\r]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v}
 var H=["Data","Tipo","Stato","Tecnico","Cliente","Rivenditore","Sede","Riferimento","Matricole","Ore","Etichette","Mia nota","Nome lavoro","Note rapportino"],rows=[H.join(";")];
 R.forEach(function(r){var s=r.s||{};rows.push([dLav(r),TIT[r.v],stato(r)==="fatto"?"Concluso":stato(r)==="corso"?"In corso":"In attesa",r.tec,g(s,"cl"),s.rv?g(s,"rvn"):"",g(s,"se"),rif(r),mats(r).map(function(m){return m.v}).join(", "),g(s,"ore"),tagsL(r).map(function(id){return tagOf(id).n}).join(", "),(META.L[r.u]||{}).n||"",r.n,r.nt||""].map(q).join(";"))});
 scarica(new Blob(["﻿"+rows.join("\r\n")],{type:"text/csv"}),"Glory archivio - "+oggi()+".csv")}
function salvaTutto(){if(!L.length&&!META.tags.length){say("Archivio vuoto.",1);return}
 scarica(new Blob([JSON.stringify({gloryPc:1,saved:Date.now(),lav:L,meta:META})],{type:"application/json"}),"Glory archivio completo - "+oggi()+".json");say("Archivio salvato. Per ripristinarlo su questo o un altro PC usa Importa file.")}

/* ---------- avvio ---------- */
$("fi").onchange=function(){if(this.files.length)importa(this.files);this.value=""};
$("q").oninput=function(){F.q=this.value;F.sel=null;F.frq=0;draw()};
$("dirb").onclick=dirPick;$("sync").onclick=function(){dirSync()};$("csv").onclick=csv;$("tagb").onclick=tagEditor;$("bak").onclick=salvaTutto;
if(location.protocol==="chrome-extension:")$("extl").hidden=true;
document.addEventListener("keydown",function(e){if(e.key==="Escape"){var o=document.querySelector(".ov");if(o){o.remove();draw()}else if(HIST.length&&document.activeElement.tagName!=="INPUT"&&document.activeElement.tagName!=="TEXTAREA")back()}});
var dc=0;document.addEventListener("dragenter",function(e){e.preventDefault();dc++;$("drop").hidden=false});
document.addEventListener("dragleave",function(){if(--dc<=0){dc=0;$("drop").hidden=true}});
document.addEventListener("dragover",function(e){e.preventDefault()});
document.addEventListener("drop",function(e){e.preventDefault();dc=0;$("drop").hidden=true;if(e.dataTransfer.files.length)importa(e.dataTransfer.files)});
try{if(navigator.storage&&navigator.storage.persist)navigator.storage.persist()}catch(e){}
dbOpen().then(function(){return cfg("meta")}).then(function(m){META=m?metaFix(m):metaDef();if(!m)cfg("meta",META)}).then(dbAll).then(function(a){L=a;draw();return dirInit()}).then(draw).catch(function(){say("Questo browser non può salvare l'archivio: usa Chrome o Edge.",1)});

