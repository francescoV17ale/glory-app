
"use strict";
var app=document.getElementById("app"),ttl=document.getElementById("ttl"),back=document.getElementById("back");
var S={},view="",ui={},noteTa=null,bkMsg="",bkNext="",arcMsg="",topMsg="";
var CL=!!(window.claude&&typeof window.claude.use==="function"),SOLO=window.GLORY_SOLO||"",BASE=SOLO?"../":"";
/* solo tipi "documento": così Android apre l'elenco dei file e non la fotocamera */
var DOCACC=".txt,.json,text/plain,application/json,application/octet-stream";
function rui(){ui={phDel:null,phMsg:"",del:0,delSel:0,pd:0,pdSel:0,md:0,rst:0,notes:{},foc:null,help:{},dlg:null,bkPend:null,arc:0,ao:0,ad:0,ap:0,q:""}}
rui();

function el(t,c,x){var e=document.createElement(t);if(c)e.className=c;if(x!=null)e.textContent=x;return e}
function btn(c,x,fn){var b=el("button",c,x);b.type="button";b.onclick=fn;return b}
function p2(v){return v<10?"0"+v:""+v}
function C(id,x){return {t:"c",id:id,x:x}}
function G(id,x,o){return {t:"g",id:id,x:x,o:o}}
function H(x){return {t:"h",x:x}}
function H3(x){return {t:"h3",x:x}}
function T(id,x,a,area){return {t:"t",id:id,x:x,a:a,area:area}}
function RVC(){var c=C("rv","Tramite rivenditore");c.memo=1;return c}
function NT(){var t=T("nte","Note tecniche","Solo nel PDF, non nelle note per il rapportino",1);t.cmp=1;return t}
function grow(t){t.style.height="auto";t.style.height=Math.min(Math.max(t.scrollHeight+2,56),200)+"px"}
function UPD(s,id,x){var c=C(id,x);c.opt=1;return [c].concat(s[id]?[T(id+"_a","Versione precedente","Es. 1.2.3"),T(id+"_n","Versione installata ora","Es. 1.2.4")]:[])}
function GRM(){var c=C("grm","Genera RMA automaticamente");c.memo=1;return c}
var rmaEl=null;
function rmaGen(s){var src=crm((s.rv&&String(s.rvn||"").trim())?s.rvn:s.cl).n,
 l3=String(src||"").normalize("NFD").replace(/[̀-ͯ]/g,"").replace(/[^A-Za-z]/g,"").slice(0,3).toUpperCase(),
 num=[PX[s.r1_md],String(s.r1_mat||"").trim()].filter(Boolean).join("-"),er=String(s.r1_er||"").replace(/\s+/g,"").toUpperCase();
 return [l3,num,er].filter(Boolean).join("-")}
/* cronometro della manodopera: tmS = millisecondi già contati, tmA = avvio in corso (timestamp), tmF = fermato */
function tmMs(s){return (+s.tmS||0)+(s.tmA?Math.max(0,Date.now()-s.tmA):0)}
function tmFmt(ms){var m=Math.floor(ms/60000);return Math.floor(m/60)+":"+p2(m%60)}
function tmOre(ms){return String(Math.min(6,Math.max(1,Math.ceil(ms/3600000))))}
function tmHalt(s){if(s.tmA){s.tmS=tmMs(s);delete s.tmA}}
var tmIv=null;
function tmTick(){var e=document.getElementById("tmv");if(!e){clearInterval(tmIv);tmIv=null;return}e.textContent=tmFmt(tmMs(S))}
function DT(){return {t:"date",id:"dt",x:"Data intervento"}}
function dIt(iso){var m=/^(\d{4})-(\d\d)-(\d\d)$/.exec(iso||"");return m?m[3]+"/"+m[2]+"/"+m[1]:""}
var HELP={"rf": {"t": "Dove trovarlo · Codice chiamata o ticket", "l": ["Lo trovi nella chiamata aperta sul CRM."]}, "5": {"t": "Indirizzo IP", "l": ["Evita indirizzi nel range DHCP del router: potrebbero essere assegnati in seguito a un altro dispositivo.", "Prima di assegnarlo fai un ping: se qualcuno risponde, l'IP è già usato.", "Imposta l'IP prima di collegare la macchina alla rete del cliente."]}, "6": {"t": "Collegamento alla rete", "l": ["Fai un ping dal PC del gestionale verso l'IP della macchina.", "Se il ping non risponde: IP e subnet devono essere della stessa rete del gestionale, e l'IP non deve essere in conflitto con un altro dispositivo.", "Se il ping risponde ma il gestionale non comunica, su un'installazione nuova il problema è quasi sempre nel gestionale o nel firewall del PC.", "Più raro: memoria event dell'FCC satura. L'FCC tiene in memoria al massimo 5 collegamenti; oltre non ne accetta altri e le porte restano occupate."]}, "ct2": {"t": "Collegamento di rete", "l": ["Fai un ping dal PC del gestionale verso l'IP della macchina.", "Se il ping non risponde: IP e subnet devono essere della stessa rete del gestionale, e l'IP non deve essere in conflitto con un altro dispositivo.", "Se il ping risponde ma il gestionale non comunica, controlla gli event: l'FCC tiene in memoria al massimo 5 collegamenti e, se sono saturi, non ne accetta altri. Libera la memoria event e riprova.", "Se gli event sono a posto, il problema è nel gestionale o nel firewall del PC."]}, "7": {"t": "Interconnessione con il gestionale", "l": ["Se hai cambiato l'IP della macchina, aggiornalo anche nel gestionale.", "Nel gestionale controlla IP e porta impostati per la cassa automatica.", "Firewall o antivirus del PC del gestionale possono bloccare la comunicazione.", "Se tutto è impostato bene e ancora non comunica, controlla che la memoria event dell'FCC non sia satura (massimo 5 collegamenti)."]}, "4": {"t": "Accensione", "l": ["Uno sportello aperto o una valigetta non inserita bene possono bloccare l'avvio con un errore."]}, "ct1": {"t": "Alimentazione e cavi", "l": ["Collega direttamente alla presa a muro per escludere multipresa e UPS.", "Se c'è un UPS, verifica che non sia scarico o in allarme."]}, "8": {"t": "Deposito e prelievo", "l": ["Banconote: le cause principali di inceppamento, in inserimento o in erogazione, sono corpi estranei nel percorso e cinghie di trasporto logore. Controlla anche i sensori.", "Monete: verifica i sensori e cerca corpi estranei sul sensore di lega o nell'unità di trasporto.", "Se il prelievo non eroga e non c'è inceppamento, controlla che nei ricicli ci sia contante sufficiente."]}, "cnt": {"t": "Prova con il contante", "l": ["Banconote: controlla l'usura delle cinghie di trasporto (sulle macchine usate è la causa più frequente) e cerca corpi estranei nel percorso.", "Monete: verifica i sensori e cerca corpi estranei sul sensore di lega o nell'unità di trasporto.", "Se il prelievo non eroga e non c'è inceppamento, controlla che nei ricicli ci sia contante sufficiente."]}, "cfb": {"t": "Test con banconote", "l": ["Se la banconota si inceppa in inserimento o in erogazione: cerca corpi estranei nel percorso e controlla l'usura delle cinghie di trasporto.", "Banconote piegate o rovinate vengono rifiutate anche da una macchina sana."]}, "cfm": {"t": "Test con monete", "l": ["Se le monete vengono rifiutate o si bloccano: verifica i sensori e cerca corpi estranei sul sensore di lega o nell'unità di trasporto.", "Monete estere, deformate o sporche vengono rifiutate anche da una macchina sana."]}, "10": {"t": "Sensori e sportelli", "l": ["Con uno sportello aperto la macchina deve segnalarlo: se non lo fa, il sensore è sporco o scollegato."]}, "ss": {"t": "Sensori e sportelli", "l": ["Con uno sportello aperto la macchina deve segnalarlo: se non lo fa, il sensore è sporco o scollegato."]}, "s8": {"t": "Dip switch 8", "l": ["Sposta i dip switch solo a macchina spenta: la nuova posizione viene letta all'accensione.", "Se dopo il riavvio non cambia nulla, ricontrolla la posizione: è facile spostare quello accanto."]}, "ds8": {"t": "Dip switch 8", "l": ["Sposta i dip switch solo a macchina spenta: la nuova posizione viene letta all'accensione.", "Se dopo il riavvio non cambia nulla, ricontrolla la posizione: è facile spostare quello accanto."]}, "ds4": {"t": "Dip switch 4", "l": ["Sposta i dip switch solo a macchina spenta: la nuova posizione viene letta all'accensione.", "Se dopo il riavvio non cambia nulla, ricontrolla la posizione: è facile spostare quello accanto."]}, "sd": {"t": "Diverter", "l": ["Dopo il settaggio fai una prova di deposito e guarda dove finisce il contante: se va nel posto sbagliato, il diverter è bloccato o settato male."]}, "dvB": {"t": "Diverter", "l": ["Dopo il settaggio fai una prova di deposito e guarda dove finisce il contante: se va nel posto sbagliato, il diverter è bloccato o settato male."]}, "b0": {"t": "Licenza SNG Cloud", "l": ["Controlla cliente e CV, e che le postazioni della licenza coprano server e client indicati sopra.", "Se è errata, falla correggere prima di installare: dopo è più complicato."]}, "bsrv": {"t": "Postazione server SNG", "l": ["Il server deve stare nella stessa rete della macchina.", "Se il servizio SNG non parte, controlla che l'antivirus non lo blocchi."]}, "bcli": {"t": "Postazione client SNG", "l": ["Imposta l'indirizzo del server SNG e verifica con un ping che il client lo raggiunga."]}, "bc": {"t": "Configurazione SNG", "l": ["Dopo aver inserito IP della macchina e licenza, verifica che SNG veda la cassa e i livelli prima di consegnare."]}, "g11": {"t": "App SNG Cloud", "l": ["Accedi con account e credenziali del cliente, non con le tue."]}, "g13": {"t": "Cash Tools", "l": ["Se non si collega alla macchina, controlla antivirus e firewall del PC."]}, "cabb": {"t": "Cablaggio", "l": ["Se il modulo non viene riconosciuto, prova un'altra porta o un altro cavo USB."]}, "cabm": {"t": "Cablaggio", "l": ["Se il modulo non viene riconosciuto, prova un'altra porta o un altro cavo USB."]}, "dg": {"t": "Downgrade FCC", "l": ["Non spegnere e non scollegare nulla durante il downgrade.", "Se non va a buon fine, riavvia e ripeti dall'inizio."]}, "bk": {"t": "Backup di configurazione", "l": ["Usa il backup del modello e del tipo di installazione giusti: uno sbagliato carica parametri errati."]}, "er": {"t": "Codice errore", "l": ["Cercalo nella documentazione Glory per capire la causa.", "Se dopo un reset il codice cambia, annota anche il nuovo."]}, "sur": {"t": "Dove si imposta · Surplus (fondo cassa)", "l": ["Si imposta dalla web app, nella sezione Watermark."]}, "f1": {"t": "Cosa illustrare · Formazione al cliente", "l": ["Procedura di estrazione della valigetta.", "Svuotamento dell'overflow monete.", "Come liberare un inceppamento semplice di banconote o monete.", "Dove trovare l'adesivo con il codice di assistenza e i contatti per le chiamate."]}};
function helpKey(id){var m;if(m=/^bsv\d+$/.exec(id))return "bsrv";if(/^bcl\d+$/.test(id))return "bcli";if(/^dg\d*$/.test(id))return "dg";if(/^bk\d*$/.test(id))return "bk";if(/^tst\d*$/.test(id))return "tst";if(id==="rf"&&view!=="loc")return "";return id.replace(/^d\d+_/,"").replace(/^r\d_/,"")}
function helpOf(id){return HELP[helpKey(id)]||null}
function helpBox(id){var h=helpOf(id),bx=el("div","hlp"),u=el("ul");bx.setAttribute("role","note");bx.append(el("b",0,(/^(Dove (trovarlo|si imposta)|Cosa illustrare)/.test(h.t)?"":"Se non va · ")+h.t));h.l.forEach(function(t){u.append(el("li",0,t))});bx.append(u);return bx}
function helpBtn(id){var b=btn("nb hb"+(ui.help[id]?" has":""),"?",function(){ui.help[id]=!ui.help[id];render()});b.setAttribute("aria-label","Aiuto: "+helpOf(id).t);b.setAttribute("aria-expanded",ui.help[id]?"true":"false");return b}
function TEC(){return T("tec","Tecnico","Nome del tecnico che esegue l'intervento")}

/* ---------- schede ---------- */
var PX={"CI-5":"50","CI-10":"100","CI-10X":"200"};
var V={
inst:{title:"Installazione",blocks:function(s){
 var n=devN(s),b=[TEC(),DT(),T("cv","CV","Codice contratto"),RVC()].concat(s.rv?[T("rvn","Rivenditore","Nome rivenditore")]:[],[T("cl","Cliente","Nome cliente"),T("se","Sede","Sede"),H("Contratto"),{t:"sw"},G("mon","Monitor presente",["Sì","No"])]),i;
 b.push({t:"cnt"});
 var swo=s.bo==="Sì"||(s.app&&s.sng!=="Android");
 if(!n&&!swo){b.push({t:"tip",x:"Aggiungi almeno un dispositivo (CI-5, CI-10 o CI-10X) per vedere le fasi dell'installazione. Per installare solo il software accendi SNG Cloud o App SNG Cloud."},NT(),{t:"n"});return b}
 if(!n)b.push({t:"tip",x:"Nessun dispositivo: installazione del solo software."});
 if(n||s.bo==="Sì")b.push(H("Prima di iniziare"));
 if(n){["Sito e punto di installazione verificati","Adesivi in dotazione (codice assistenza e contatti azienda)","Dotazione verificata (cavi, chiavi, manuali)","Pre-configurazione di magazzino verificata","Matricole comunicate al Magazzino","DDT ricevuto","Cliente contattato: punto di installazione predisposto (prese elettriche adeguate, rete attiva e presente)"].forEach(function(t,k){b.push(C("p"+k,t))});
 var cr=C("car","Carrettino trasporto Glory");cr.memo=1;b.splice(b.length-7,0,cr)}
 if(s.bo==="Sì")b.push(C("b1","Cliente contattato per informazioni su SNG Cloud e postazioni"),{t:"num",id:"nsv",x:"Postazioni server SNG",max:5},{t:"num",id:"ncl",x:"Postazioni client SNG",max:20},C("b0","Licenza SNG Cloud creata correttamente"))
 function DL(i){var m=s["m"+i];return "Dispositivo "+i+(m?" · "+m:"")}
 if(n){
  b.push(H("Installazione hardware"));
  for(i=1;i<=n;i++){var k="d"+i+"_";b.push(H3(DL(i)),C(k+"1","Posizionamento e ancoraggio"),C(k+"2","Cablaggio e alimentazione dispositivo"));if(s.mon!=="No")b.push(C(k+"3","Cablaggio e alimentazione monitor"));b.push(C(k+"4","Avvio e verifica accensione"))}
  b.push(H("Configurazione"));
  for(i=1;i<=n;i++){var k="d"+i+"_";b.push(H3(DL(i)),C(k+"5","Indirizzo IP impostato"),C(k+"6","Collegato alla rete del cliente"),C(k+"7","Interconnessione con il gestionale verificata"))}
  b.push(H3("Software di servizio"));
  if(s.bo!=="Sì"&&s.app&&s.sng!=="Android")b.push(C("g11","App SNG Cloud installata"));
  b.push(C("g12","Cartella assistenza Glory trasferita"),C("g13","Cash Tools installato"));
  b.push(H("Collaudo"));
  for(i=1;i<=n;i++){var k="d"+i+"_";b.push(H3(DL(i)));if(s["m"+i]==="CI-5")b.push(C(k+"s8","Dip switch 8 verificato"),C(k+"sd","Verificati diverter"),C(k+"sv","Verificato sensore valigetta"));
   b.push(C(k+"8","Test di deposito e prelievo"),C(k+"9","Test trasferimento e azzeramento livelli valigetta"),C(k+"10","Sensori e sportelli verificati"))}
  b.push(H("Adesivi e codice impianto"),C("adx","Adesivi di assistenza applicati ai dispositivi"),C("mtx","Codice impianto applicato"));
 }
 else if(s.bo!=="Sì"&&s.app&&s.sng!=="Android")b.push(H("Software"),C("g11","App SNG Cloud installata"));
 if(s.bo==="Sì"){var ns=+s.nsv||0,nc=+s.ncl||0,q;b.push(H("SNG Cloud"));
  if(!ns&&!nc)b.push(C("bi","Software installato"),C("bc","Software configurato"));
  for(q=1;q<=ns;q++)b.push(C("bsv"+q,q===1&&nc?"Server + client 1 (stesso PC): SNG installato e configurato":"Server "+q+": SNG installato e configurato"));
  for(q=(ns?2:1);q<=nc;q++)b.push(C("bcl"+q,"Client "+q+": SNG installato e configurato"));
  b.push(C("bs","Cliente istruito sul software"))}
 b.push(H("Consegna"));
 if(n)b.push(G("sur","Surplus (fondo cassa): il cliente lo vuole? Se sì, impostalo",["Sì, impostato","No"]));
 if(n)b.push(C("f1","Eseguita formazione"),C("f2","Imballi puliti e ritirati"),C("f3","Chiavi e staffe di fissaggio consegnate"),T("ric","Chiavi consegnate a","Es. sig. Mario Rossi"),(function(){var t=T("altm","Altro materiale fornito o installato","Facoltativo · es. switch di rete, multipresa");t.opt=1;return t})());
 b.push(C("f4","Firma del cliente sul rapporto"),NT(),{t:"n"});
 return b}},
prep:{title:"Preparazione macchine",blocks:function(s){
 var b=[TEC(),DT(),T("cvc","CV","Codice contratto"),G("m","Modello",["CI-5","CI-10","CI-10X"])];
 if(!s.m)return b;
 var c5=s.m==="CI-5";
 if(!c5){b.push(G("bt","Tipo di basamento a contratto",["Standard","Altro"]));if(s.bt==="Altro")b.push(T("bto","Specifica il basamento","Descrizione"))}
 var pm=prepMode(s),full=!c5||pm==="Completa",k=1,pf=PX[s.m]?"R":"",t1;
 if(!c5)b.push(G("mon","Monitor presente nel contratto",["Sì","No"]));
 else{b.push(G("pt","Tipo di preparazione",["Downgrade CI-5","Completa"]));
  if(!pm)return b;
  if(pm==="Completa"){t1=T("mtB","Matricola modulo banconote RBW50-","Numero di matricola");t1.opt=1;b.push(t1);
   t1=T("mtM","Matricola modulo monete RCW50-","Numero di matricola");t1.opt=1;b.push(t1);
   t1=T("mtD","Codice impianto","Codice impianto");t1.opt=1;b.push(t1);
   b.push(G("mon","Monitor presente nel contratto",["Sì","No"]))}
  }
 if(full){b.push(H(k++ +" · Hardware"));
  if(c5){
   b.push(H3("Modulo banconote"),C("nasB","Rimossi i nastri di protezione"),C("dvB","Eseguito settaggio dei diverter"),C("svB","Verificato sensore valigetta"),C("azB","Eseguito azzeramento valigetta"),C("adB","Adesivo BANCONOTE"));
   b.push(H3("Modulo monete"),C("nas","Rimossi i nastri di protezione"),C("ds8","Dip switch 8 impostato"),C("adM","Adesivo MONETE"))}
  else{[["b","banconote"],["m","monete"]].forEach(function(p){var k2=p[0],n=p[1];
   b.push(H3("Modulo "+n),C("bas"+k2,"Basamento collegato"),C("nas"+k2,"Rimossi i nastri di protezione"),G("val"+k2,"Valigetta "+n,["Standard","Motorizzata"]),C("cab"+k2,"Eseguito cablaggio: alimentazione e USB"),C("ad"+k2,"Adesivo "+n.toUpperCase()))});
   b.push(G("fw","Firmware modulo monete versione 47",["Sì","No"]));if(s.fw==="Sì")b.push(C("ds4","Dip switch 4 impostato"))}}
 if(c5&&pm==="Downgrade CI-5"){var nd=+s.dn||1,dd,c1;
  for(dd=1;dd<=nd;dd++){t1=T(mrk(dd),(nd>1?"Dispositivo "+dd+" · matricola ":"Matricola modulo monete ")+"RCW50-","Numero di matricola");t1.opt=1;b.push(t1);
   c1=C(dgk(dd),"Eseguito downgrade FCC");c1.dv=dd;b.push(c1);c1=C(bkk(dd),"Caricato backup di configurazione base");c1.dv=dd;b.push(c1);c1=C(tsk(dd),"Eseguito test di configurazione");c1.dv=dd;b.push(c1)}
  b.push({t:"addm"},{t:"delm"})}
 else b.push(H(k++ +" · Configurazione software"),C("fcc","FCC alimentato a macchina assemblata"),C("dg",c5?"Eseguito downgrade FCC (modulo monete)":"Eseguito downgrade FCC (su basamento modulo banconote)"),C("bk","Caricato backup di configurazione base FCC"),C("tst","Eseguito test di configurazione"));
 if(!(c5&&!full))b.push(H(k++ +" · Chiusura"));
 if(c5&&!full){t1=C("imb",(+s.dn||1)>1?"Moduli reimballati con nastro SNG":"Modulo monete reimballato con nastro SNG");t1.pl="Reimballo eseguito";b.push(t1);t1=C("ass","Associato a modulo banconote imballato");t1.opt=1;b.push(t1)}
 else{if(full){var kc=c5?"rosse e gialle":"rosse, gialle e blu",kt=C("chv","Chiavi macchina ("+kc+")"+(s.mon==="Sì"?" inserite nella scatola del monitor":""));b.push(kt);
   if(s.mon!=="Sì"){t1=T("chp","Dove sono state messe le chiavi","Es. nella valigetta banconote");t1.opt=1;b.push(t1)}}
  b.push(C("imb","Reimballo eseguito"));
  if(c5)b.push(C("cv","Cavi di alimentazione e rete inseriti nell'imballo"));
  else if(s.mon==="Sì")b.push(C("hd","Cavo HDMI 3 m inserito nell'imballo"),C("et","Cavo Ethernet (min. 3 m) inserito nell'imballo"))}
 b.push(NT());
 return b}},
rip:{title:"Riparazioni in laboratorio",blocks:function(s){
 var rn=+s.rn||1,AS=ripAs(s),i,b=[TEC(),DT(),{t:"tmr"},RVC()].concat(s.rv?[T("rvn","Rivenditore","Nome rivenditore")]:[],[T("cl","Cliente","Nome cliente"),GRM(),T("rma","RMA","Codice RMA"),(function(){var t=T("cv","CV","Facoltativo · se manca l'RMA");t.opt=1;return t})()]);
 for(i=1;i<=rn;i++){var p="r"+i+"_",mi=modInfo(s,p);
  if(AS&&i===2){b.push(H("Modulo associato · "+mi.n+" · revisione"),T(p+"mat","Matricola"+(mi.sig?" "+mi.sig:""),"Numero di matricola"),H3("Revisione"),C(p+"pl","Pulizia completa del modulo eseguita"),C(p+"ss","Sensori e sportelli verificati"),G(p+"pp","Problema rilevato durante la revisione",["No","Sì"]));
   if(s[p+"pp"]==="Sì"){b.push(T(p+"er","Codice errore","Es. 1234"),T(p+"pb","Problematica riscontrata","Descrivi il problema",1));
    for(var qi=1;qi<=(+s[p+"np"]||0);qi++)b.push(T(p+"pz"+qi,"Pezzo sostituito "+qi,"Quale pezzo"));
    b.push({t:"addp",p:p},{t:"delp",p:p},T(p+"pr","Interventi eseguiti","Descrivi gli interventi",1))}
   b.push(H3("Aggiornamenti"));b=b.concat(UPD(s,p+"ucp","Aggiornamento firmware CPU"));if(mi.t!=="C")b=b.concat(UPD(s,p+"ubv","Aggiornamento BV (lettore banconote)"));
   b.push({t:"mod"});continue}
  b.push(H("Modulo "+(AS?"":i)+(mi.t?(AS?"":" · ")+mi.n+(mi.m?" · "+mi.m:""):"")),G(p+"tp","Tipo di modulo",["Banconote","Monete"]),G(p+"md","Modello",["CI-5","CI-10","CI-10X"]),T(p+"mat","Matricola"+(mi.sig?" "+mi.sig:""),"Numero di matricola"));
  if(i===1&&rn===1&&mi.t)b.push({t:"mod"});
  b.push(H3("Diagnosi e intervento"),T(p+"er","Codice errore","Es. 1234"),T(p+"pb","Problematica riscontrata","Descrivi il problema",1));
  for(var pi=1;pi<=(+s[p+"np"]||0);pi++)b.push(T(p+"pz"+pi,"Pezzo sostituito "+pi,"Quale pezzo"));
  b.push({t:"addp",p:p},{t:"delp",p:p},T(p+"pr","Interventi eseguiti","Descrivi gli interventi (es. rimozione corpo estraneo, disassemblaggio)",1),
   H3("Aggiornamenti"));
  b=b.concat(UPD(s,p+"ucp","Aggiornamento firmware CPU"));
  if(mi.t!=="C")b=b.concat(UPD(s,p+"ubv","Aggiornamento BV (lettore banconote)"));
  if(!AS)ripEnd(b,s,p,H3("Test"),"Prova con "+(mi.t==="C"?"monete":mi.t==="B"?"banconote":"contante"))}
 if(AS)ripEnd(b,s,"r1_",H("Collaudo · entrambi i moduli"),"Prova con banconote e monete");
 if(!AS&&rn>1)b.push({t:"mod"});
 b.push(NT(),H("Manodopera"),{t:"sel",id:"ore",x:"Manodopera (ore)",o:["1","2","3","4","5","6"]},{t:"n"});
 return b}},
loc:{title:"Interventi in loco",blocks:function(s){
 var U=locUnits(s),i,fl=C("fl","Contratto full: aggiornamenti inclusi");fl.memo=1;
 var b=[TEC(),DT(),{t:"tmr"},T("rf","Riferimento intervento","Codice chiamata o ticket"),RVC()].concat(s.rv?[T("rvn","Rivenditore","Nome rivenditore")]:[],[T("cl","Cliente","Nome cliente"),T("se","Sede","Sede"),fl,
  H("Dispositivo"),G("sc","Intervento su",["Modulo banconote","Modulo monete","Entrambi i moduli","Pulizia e revisione","Dispositivo / altro"]),G("md","Modello dispositivo",["CI-5","CI-10","CI-10X"]),T("mt","Codice impianto","Facoltativo")]);
 if(s.sc==="Dispositivo / altro"){var si=0;b.forEach(function(x,k){if(x.id==="sc")si=k});b.splice(si+1,0,T("sp","Specifica","Es. monitor, stampante, PC"))}
 U.forEach(function(u){if(u.m)b.push(T(u.p+"mat","Matricola "+u.n+(u.sig?" "+u.sig:""),"Numero di matricola"))});
 b.push(H("Controlli preliminari"),G("ct1","Alimentazione e cavi",["OK","Problema"]),G("ct2","Collegamento di rete",["OK","Problema"]));
 if(locPre(s)){b.push(H("Problema nei controlli preliminari"),T("ppb","Problematica riscontrata","Descrivi il problema",1),T("ppr","Interventi eseguiti","Cosa è stato fatto",1),G("pes","Esito",["Risolto","Non risolto"]));
  if(s.pes!=="Risolto"){if(s.pes==="Non risolto")b.push(G("pde","Destinazione",["Ritiro per riparazione in laboratorio","Nuovo intervento"]));
   b.push({t:"tip",x:"Finché il problema dei controlli preliminari non è risolto non si passa all'analisi dei moduli."},NT(),H("Manodopera"),{t:"sel",id:"ore",x:"Manodopera (ore)",o:["1","2","3","4","5","6"]},{t:"n"});return b}}
 var PUL=s.sc==="Pulizia e revisione";
 if(U.length)b.push(H(PUL?"Pulizia e revisione":"Analisi dei moduli"));
 if(PUL)b.push({t:"tip",x:"Pulizia e revisione di entrambi i moduli. Se dopo la pulizia un modulo presenta un problema, segna «Sì» e compila l'intervento su quel modulo."});
 U.forEach(function(u){var p=u.p;
  b.push(H3(u.l));
  if(PUL){b.push(C(p+"pl","Pulizia completa del modulo eseguita"),C(p+"ss","Sensori e sportelli verificati"),G(p+"pp","Problema rilevato dopo la pulizia",["No","Sì"]));if(s[p+"pp"]!=="Sì")return;b.push(H3(u.l+" · intervento"))}
  else if(u.m)b.push(C(p+"ss","Sensori e sportelli verificati"));
  b.push(T(p+"er","Codice errore","Es. 1234"),T(p+"pb","Problematica riscontrata","Descrivi il problema",1),T(p+"pr","Interventi eseguiti","Descrivi gli interventi (anche pezzi riparati in loco)",1));
  for(var pi=1;pi<=(+s[p+"np"]||0);pi++)b.push(T(p+"pz"+pi,"Pezzo sostituito "+pi,"Quale pezzo"));
  b.push({t:"addp",p:p},{t:"delp",p:p})});
 b.push(H("Aggiornamenti"));
 var LU=locUpd(s);
 if(LU.B){b.push(H3("Modulo banconote"));b=b.concat(UPD(s,"ubc","Aggiornamento firmware CPU"),UPD(s,"ubb","Aggiornamento BV (lettore banconote)"))}
 if(LU.C){b.push(H3("Modulo monete"));b=b.concat(UPD(s,"umc","Aggiornamento firmware CPU"))}
 b.push(H3("FCC"));b=b.concat(UPD(s,"ufc","Aggiornamento FCC"));
 if(U.length){var rv=C("rev","Pulizia e revisione del dispositivo"),MD=U.filter(function(u){return u.m});rv.opt=1;b.push(H("Collaudo finale"));if(!PUL)b.push(rv);
  b.push(C("cfa","Test di accensione"),C("cfr","Reset"));
  if(U.some(function(u){return u.t==="B"}))b.push(C("cfb","Test con banconote"));
  if(U.some(function(u){return u.t==="C"}))b.push(C("cfm","Test con monete"));
  if(!MD.length)b.push(C("cft","Test di funzionamento"));
  b.push(G("cfe","Esito",["Tutto OK","Problematica rilevata"]));
  if(s.cfe==="Problematica rilevata"){if(MD.length>1)b.push(G("cfq","Su quale modulo",["Modulo banconote","Modulo monete","Entrambi"]));
   b.push(G("cfx","Problematica",["Risolta","Non risolta"]));if(s.cfx==="Non risolta")b.push(G("cfd","Destinazione",["Ritiro per riparazione in laboratorio","Nuovo intervento"]))}}
 b.push(NT(),H("Manodopera"),{t:"sel",id:"ore",x:"Manodopera (ore)",o:["1","2","3","4","5","6"]},{t:"n"});
 return b}},
rit:{title:"Ritiro dispositivo",blocks:function(s){
 var LOC=s.dv==="In loco",MAG=s.dv==="In magazzino",n=devN(s),b=[TEC(),DT(),{t:"tmr"},G("dv","Dove",["In loco","In magazzino"]),T("rf","Riferimento","CV, ticket o RMA"),RVC()].concat(s.rv?[T("rvn","Rivenditore","Nome rivenditore")]:[],[T("cl","Cliente","Nome cliente")]);
 if(LOC)b.push(T("se","Sede","Sede"));
 b.push(G("mo","Motivo",["Dismissione","Sostituzione","Furto","Danneggiata","Altro"]));
 if(s.mo==="Altro")b.push(T("mos","Specifica il motivo","Descrivi"));
 b.push(H("Dispositivi ritirati"),{t:"cnt"});
 if(LOC)b.push(H("Ritiro dal cliente"),C("w1","Dispositivo scollegato da alimentazione e rete"),C("w2","Contante rimosso e valigette svuotate in presenza del cliente"),C("w3","Chiavi ritirate"));
 if(MAG)b.push(H("Ricezione in magazzino"),G("imb","Imballo ricevuto integro",["Sì","No"]));
 b.push(H("Stato del dispositivo"),G("dn","Danni riscontrati",["No","Sì"]));
 if(s.dn==="Sì")b.push(T("dnd","Descrizione dei danni","Descrivi i danni (le foto si allegano in fondo)",1));
 if(LOC)b.push(H("Firma"),C("w4","Firma del cliente sul rapporto"));
 b.push(NT(),H("Manodopera"),{t:"sel",id:"ore",x:"Manodopera (ore)",o:["1","2","3","4","5","6"]},{t:"n"});
 return b}},
altro:{title:"Altre attività",blocks:function(s){
 var b=[TEC(),DT(),{t:"tmr"},G("tp","Tipo di attività",["Installazione","Riparazione","Altro"]),G("rf","Riferimento",["CV","RMA"])];
 if(s.rf)b.push(T("rc",s.rf,"Codice "+(s.rf==="CV"?"contratto":"RMA")));
 b.push(T("ti","Titolo","Es. Installazione blindatura"),T("mt","Modello","Facoltativo"),T("ma","Matricola","Facoltativo"),
  T("de","Descrizione dell'intervento","Descrivi cosa è stato fatto",1),G("es","Esito",["Eseguito","Non eseguito"]),NT(),H("Manodopera"),{t:"sel",id:"ore",x:"Manodopera (ore)",o:["1","2","3","4","5","6"]},{t:"n"});
 return b}}
};
var NEWS=[["inst","Installazione"],["prep","Preparazione macchine"],["rip","Riparazione in laboratorio"],["loc","Intervento in loco"],["altro","Altra attività"],["rit","Ritiro dispositivo"]];

/* ---------- salvataggio della scheda in corso (solo su questo dispositivo) ---------- */
var LS=null;
try{localStorage.setItem("gla_t","1");localStorage.removeItem("gla_t");LS=localStorage}catch(e){}
function lsGet(k){try{return LS?LS.getItem(k):null}catch(e){return null}}
var VER=88,svEl=null;
function svWarn(on){if(!svEl){if(!on)return;svEl=document.createElement("div");svEl.setAttribute("role","alert");svEl.textContent="Salvataggio non riuscito: i dati di questa scheda non sono al sicuro. Salva un backup o genera il PDF adesso.";svEl.style.cssText="position:fixed;left:0;right:0;bottom:0;z-index:50;padding:12px 16px;background:#b3261e;color:#fff;font-weight:600;font-size:15px";document.body.appendChild(svEl)}svEl.hidden=!on}
function lsSet(k,v){try{if(LS){LS.setItem(k,v);svWarn(0)}}catch(e){svWarn(1)}}
function tecRm(){return lsGet("gla_tecrm")!=="0"}
function load(v){var s=null;try{s=JSON.parse(lsGet("gla_"+v))}catch(e){}if(!s||typeof s!=="object"||Array.isArray(s))s={};mig(v,s);if(!s.tec&&tecRm()){var tc=lsGet("gla_tec");if(tc)s.tec=tc}return s}
function migInst(s){["11","12","13"].forEach(function(x){var re=new RegExp("^d\\d+_"+x+"$");if(s["g"+x]==null&&Object.keys(s).some(function(k){return re.test(k)&&s[k]}))s["g"+x]=1})}
function migLoc(s){if(s.sc!=="Modulo monete"||Object.keys(s).some(function(k){return /^(nt_)?r2_/.test(k)}))return;
 Object.keys(s).forEach(function(k){var m=/^(nt_)?r1_(.+)$/.exec(k);if(m){s[(m[1]||"")+"r2_"+m[2]]=s[k];delete s[k]}})}
function migRip(s){[1,2].forEach(function(i){var p="r"+i+"_";if(!s[p+"es"]){if(s[p+"ok"])s[p+"es"]="Riparato";else if(s[p+"nr"])s[p+"es"]="Non riparabile"}})}
function mig(v,s){if(v==="inst")migInst(s);if(v==="loc")migLoc(s);if(v==="rip")migRip(s);return s}
function save(){if(view){if(!S.dt&&hasData(S))S.dt=day();lsSet("gla_"+view,JSON.stringify(S));if(passi())chrome()}}

/* ---------- testi per il rapportino ---------- */
var DLP=null;
try{if(CL)window.claude.use("downloads").then(function(d){DLP=d||null},function(){})}catch(e){}
function prepMode(s){return s.pt==="Downgrade FCC"?"Downgrade CI-5":(s.pt||(s.cfull?"Completa":""))}
function mrk(i){return i===1?"mtM":"mtM"+i}
function dgk(i){return i===1?"dg":"dg"+i}
function bkk(i){return i===1?"bk":"bk"+i}
function tsk(i){return i===1?"tst":"tst"+i}
function dgCount(){return +S.dn||1}
function mnorm(v){return String(v||"").replace(/\s+/g,"").toUpperCase()}
function mIdx(id){return id==="mtM"?1:+id.slice(3)}
function dupOf(id,val){var v=mnorm(val),n=+S.dn||1,k,me=mIdx(id);if(!v)return 0;for(k=1;k<=n;k++)if(k!==me&&mnorm(S[mrk(k)])===v)return k;return 0}
function delRow(j){var n=+S.dn||1,i,f=[mrk,dgk,bkk,tsk];for(i=j;i<n;i++)f.forEach(function(g){if(S[g(i+1)])S[g(i)]=S[g(i+1)];else delete S[g(i)]});f.forEach(function(g){delete S[g(n)]});S.dn=Math.max(1,n-1);save()}
function prepMat(k){var pf={mtM:"RCW50-",mtB:"RBW50-"}[k],v=String(S[k]||"").trim();return v?pf+v:""}
function modInfo(s,p){var t=s[p+"tp"]==="Banconote"?"B":s[p+"tp"]==="Monete"?"C":"",m=s[p+"md"]||"",n=PX[m]||"",sg=t&&n?"R"+t+"W"+n+"-":"";
 return {t:t,n:t==="B"?"banconote":t==="C"?"monete":"",m:m,sig:sg,full:sg+(s[p+"mat"]||"…")}}
function verT(s,id){var a=String(s[id+"_a"]||"").trim(),n=String(s[id+"_n"]||"").trim();return n?(a?" (da "+a+" a "+n+")":" (versione "+n+")"):(a?" (da "+a+")":"")}
/* modulo associato: l'altro modulo della stessa macchina, revisionato; collaudo unico */
/* mail al magazzino: il minimo per la spedizione. Il codice CRM è il prefisso del nome cliente */
function crm(t){var m=/^\s*([A-Za-z]{0,4}\d[\w.\/]*)\s*[-–—:·,]?\s+(.+)$/.exec(String(t||""));return m?{c:m[1],n:m[2].trim()}:{c:"",n:String(t||"").trim()}}
function magMail(s){var o=[],cl=crm(s.cl),rv=s.rv?crm(s.rvn):null,ss=[],i,t,v=view;
 function L(k,x){x=String(x==null?"":x).trim();if(x)o.push(k+": "+x)}
 function pz(p){var q=[],j;for(j=1;j<=(+s[p+"np"]||0);j++)if(String(s[p+"pz"+j]||"").trim())q.push(String(s[p+"pz"+j]).trim());return q}
 function cli(){L("Codice cliente",cl.c);L("Cliente",cl.n);if(rv)L("Rivenditore",(rv.c?rv.c+" ":"")+rv.n)}
 function devs(){var n=devN(s);for(i=1;i<=n;i++){var px=PX[s["m"+i]]||"";o.push("Dispositivo"+(n>1?" "+i:"")+": Glory "+(s["m"+i]||"…")+" · RBW"+px+"-"+(String(s["a"+i]||"").trim()||"…")+" · RCW"+px+"-"+(String(s["c"+i]||"").trim()||"…")+(String(s["mt"+i]||"").trim()?" · impianto "+String(s["mt"+i]).trim():""))}}
 var sp={"Cliente":"al cliente","Rivenditore":"al rivenditore","Tecnico di zona":"al tecnico di zona"};
 if(v==="rip"){var A=ripAs(s),M=[modInfo(s,"r1_")].concat(A?[modInfo(s,"r2_")]:[]),es=s.r1_es,de=s.r1_de;
  ss=[es==="Riparato"?"Riparato":es==="Non riparabile"?"Non riparabile":"Riparazione",s.rma?"RMA "+String(s.rma).trim():s.cv?"CV "+String(s.cv).trim():""];
  o.push(es==="Riparato"?"la macchina è stata riparata"+(de==="Spedizione"?" ed è pronta per la spedizione.":"."):es==="Non riparabile"?"la macchina non è riparabile.":"aggiornamento sulla riparazione.","");
  cli();L("RMA",s.rma);if(!s.rma)L("CV",s.cv);o.push("Dispositivo: Glory "+(M[0].m||"…")+" · "+M.map(function(m){return m.full}).join(" · "));
  t=pz("r1_").concat(A?pz("r2_"):[]);if(t.length)L("Pezzi sostituiti",t.join(", "));
  if(es==="Riparato"&&de){L("Destinazione",de==="Spedizione"?"spedizione"+(s.r1_sp?" "+sp[s.r1_sp]:""):de.toLowerCase());if(de==="Spedizione")L("Indirizzo di spedizione",String(s.r1_spa||"").trim()||"…")}}
 else if(v==="inst"){ss=["Installazione",s.cv?"CV "+String(s.cv).trim():""];o.push(s.f4?"installazione completata.":"installazione.","");cli();L("CV",s.cv);L("Sede",s.se);devs();if(String(s.altm||"").trim())L("Materiale fornito",s.altm)}
 else if(v==="loc"){var U=locUnits(s),dest=s.cfd||(s.pes==="Non risolto"?s.pde:"");ss=["Intervento in loco",s.rf?"rif. "+String(s.rf).trim():""];
  o.push(dest==="Ritiro per riparazione in laboratorio"?"dispositivo da ritirare per riparazione in laboratorio.":dest==="Nuovo intervento"?"serve un nuovo intervento.":s.cfe==="Tutto OK"?"intervento concluso, dispositivo operativo.":"intervento in loco.","");
  cli();L("Riferimento",s.rf);L("Sede",s.se);o.push("Dispositivo: Glory "+(s.md||"…")+U.filter(function(u){return u.m}).map(function(u){return " · "+u.full}).join("")+(String(s.mt||"").trim()?" · impianto "+String(s.mt).trim():""));
  t=[];U.forEach(function(u){t=t.concat(pz(u.p))});if(t.length)L("Pezzi sostituiti",t.join(", "))}
 else if(v==="prep"){var c5=s.m==="CI-5"&&prepMode(s)==="Downgrade CI-5";ss=["Preparazione "+(s.m||""),s.cvc?"CV "+String(s.cvc).trim():c5?"downgrade":""];
  o.push(s.imb?(c5?"moduli pronti e reimballati.":"macchina pronta e reimballata."):"preparazione in corso.","");L("CV",s.cvc||"da associare");L("Modello",s.m+(c5?" · downgrade FCC":""));
  if(c5){for(i=1;i<=(+s.dn||1);i++)if(String(s[mrk(i)]||"").trim())o.push("Modulo monete "+i+": RCW50-"+String(s[mrk(i)]).trim())}
  else{L("Matricola banconote",prepMat("mtB"));L("Matricola monete",prepMat("mtM"));L("Codice impianto",s.mtD);L("Monitor",s.mon);L("Chiavi",s.mon==="Sì"?"nella scatola del monitor":s.chp)}}
 else if(v==="rit"){ss=["Ritiro dispositivo",s.dv?String(s.dv).toLowerCase():""];o.push((s.dv==="In magazzino"?"dispositivo ricevuto in magazzino":"dispositivo ritirato dal cliente")+(s.mo?" · motivo: "+(s.mo==="Altro"&&s.mos?s.mos:s.mo).toLowerCase():"")+".","");
  cli();L("Riferimento",s.rf);if(s.dv==="In loco")L("Sede",s.se);devs();if(s.dv==="In magazzino"&&s.imb)L("Imballo integro",s.imb);L("Danni",s.dn==="Sì"?(String(s.dnd||"").trim()||"sì"):s.dn==="No"?"nessuno":"")}
 else{ss=[s.tp||"Attività",String(s.ti||"").trim()];o.push((String(s.ti||"").trim()||"attività")+".","");L(s.rf||"Riferimento",s.rc);L("Modello",s.mt);L("Matricola",s.ma);L("Esito",s.es)}
 var sogg=ss.concat(cl.c?[cl.c]:[],cl.n?[cl.n]:[]).filter(Boolean).join(" · ");
 o.unshift("Ciao,");o.push("","Grazie"+(String(s.tec||"").trim()?",\n"+String(s.tec).trim():""));
 return "mailto:?subject="+encodeURIComponent(sogg)+"&body="+encodeURIComponent(o.join("\n"))}
function ripRif(s){var r=String(s.rma||"").trim(),c=String(s.cv||"").trim();return r?"RMA: "+r:c?"CV: "+c:"RMA: …"}
function ripAs(s){return (+s.rn||1)===2&&!!s.rva}
function ripEnd(b,s,p,hd,cnt){b.push(hd,C(p+"acc","Test di accensione"),C(p+"res","Reset"),C(p+"cnt",cnt),G(p+"es","Esito",["Riparato","Non riparabile"]));
 if(s[p+"es"]==="Riparato"){b.push(G(p+"de","Destinazione",["Reimballo","Reinstallazione in loco","Spedizione"]));
  if(s[p+"de"]==="Spedizione"){b.push(G(p+"sp","Spedire a",["Cliente","Rivenditore","Tecnico di zona"]));var ad=T("spa","Indirizzo di spedizione","Via, CAP, comune, provincia",1);ad.opt=1;b.push(ad)}}}
function ripDet(s,p,pz){var d=[];if(s[p+"er"])d.push("Codice errore: "+String(s[p+"er"]).trim()+".");
 if(s[p+"pb"])d.push("Problematica riscontrata: "+String(s[p+"pb"]).trim());
 if(s[p+"pr"])d.push("Interventi eseguiti: "+String(s[p+"pr"]).trim());
 if(pz.length)d.push("Per ripristinare il corretto funzionamento "+(pz.length>1?"sono stati sostituiti i componenti: ":"è stato sostituito il componente: ")+pz.join(", ")+".");return d}
function ripAg(s,p,mi){var ag=[];if(s[p+"ucp"])ag.push("firmware CPU"+verT(s,p+"ucp"));if(s[p+"ubv"]&&mi.t!=="C")ag.push("BV"+verT(s,p+"ubv"));return ag.length?"Eseguito aggiornamento "+ag.join(" e ")+".":""}
function ripPz(s,p){var o=[],j;for(j=1;j<=(+s[p+"np"]||0);j++)if(s[p+"pz"+j])o.push(s[p+"pz"+j]);return o}
function ripDest(s,p,d,ok,nr,w){if(ok){d.push(w+" riparato.");var de=s[p+"de"],sp={"Cliente":"al cliente","Rivenditore":"al rivenditore","Tecnico di zona":"al tecnico di zona"}[s[p+"sp"]]||"";
  if(de)d.push("Destinazione: "+(de==="Spedizione"?"spedizione"+(sp?" "+sp:""):de.charAt(0).toLowerCase()+de.slice(1))+".")}
 else if(nr)d.push(w+" non riparabile.")}
function ripTextAs(s){var A=modInfo(s,"r1_"),Bm=modInfo(s,"r2_"),o=[],d,x,ok=s.r1_es==="Riparato",nr=s.r1_es==="Non riparabile";
 o.push("Riparazione in laboratorio del modulo"+(A.n?" "+A.n:"")+" e revisione totale del modulo"+(Bm.n?" "+Bm.n:"")+(A.m?" del dispositivo Glory "+A.m:"")+".");
 o.push(A.full,Bm.full,ripRif(s));
 d=ripDet(s,"r1_",ripPz(s,"r1_"));x=ripAg(s,"r1_",A);if(x)d.push(x);
 if(d.length){o.push("","Modulo "+(A.n||"1")+":");o=o.concat(d)}
 d=[];var q=[];if(s.r2_pl)q.push("pulizia completa");if(s.r2_ss)q.push("verifica di sensori e sportelli");
 if(q.length)d.push("Eseguita "+q.join(" e ")+".");
 if(s.r2_pp==="Sì"){d.push("Durante la revisione rilevato un problema.");d=d.concat(ripDet(s,"r2_",ripPz(s,"r2_")))}
 else if(s.r2_pp==="No")d.push("Nessun problema rilevato.");
 x=ripAg(s,"r2_",Bm);if(x)d.push(x);
 if(d.length){o.push("","Modulo "+(Bm.n||"2")+" (revisione):");o=o.concat(d)}
 d=[];if(s.r1_acc||s.r1_res||s.r1_cnt)d.push("Eseguite prove di funzionamento su entrambi i moduli"+(ok?" con esito positivo":"")+".");
 ripDest(s,"r1_",d,ok,nr,"Dispositivo");
 if(d.length){o.push("");o=o.concat(d)}
 return o.join("\n")}
function ripText(s){if(ripAs(s))return ripTextAs(s);var rn=+s.rn||1,o=[],i,j,M=[];
 for(i=1;i<=rn;i++)M.push(modInfo(s,"r"+i+"_"));
 var mdl=M.map(function(m){return m.m}).filter(Boolean),same=mdl.length===M.length&&mdl.every(function(x){return x===mdl[0]}),nm=M.map(function(m){return m.n}).filter(Boolean);
 if(rn>1)o.push("Riparazione in laboratorio "+(nm.length===rn&&nm[0]===nm[1]?"di due moduli "+nm[0]:"dei moduli"+(nm.length===rn?" "+nm.join(" e "):""))+(same?" Glory "+mdl[0]:"")+".");
 else o.push("Riparazione in laboratorio del modulo"+(M[0].n?" "+M[0].n:"")+(M[0].m?" Glory "+M[0].m:"")+".");
 M.forEach(function(m){o.push(m.full+(rn>1&&!same&&m.m?" ("+m.m+")":""))});
 o.push(ripRif(s));
 for(i=1;i<=rn;i++){var p="r"+i+"_",mi=M[i-1],pz=[],ag=[],d=[],ts=s[p+"acc"]||s[p+"res"]||s[p+"cnt"];
  for(j=1;j<=(+s[p+"np"]||0);j++)if(s[p+"pz"+j])pz.push(s[p+"pz"+j]);
  if(s[p+"er"])d.push("Codice errore: "+String(s[p+"er"]).trim()+".");
  if(s[p+"pb"])d.push("Problematica riscontrata: "+String(s[p+"pb"]).trim());
  if(s[p+"pr"])d.push("Interventi eseguiti: "+String(s[p+"pr"]).trim());
  if(pz.length)d.push("Per ripristinare il corretto funzionamento "+(pz.length>1?"sono stati sostituiti i componenti: ":"è stato sostituito il componente: ")+pz.join(", ")+".");
  var ok=s[p+"es"]==="Riparato",nr=s[p+"es"]==="Non riparabile";
  if(s[p+"ucp"])ag.push("firmware CPU"+verT(s,p+"ucp"));if(s[p+"ubv"]&&mi.t!=="C")ag.push("BV"+verT(s,p+"ubv"));
  if(ag.length)d.push("Eseguito aggiornamento "+ag.join(" e ")+".");
  if(ts)d.push("Eseguite prove di funzionamento"+(ok?" con esito positivo":"")+".");
  if(ok){d.push("Modulo riparato.");var de=s[p+"de"],sp={"Cliente":"al cliente","Rivenditore":"al rivenditore","Tecnico di zona":"al tecnico di zona"}[s[p+"sp"]]||"";
   if(de)d.push("Destinazione: "+(de==="Spedizione"?"spedizione"+(sp?" "+sp:""):de.charAt(0).toLowerCase()+de.slice(1))+".")}
  else if(nr)d.push("Modulo non riparabile.");
  if(rn>1&&d.length)d.unshift("Modulo "+(mi.n||i)+":");
  if(d.length){o.push("");d.forEach(function(l){o.push(l)})}}
 return o.join("\n")}
function locUnits(s){var P=PX[s.md]||"",o=[];
 function mod(p,t){var sg=P?"R"+t+"W"+P+"-":"";o.push({p:p,t:t,m:1,l:t==="B"?"Modulo banconote":"Modulo monete",n:t==="B"?"banconote":"monete",sig:sg,full:sg+(s[p+"mat"]||"…")})}
 if(s.sc==="Modulo banconote")mod("r1_","B");else if(s.sc==="Modulo monete")mod("r2_","C");
 else if(s.sc==="Entrambi i moduli"||s.sc==="Pulizia e revisione"){mod("r1_","B");mod("r2_","C")}
 else if(s.sc==="Dispositivo / altro")o.push({p:"d_",t:"",m:0,l:String(s.sp||"").trim()||"Dispositivo",n:"",sig:"",full:""});
 return o}
function locUpd(s){var U=locUnits(s),all=!!s.fl||!s.sc;return {B:all||U.some(function(u){return u.t==="B"}),C:all||U.some(function(u){return u.t==="C"})}}
function locPre(s){return s.ct1==="Problema"||s.ct2==="Problema"}
function locPreText(s){var pr=[],o=[];if(s.ct1==="Problema")pr.push("alimentazione e cavi");if(s.ct2==="Problema")pr.push("collegamento di rete");
 o.push("Controlli preliminari: riscontrato problema su "+pr.join(" e ")+".");
 if(s.ppb)o.push("Problematica riscontrata: "+String(s.ppb).trim());if(s.ppr)o.push("Interventi eseguiti: "+String(s.ppr).trim());
 if(s.pes==="Risolto")o.push("Problema risolto.");
 else if(s.pes==="Non risolto"){o.push("Problema non risolto.");if(s.pde)o.push(s.pde==="Nuovo intervento"?"Necessario nuovo intervento.":"Dispositivo da ritirare per riparazione in laboratorio.")}
 return o}
function locHead(s){var U=locUnits(s),o=[],PUL=s.sc==="Pulizia e revisione";
 if(s.sc==="Dispositivo / altro")o.push("Intervento su "+(String(s.sp||"").trim()||"dispositivo")+(s.md?" del dispositivo Glory "+s.md:"")+".");
 else o.push((PUL?"Eseguita pulizia e revisione del dispositivo":"Intervento sul dispositivo")+(s.md?" Glory "+s.md:"")+".");
 U.forEach(function(u){if(u.m)o.push(u.full)});
 if(String(s.mt||"").trim())o.push("Codice impianto: "+String(s.mt).trim());
 return o}
function locText(s){var o=locHead(s);
 if(locPre(s)){o.push("");o=o.concat(locPreText(s));if(s.pes!=="Risolto")return o.join("\n")}
 var t=locText2(s);if(t){o.push("");o.push(t)}
 return o.join("\n")}
function locText2(s){var U=locUnits(s),o=[],ag=[],i,j,m=U.length>1,PUL=s.sc==="Pulizia e revisione";
 if(PUL){var MM=U.filter(function(u){return u.m}),pc=MM.filter(function(u){return s[u.p+"pl"]}),sc2=MM.filter(function(u){return s[u.p+"ss"]}),q=[];
  if(pc.length)q.push("pulizia completa "+(pc.length===MM.length?"di entrambi i moduli":"del modulo "+pc[0].n));
  if(sc2.length)q.push("verifica di sensori e sportelli"+(sc2.length===MM.length?"":" del modulo "+sc2[0].n));
  if(q.length){var t0=q.join(" e ");o.push(t0.charAt(0).toUpperCase()+t0.slice(1)+".")}}
 U.forEach(function(u){var p=u.p,pz=[],d=[];
  if(PUL&&s[p+"pp"]!=="Sì")return;
  for(j=1;j<=(+s[p+"np"]||0);j++)if(s[p+"pz"+j])pz.push(s[p+"pz"+j]);
  if(s[p+"er"])d.push("Codice errore: "+String(s[p+"er"]).trim()+".");
  if(s[p+"pb"])d.push("Problematica riscontrata: "+String(s[p+"pb"]).trim());
  if(s[p+"pr"])d.push("Interventi eseguiti: "+String(s[p+"pr"]).trim());
  if(pz.length)d.push("Per ripristinare il corretto funzionamento "+(pz.length>1?"sono stati sostituiti i componenti: ":"è stato sostituito il componente: ")+pz.join(", ")+".");
  if(PUL)d.unshift("Dopo la pulizia rilevato un problema sul modulo "+u.n+".");
  else if(d.length&&m&&u.m)d.unshift("Modulo "+u.n+":");
  if(d.length){if(o.length)o.push("");d.forEach(function(l){o.push(l)})}});
 if(s.rev&&!PUL){if(o.length)o.push("");o.push("Contestualmente eseguita revisione generale del dispositivo.")}
 var ap=[],vb=verT(s,"ubc"),vm=verT(s,"umc"),LU=locUpd(s),xb=LU.B&&s.ubc,xm=LU.C&&s.umc;if(LU.B&&s.ubb)ap.push("BV"+verT(s,"ubb"));if(xb&&xm&&!vb&&!vm)ap.push("firmware CPU di entrambi i moduli");else{if(xb)ap.push("firmware CPU del modulo banconote"+vb);if(xm)ap.push("firmware CPU del modulo monete"+vm)}if(s.ufc)ap.push("FCC"+verT(s,"ufc"));
 if(ap.length)ag.push("Eseguito aggiornamento "+(ap.length>1?ap.slice(0,-1).join(", ")+" e "+ap[ap.length-1]:ap[0])+".");
 if(ag.length){o.push("");ag.forEach(function(l){o.push(l)})}
 var MD=U.filter(function(u){return u.m});
 if(U.length&&(s.cfa||s.cfr||s.cfb||s.cfm||s.cft)){o.push("");o.push("Eseguite prove di funzionamento"+(s.cfe==="Tutto OK"?" con esito positivo":"")+".")}
 if(U.length&&s.cfe==="Tutto OK"){o.push("");o.push(PUL&&!U.some(function(u){return s[u.p+"pp"]==="Sì"})?"Dispositivo lasciato operativo.":"Dispositivo ripristinato e lasciato operativo.")}
 else if(U.length&&s.cfe==="Problematica rilevata"){o.push("");
  var mq=MD.length>1?(s.cfq==="Entrambi"?" su entrambi i moduli":s.cfq?" sul "+s.cfq.toLowerCase():""):(MD.length?" sul modulo "+MD[0].n:"");
  o.push("Al collaudo rilevata una problematica"+mq+".");
  if(s.cfx==="Risolta")o.push("Problematica risolta, dispositivo lasciato operativo.");
  else if(s.cfx==="Non risolta"){o.push("Problematica non risolta.");if(s.cfd)o.push(s.cfd==="Nuovo intervento"?"Necessario nuovo intervento.":"Dispositivo da ritirare per riparazione in laboratorio.")}}
 return o.join("\n").replace(/^\n+/,"")}
function altroText(s){var o=[(s.tp||"Attività")+(s.ti?": "+s.ti:"")+"."],d=[s.mt,s.ma].filter(Boolean).join(" ");
 if(d)o.push("Dispositivo: "+d+".");if(s.de)o.push(String(s.de).trim());if(s.es)o.push("Esito: "+s.es.toLowerCase()+".");
 return o.join("\n")}
function notes(s){var sn=s.sng==="Android"?"SNG 3":s.sng==="Windows"?"SNG Suite":"…",n=devN(s),o=[],l=[],big=0,ic=0,ts=1,i,pl=n>1;
 for(i=1;i<=n;i++){var m=s["m"+i]||"[modello]",p=PX[s["m"+i]]||"";if(s["m"+i]&&m!=="CI-5")big=1;
  if(s["d"+i+"_7"])ic=1;if(!s["d"+i+"_8"])ts=0;
  o.push("Installato dispositivo Glory "+m+".","RBW"+p+"-"+(s["a"+i]||"…"),"RCW"+p+"-"+(s["c"+i]||"…"),"Codice impianto: "+(s["mt"+i]||"…"),"")}
 if(ts&&n)l.push("Eseguiti test di funzionamento "+(pl?"dei dispositivi":"del dispositivo")+" con esito positivo.");
 if(ic)l.push("Eseguita interconnessione con il gestionale del cliente.");
 var nsv=+s.nsv||0,ncl=+s.ncl||0;
 if(s.bo==="Sì"&&(nsv||ncl)){var ds=0,dc=0,q;for(q=1;q<=nsv;q++)if(s["bsv"+q])ds++;for(q=1;q<=ncl;q++)if(q===1&&nsv?s.bsv1:s["bcl"+q])dc++;
  var pp=[];if(ds)pp.push(ds+" server");if(dc)pp.push(dc+" client");if(pp.length)l.push("Installato e configurato "+sn+" su "+pp.join(" e ")+".")}
 else if(s.bo==="Sì"&&(s.bi||s.bc))l.push((s.bi&&s.bc?"Installato e configurato":s.bi?"Installato":"Configurato")+" "+sn+".");
 if(s.bo!=="Sì"&&s.app&&s.sng!=="Android"&&s.g11)l.push("Installata app SNG Cloud.");
 if(n&&s.sur==="Sì, impostato")l.push("Impostato il surplus (fondo cassa) su richiesta del cliente.");
 else if(n&&s.sur==="No")l.push("Il cliente non ha richiesto l'impostazione del surplus.");
 if(l.length)o.push(l.join(" "),"");
 if(n&&s.f1)o.push("Illustrato al cliente il corretto utilizzo "+(pl?"dei dispositivi":"del dispositivo")+" e le principali manovre di ripristino.","");
 if(s.bo==="Sì"&&s.bs)o.push("Illustrato al cliente il corretto utilizzo di "+sn+" e le principali funzionalità.","");
 if(n)o.push("Istruito il cliente sul fissaggio "+(pl?"dei dispositivi":"del dispositivo")+", a suo carico. Consigliata l’alimentazione "+(pl?"dei dispositivi":"del dispositivo")+" tramite UPS.");
 if(n&&s.f3)o.push("","Chiavi "+(pl?"dei dispositivi":"del dispositivo")+" (rosse, gialle"+(big?" e blu":"")+") consegnate a: "+(String(s.ric||"").trim()||"______________")+".");
 if(n&&String(s.altm||"").trim())o.push("","Fornito e installato: "+String(s.altm).trim().replace(/\.$/,"")+".");
 return o.join("\n")}
function noteText(){return view==="inst"?notes(S):view==="rip"?ripText(S):view==="loc"?locText(S):view==="rit"?ritText(S):altroText(S)}
function ritText(s){var n=devN(s),o=[],i,pl=n>1,LOC=s.dv==="In loco",MAG=s.dv==="In magazzino",mo={"Dismissione":"per dismissione","Sostituzione":"per sostituzione","Furto":"a seguito di furto","Danneggiata":"perché danneggiat"+(pl?"i":"o")}[s.mo]||(s.mo==="Altro"&&String(s.mos||"").trim()?"("+String(s.mos).trim()+")":"");
 var md=[];for(i=1;i<=n;i++)if(s["m"+i])md.push(s["m"+i]);var same=md.length===n&&md.every(function(x){return x===md[0]});
 o.push((MAG?(pl?"Ricevuti":"Ricevuto")+" in magazzino ":LOC?(pl?"Ritirati":"Ritirato")+" presso il cliente ":(pl?"Ritirati ":"Ritirato "))+(pl?(same?n+" dispositivi Glory "+md[0]:n+" dispositivi Glory"):"dispositivo Glory "+(s.m1||"[modello]"))+(mo?" "+mo:"")+".");
 for(i=1;i<=n;i++){var p=PX[s["m"+i]]||"";if(pl&&!same)o.push("Dispositivo "+i+": Glory "+(s["m"+i]||"[modello]"));o.push("RBW"+p+"-"+(s["a"+i]||"…"),"RCW"+p+"-"+(s["c"+i]||"…"));if(String(s["mt"+i]||"").trim())o.push("Codice impianto: "+String(s["mt"+i]).trim())}
 var f=[];if(LOC){if(s.w1)f.push((pl?"Dispositivi scollegati":"Dispositivo scollegato")+" da alimentazione e rete");if(s.w2)f.push("contante rimosso e valigette svuotate in presenza del cliente");if(s.w3)f.push("chiavi ritirate")}
 if(f.length){var t=f.join(", ");o.push("",t.charAt(0).toUpperCase()+t.slice(1)+".")}
 if(MAG&&s.imb)o.push("",s.imb==="Sì"?"Imballo ricevuto integro.":"Imballo ricevuto non integro.");
 if(s.dn==="Sì")o.push("","Danni riscontrati: "+(String(s.dnd||"").trim()||"…"));else if(s.dn==="No")o.push("","Nessun danno riscontrato.");
 return o.join("\n")}

/* ---------- controllo prima di copiare ---------- */
function check(bl){var bad=[],warn=[],s=S,i,n,sec="",sub="";
 function has(k){return !!String(s[k]||"").trim()}
 function need(k,t){if(!has(k)){bad.push(t);MK[t]=k}}
 function want(k,t){if(!has(k)){warn.push(t);MK[t]=k}}
 want("tec","Nome del tecnico");
 if(view==="rit"){n=devN(s);if(!n)bad.push("Almeno un dispositivo ritirato (CI-5, CI-10 o CI-10X)");if(!s.dv)bad.push("Dove: in loco o in magazzino");if(!s.mo){warn.push("Motivo del ritiro");MK["Motivo del ritiro"]="mo"}
  for(i=1;i<=n;i++){need("m"+i,"Modello del dispositivo "+i);need("a"+i,"Matricola banconote del dispositivo "+i);need("c"+i,"Matricola monete del dispositivo "+i)}
  want("cl","Cliente");if(s.rv)want("rvn","Rivenditore");want("rf","Riferimento (CV, ticket o RMA)");if(!s.dn){warn.push("Danni riscontrati (Sì o No)");MK["Danni riscontrati (Sì o No)"]="dn"}else if(s.dn==="Sì")want("dnd","Descrizione dei danni");want("ore","Ore di manodopera")}
 else if(view==="inst"){n=devN(s);if(!n&&!(s.bo==="Sì"||(s.app&&s.sng!=="Android")))bad.push("Almeno un dispositivo (CI-5, CI-10 o CI-10X) oppure il software da installare");
  for(i=1;i<=n;i++){need("m"+i,"Modello del dispositivo "+i);need("a"+i,"Matricola banconote del dispositivo "+i);need("c"+i,"Matricola monete del dispositivo "+i);want("mt"+i,"Codice impianto del dispositivo "+i)}
  var dupI={};for(i=1;i<=n;i++)["a","c"].forEach(function(f){var v=mnorm(s[f+i]),k=f+s["m"+i]+v,t;if(!v)return;if(dupI[k]){t="Matricola "+(f==="a"?"banconote":"monete")+" duplicata: "+s[f+i]+" (dispositivi "+dupI[k]+" e "+i+")";warn.push(t);MK[t]=f+i}else dupI[k]=i});
  if(s.bo==="Sì"){need("sng","Sistema del gestionale del cliente (Windows o Android)");if(!(+s.nsv||0)&&!(+s.ncl||0))warn.push("Numero di postazioni server e client SNG")}
  if(n&&s.sur!=="Sì, impostato"&&s.sur!=="No")warn.push("Surplus (fondo cassa): chiedi al cliente se lo vuole");
  want("cv","Codice contratto (CV)");if(s.rv)want("rvn","Rivenditore");want("cl","Cliente");if(s.f3)want("ric","Nome di chi riceve le chiavi")}
 else if(view==="loc"){need("rf","Riferimento dell'intervento");need("sc","Su cosa è stato fatto l'intervento");if(s.sc==="Dispositivo / altro")need("sp","Specifica il dispositivo o l'oggetto dell'intervento");else need("md","Modello del dispositivo");if(s.rv)want("rvn","Rivenditore");want("cl","Cliente");
  if(!s.ct1||!s.ct2)warn.push("Controlli preliminari: alimentazione e rete (OK o Problema)");
  var stp=locPre(s)&&s.pes!=="Risolto";if(locPre(s)){need("ppb","Problematica riscontrata nei controlli preliminari");if(!s.pes)bad.push("Esito dei controlli preliminari (risolto o non risolto)")}
  locUnits(s).forEach(function(u){var q=u.p;if(u.m)need(q+"mat","Matricola del "+u.l.toLowerCase());if(stp)return;
   if(s.sc==="Pulizia e revisione"){if(!s[q+"pp"])bad.push("Pulizia: problema rilevato dopo la pulizia sul "+u.l.toLowerCase()+"? (Sì o No)");if(s[q+"pp"]!=="Sì")return}
   want(q+"pb","Problematica riscontrata ("+u.l.toLowerCase()+")");want(q+"pr","Interventi eseguiti ("+u.l.toLowerCase()+")")});
 var LU=locUnits(s);if(!stp&&LU.length){if(!s.cfe)bad.push("Esito del collaudo finale (Tutto OK o Problematica rilevata)");
   else if(s.cfe==="Problematica rilevata"){if(LU.filter(function(u){return u.m}).length>1&&!s.cfq)bad.push("Su quale modulo è la problematica del collaudo");if(!s.cfx)bad.push("Problematica del collaudo: risolta o non risolta")}}
  if(s.fl&&!stp){if(!s.rev&&s.sc!=="Pulizia e revisione")warn.push("Contratto full: pulizia e revisione del dispositivo non eseguita");if(!s.ufc&&!s.ubc&&!s.ubb&&!s.umc)warn.push("Contratto full: nessun aggiornamento eseguito (firmware CPU, BV, FCC)")}
  want("ore","Ore di manodopera")}
 else if(view==="rip"){if(!has("rma")&&!has("cv")){bad.push("Codice RMA (oppure il CV)");MK["Codice RMA (oppure il CV)"]="rma"}n=+s.rn||1;
  var AS=ripAs(s);
  for(i=1;i<=n;i++){var p="r"+i+"_";if(AS&&i===2){need(p+"mat","Matricola del modulo associato");if(!s[p+"pp"]){bad.push("Revisione del modulo associato: problema rilevato? (Sì o No)");MK["Revisione del modulo associato: problema rilevato? (Sì o No)"]=p+"pp"}else if(s[p+"pp"]==="Sì"){want(p+"pb","Problematica riscontrata sul modulo associato");want(p+"pr","Interventi eseguiti sul modulo associato")}continue}
   need(p+"tp","Tipo del modulo "+i);need(p+"md","Modello del modulo "+i);need(p+"mat","Matricola del modulo "+i);
   if(!s[p+"es"])bad.push("Esito del modulo "+i+" (riparato o non riparabile)");
   else if(s[p+"es"]==="Riparato"){if(!s[p+"de"]){warn.push("Destinazione del modulo "+i);MK["Destinazione del modulo "+i]=p+"de"}else if(s[p+"de"]==="Spedizione"&&!s[p+"sp"]){warn.push("A chi spedire il modulo "+i);MK["A chi spedire il modulo "+i]=p+"sp"}}
   want(p+"pb","Problematica riscontrata sul modulo "+i);want(p+"pr","Interventi eseguiti sul modulo "+i)}
  want("ore","Ore di manodopera")}
 else if(view==="prep"){if(s.m&&(s.m!=="CI-5"||prepMode(s)==="Completa")&&s.mon!=="Sì"&&!has("chp"))warn.push("Dove sono state messe le chiavi (monitor assente)");if(prepMode(s)==="Downgrade CI-5"){var sn={},dk,dv0;for(dk=1;dk<=(+s.dn||1);dk++){dv0=mnorm(s[mrk(dk)]);if(!dv0)continue;if(sn[dv0])warn.push("Matricola duplicata: "+s[mrk(dk)]+" (dispositivi "+sn[dv0]+" e "+dk+")");else sn[dv0]=dk}}}
  else{need("ti","Titolo dell'attività");need("de","Descrizione dell'intervento");
  if(s.rf)want("rc","Codice "+s.rf);else warn.push("Riferimento CV o RMA");want("es","Esito");want("ore","Ore di manodopera")}
 bl.forEach(function(x){if(x.t==="h"){sec=x.x;sub=""}else if(x.t==="h3")sub=x.x;else if(x.t==="c"&&!x.memo&&!x.opt&&!s[x.id]){var _m="Non spuntata: "+x.x+(x.dv?" · dispositivo "+x.dv:"")+(sec?" ("+sec+(sub?" · "+sub:"")+")":"");warn.push(_m);MK[_m]=x.id}});
 return {bad:bad,warn:warn}}
function cpy(t,ok,ko){var f=function(){var a=document.createElement("textarea"),r=false;a.value=t;a.style.position="fixed";a.style.opacity="0";document.body.append(a);a.select();try{r=document.execCommand("copy")}catch(e){}a.remove();if(r)ok();else if(ko)ko()};
 try{navigator.clipboard.writeText(t).then(ok,f)}catch(e){f()}}
function wlist(bx,a){var u=el("ul","wl");a.slice(0,12).forEach(function(t){var k=keyOf(t),li=el("li");if(canJump(k))li.append(btn("wlk",t,function(){jump(k)}));else li.textContent=t;u.append(li)});if(a.length>12)u.append(el("li",0,"e altre "+(a.length-12)+" voci"));bx.append(u)}
function doCopy(cb,cm){var t=noteText();if(noteTa)noteTa.value=t;cm.textContent="";
 cpy(t,function(){cb.textContent="Copiato";setTimeout(function(){cb.textContent="Copia note"},1800)},function(){cm.textContent="Copia non riuscita: seleziona il testo qui sopra e copialo a mano."})}
function tryCopy(cb,cm){var r=check(V[view].blocks(S));cm.textContent="";
 if(!r.bad.length&&(!r.warn.length||passi())){doCopy(cb,cm);return}
 var bx=el("div",r.bad.length?"box":"box wn");bx.setAttribute("role","alert");
 if(r.bad.length){bx.append(el("b",0,"Non copio: mancano dati fondamentali"));wlist(bx,r.bad)}
 if(r.warn.length){bx.append(el("b",0,r.bad.length?"Da controllare":"Prima di copiare, controlla"));wlist(bx,r.warn)}
 if(!r.bad.length){var sg=el("div","seg");sg.append(btn("on","Copia comunque",function(){doCopy(cb,cm)}),btn("","Annulla",function(){cm.textContent=""}));bx.append(sg)}
 cm.append(bx)}
/* ---------- PDF ---------- */
function prog(bl,s,all){var t=0,d=0;bl.forEach(function(x){if(x.memo||x.opt)return;if(x.t==="c"||(all&&(x.t==="g"||x.t==="sel"))){t++;if(s[x.id])d++}});return {t:t,d:d}}
var PSKIP={inst:["tec","cv","cl","se","rvn","nte"],prep:["tec","cvc","nte","mtM","mtB","mtD"],rip:["tec","rma","cv","rvn","cl","nte"],loc:["tec","rf","cl","se","rvn","nte"],altro:["tec","nte"],rit:["tec","rf","cl","se","rvn","nte"]};
function pdfEnc(t){return String(t==null?"":t).replace(/[‘’]/g,"'").replace(/[“”]/g,'"').replace(/[–—]/g,"-").replace(/≥/g,">=").replace(/…/g,"...").replace(/\s/g," ").replace(/[^\x20-\xFF]/g,"?")}
function pdfEsc(t){return pdfEnc(t).replace(/[\\()]/g,"\\$&")}
function pdfWrap(t,n){var l=[];String(t==null?"":t).split(/\r?\n/).forEach(function(par){var c="";
  par.split(" ").forEach(function(z){while(z.length>n){if(c){l.push(c);c=""}l.push(z.slice(0,n));z=z.slice(n)}
   if(c&&(c+" "+z).length>n){l.push(c);c=z}else c=c?c+" "+z:z});
  l.push(c)});
 return l.length?l:[""]}
function buildPdf(meta,rows){
 var W=595,HH=842,M=42,BLUE=[0.12,0.37,0.60],GREEN=[0.12,0.48,0.30],RED=[0.76,0.23,0.13],G1=[0.95,0.96,0.97],G2=[0.90,0.92,0.94],TXT=[0.08,0.10,0.11],MUT=[0.42,0.46,0.50],pages=[],ops,y,i,k;
 function c3(a){return a.map(function(v){return v.toFixed(3)}).join(" ")}
 function np(){ops=[];pages.push(ops);y=HH-M;if(pages.length>1){ops.push(c3(BLUE)+" RG 1.2 w "+M+" "+(HH-26)+" m "+(W-M)+" "+(HH-26)+" l S");y=HH-M-8}}
 function need(h){if(y-h<M+22)np()}
 function rect(x,yy,w,h,col){ops.push(c3(col)+" rg "+x.toFixed(1)+" "+yy.toFixed(1)+" "+w.toFixed(1)+" "+h.toFixed(1)+" re f")}
 function frame(x,yy,w,h,col,lw){ops.push(c3(col)+" RG "+(lw||0.6)+" w "+x.toFixed(1)+" "+yy.toFixed(1)+" "+w.toFixed(1)+" "+h.toFixed(1)+" re S")}
 function tx(f,s,x,yy,t,col){ops.push("BT /"+f+" "+s+" Tf "+c3(col||TXT)+" rg "+x.toFixed(1)+" "+yy.toFixed(1)+" Td ("+pdfEsc(t)+") Tj ET")}
 function tw(t,s){return pdfEnc(t).length*s*0.5}
 function cl(t,n){t=String(t==null?"":t);return t.length>n?t.slice(0,n-3)+"...":t}
 np();
 var bandH=52,pn=(meta.fn||pdfName()).replace(/\.pdf$/,"");
 rect(0,HH-bandH,W,bandH,BLUE);tx("F2",16,M,HH-27,meta.title,[1,1,1]);tx("F1",8,M,HH-42,"Documento interno",[0.82,0.90,0.97]);
 tx("F1",8,W-M-tw(meta.date,8),HH-27,meta.date,[1,1,1]);
 y=HH-bandH-14;
 var info=[],prg="";
 meta.lines.forEach(function(l){if(/^Voci completate/.test(l)){prg=l;return}var j=l.indexOf(": ");info.push(j<0?["",l]:[l.slice(0,j),l.slice(j+2)])});
 info.forEach(function(p){p[2]=pdfWrap(p[1],78)});var bh=info.reduce(function(a,p){return a+p[2].length*11+4},0)+10;
 rect(M,y-bh,W-2*M,bh,G1);rect(M,y-bh,3,bh,BLUE);
 var iy=y-15;info.forEach(function(p){tx("F2",7.5,M+14,iy,p[0].toUpperCase(),MUT);p[2].forEach(function(l,j){tx("F1",9.5,M+124,iy-j*11,l,TXT)});iy-=p[2].length*11+4});
 y-=bh+10;
 var mm=/(\d+) di (\d+)/.exec(prg),dn=mm?+mm[1]:0,tt=mm?+mm[2]:0;
 tx("F2",8,M,y-8,"Voci completate",MUT);tx("F1",8,M+74,y-8,dn+" di "+tt,TXT);
 var bx=M+120,bw=W-2*M-120;rect(bx,y-10,bw,6,G2);rect(bx,y-10,tt?bw*dn/tt:0,6,GREEN);
 y-=24;
 var alt=0,R=rows.filter(function(r,j,a){return !(r.k==="h3"&&(!a[j+1]||a[j+1].k==="h"||a[j+1].k==="h3"))});
 for(i=0;i<R.length;i++){var r=R[i];
  if(r.k!=="f")alt=0;
  if(r.k==="h"){need(34);y-=6;rect(M,y-17,W-2*M,17,G2);rect(M,y-17,4,17,BLUE);tx("F2",10,M+12,y-12,r.x,TXT);y-=22}
  else if(r.k==="h3"){need(24);y-=2;tx("F2",7.5,M+2,y-8,r.x.toUpperCase(),BLUE);y-=13}
  else if(r.k==="c"){var L=pdfWrap(r.x,96),hh=L.length*11+5;need(hh+2);
   var es=/^(Problema (non )?risolto|Dispositivo riparato|Macchina non riparabile)$/.test(r.x)&&r.d,ko=es&&/non/.test(r.x);
   if(es)rect(M,y-hh+1,W-2*M,hh-1,ko?[0.99,0.92,0.90]:[0.90,0.96,0.92]);
   var col=r.d?(ko?RED:GREEN):null;
   if(r.d){rect(M+6,y-10,9,9,col);ops.push("1 1 1 RG 1.4 w "+(M+7.9)+" "+(y-5.4)+" m "+(M+9.6)+" "+(y-7.8)+" l "+(M+13)+" "+(y-2.6)+" l S")}
   else frame(M+6,y-10,9,9,[0.6,0.64,0.68],0.8);
   L.forEach(function(s,j){tx(r.d?"F2":"F1",9,M+24,y-8.5-j*11,s,r.d?TXT:MUT)});
   y-=hh}
  else if(r.k==="f"){var L2=pdfWrap(r.v,76),LB=pdfWrap(r.x.toUpperCase(),28),h2=Math.max(L2.length,LB.length)*11+6;need(h2);
   if(alt%2===0)rect(M,y-h2+2,W-2*M,h2,G1);alt++;
   LB.forEach(function(s,j){tx("F2",7.5,M+8,y-8.5-j*11,s,MUT)});L2.forEach(function(s,j){tx("F1",9,M+160,y-8.5-j*11,s)});y-=h2}
  else if(r.k==="dv"){need(18);if(alt%2===0)rect(M,y-16,W-2*M,16,G1);alt++;
    tx("F2",7.5,M+8,y-11,r.x.toUpperCase(),MUT);tx("F1",9,M+100,y-11,r.v);
    r.m.forEach(function(q,j){var bx=M+190+[0,95,200][j];if(q[1]){rect(bx,y-12,9,9,GREEN);ops.push("1 1 1 RG 1.4 w "+(bx+1.9)+" "+(y-7.4)+" m "+(bx+3.6)+" "+(y-9.8)+" l "+(bx+7)+" "+(y-4.6)+" l S")}else frame(bx,y-12,9,9,[0.6,0.64,0.68],0.8);
     tx(q[1]?"F2":"F1",8,bx+13,y-10.5,q[0],q[1]?TXT:MUT)});y-=16;if(!R[i+1]||R[i+1].k!=="dv")y-=6}
   else if(r.k==="tl"){need(20);y-=6;tx("F1",9,M+8,y-9,r.x,TXT);y-=16}
   else if(r.k==="nt"){var L3=pdfWrap("Nota: "+r.x,106);need(L3.length*10+4);L3.forEach(function(s,j){tx("F3",8,M+24,y-8-j*10,s,MUT)});y-=L3.length*10+4}
  else if(r.k==="li"){var g=[];while(i<R.length&&R[i].k==="li"){g.push(R[i].x);i++}i--;
   var h4=g.length*11+10;need(h4+4);frame(M,y-h4,W-2*M,h4,[0.65,0.70,0.75],0.7);g.forEach(function(s,j){tx("F1",9,M+10,y-13-j*11,s)});y-=h4+5}
 }
 var F=PH[view]||[],tp=pages.length+F.length;
 function foot(o,nr){o.push(c3([0.75,0.78,0.81])+" RG 0.5 w "+M+" 32 m "+(W-M)+" 32 l S");
  o.push("BT /F1 8 Tf "+c3(MUT)+" rg "+M+" 20 Td ("+pdfEsc(pn)+") Tj ET");
  var pg="Pagina "+nr+" di "+tp;o.push("BT /F1 8 Tf "+c3(MUT)+" rg "+(W-M-pg.length*4)+" 20 Td ("+pg+") Tj ET")}
 pages.forEach(function(o,j){foot(o,j+1)});
 var objs=[],n=pages.length,kids=[];
 objs[1]="<</Type/Catalog/Pages 2 0 R>>";
 objs[3]="<</Type/Font/Subtype/Type1/BaseFont/Helvetica/Encoding/WinAnsiEncoding>>";
 objs[4]="<</Type/Font/Subtype/Type1/BaseFont/Helvetica-Bold/Encoding/WinAnsiEncoding>>";
 objs[5]="<</Type/Font/Subtype/Type1/BaseFont/Helvetica-Oblique/Encoding/WinAnsiEncoding>>";
 var FR="<</Font<</F1 3 0 R/F2 4 0 R/F3 5 0 R>>";
 pages.forEach(function(o,j){var c=o.join("\n");objs[6+2*j]="<</Length "+c.length+">>\nstream\n"+c+"\nendstream";
  objs[7+2*j]="<</Type/Page/Parent 2 0 R/MediaBox[0 0 "+W+" "+HH+"]/Resources"+FR+">>/Contents "+(6+2*j)+" 0 R>>";kids.push((7+2*j)+" 0 R")});
 var base=6+2*n;
 F.forEach(function(f,j){var io=base+3*j,mw=W-2*M,mh=HH-2*M-70,kk=Math.min(mw/f.w,mh/f.h),w=f.w*kk,h=f.h*kk,x=M+(mw-w)/2,yy=HH-M-60-h;ops=[];
  rect(0,HH-64,W,64,BLUE);tx("F2",14,M,HH-38,"Foto "+(j+1),[1,1,1]);tx("F1",9,M,HH-54,f.n,[0.82,0.90,0.97]);
  ops.push("q "+w.toFixed(1)+" 0 0 "+h.toFixed(1)+" "+x.toFixed(1)+" "+yy.toFixed(1)+" cm /Im0 Do Q");
  frame(x,yy,w,h,[0.65,0.70,0.75],0.7);foot(ops,n+j+1);
  var c=ops.join("\n");
  objs[io]="<</Type/XObject/Subtype/Image/Width "+f.w+"/Height "+f.h+"/ColorSpace/DeviceRGB/BitsPerComponent 8/Filter/DCTDecode/Length "+f.b.length+">>\nstream\n"+f.b+"\nendstream";
  objs[io+1]="<</Length "+c.length+">>\nstream\n"+c+"\nendstream";
  objs[io+2]="<</Type/Page/Parent 2 0 R/MediaBox[0 0 "+W+" "+HH+"]/Resources<</Font<</F1 3 0 R/F2 4 0 R>>/XObject<</Im0 "+io+" 0 R>>>>/Contents "+(io+1)+" 0 R>>";
  kids.push((io+2)+" 0 R")});
 objs[2]="<</Type/Pages/Kids["+kids.join(" ")+"]/Count "+kids.length+">>";
 var out="%PDF-1.4\n",off=[];
 for(k=1;k<objs.length;k++){off[k]=out.length;out+=k+" 0 obj\n"+objs[k]+"\nendobj\n"}
 var xr=out.length;out+="xref\n0 "+objs.length+"\n0000000000 65535 f \n";
 for(k=1;k<objs.length;k++)out+=("0000000000"+off[k]).slice(-10)+" 00000 n \n";
 out+="trailer\n<</Size "+objs.length+"/Root 1 0 R>>\nstartxref\n"+xr+"\n%%EOF";
 var u=new Uint8Array(out.length);for(k=0;k<out.length;k++)u[k]=out.charCodeAt(k)&255;
 return u}
function pdfRows(bl){var r=[];bl.forEach(function(x){
 if(x.t==="h")r.push({k:"h",x:x.x});else if(x.t==="h3")r.push({k:"h3",x:x.x});
 else if(x.t==="c"){if(x.memo||(x.opt&&!S[x.id]))return;if(x.dv&&view==="prep"&&prepMode(S)==="Downgrade CI-5")return;r.push({k:"c",x:x.pl||x.x,d:!!S[x.id]});if(S["nt_"+x.id])r.push({k:"nt",x:S["nt_"+x.id]})}
 else if(view==="prep"&&x.t==="t"&&/^mtM\d*$/.test(x.id)&&prepMode(S)==="Downgrade CI-5"){{var mi=x.id==="mtM"?1:+x.id.slice(3);if(mi===1)r.push({k:"tl",x:"Configurati e testati i seguenti dispositivi:"});r.push({k:"f",x:"Dispositivo "+mi,v:String(S[x.id]||"").trim()||"-"})}}
 else if(x.t==="sw")r.push({k:"f",x:"SNG Cloud",v:S.bo==="Sì"?"Sì":"No"},{k:"f",x:"Sistema gestionale",v:S.sng?S.sng+(S.sng==="Android"?" (SNG 3)":" (SNG Suite)"):"-"},{k:"f",x:"App SNG Cloud",v:S.bo==="Sì"?"Non necessaria":(S.app&&S.sng!=="Android")?"Sì":"No"});
 else if(view==="prep"&&prepMode(S)==="Downgrade CI-5"&&x.id==="m"){}
 else if(view==="prep"&&prepMode(S)==="Downgrade CI-5"&&x.id==="pt")r.push({k:"f",x:"Tipo di preparazione",v:"Downgrade CI-5 (modulo monete)"})
 else if(x.t==="cnt"){var nd2=devN(S),q3;if(nd2)r.push({k:"h",x:"Dispositivi"});for(q3=1;q3<=nd2;q3++){var px=PX[S["m"+q3]]||"";r.push({k:"h3",x:"Dispositivo "+q3+(S["m"+q3]?" · "+S["m"+q3]:"")},{k:"f",x:"RBW"+px+"- banconote",v:S["a"+q3]||"-"},{k:"f",x:"RCW"+px+"- monete",v:S["c"+q3]||"-"},{k:"f",x:"Codice impianto",v:S["mt"+q3]||"-"})}}
 else if(x.t==="mat")r.push({k:"h3",x:x.lab},{k:"f",x:"RBW"+x.p+"- banconote",v:S["a"+x.i]||"-"},{k:"f",x:"RCW"+x.p+"- monete",v:S["c"+x.i]||"-"},{k:"f",x:"Codice impianto",v:S["mt"+x.i]||"-"});
 else if(x.t==="num")r.push({k:"f",x:x.x,v:String(+S[x.id]||0)});
 else if((x.t==="g"||x.t==="t"||x.t==="sel")&&PSKIP[view].indexOf(x.id)<0){if(x.opt&&!S[x.id])return;r.push({k:"f",x:x.x,v:S[x.id]||"-"})}});
 var nt=String(S.nte||"").trim();if(nt){r.push({k:"h",x:"Note tecniche"});pdfWrap(nt,100).forEach(function(l){r.push({k:"li",x:l})})}
 var F=PH[view]||[];if(F.length){r.push({k:"h",x:"Foto allegate"});F.forEach(function(f,j){r.push({k:"li",x:(j+1)+". "+f.n+" - in fondo al documento"})})}
 return r}
function fmtDate(dt){return p2(dt.getDate())+"/"+p2(dt.getMonth()+1)+"/"+dt.getFullYear()+" "+p2(dt.getHours())+":"+p2(dt.getMinutes())}
function pdfMeta(bl,when){var pr=prog(bl,S,0),dt=when?new Date(when):new Date();
 var tt={inst:"Checklist installazione Glory",prep:"Checklist preparazione macchine Glory",rip:"Checklist riparazione Glory",loc:"Checklist intervento in loco Glory",altro:"Attività Glory",rit:"Ritiro dispositivo Glory"},
  hl={inst:["CV: "+(S.cv||"-")].concat(S.rv?["Rivenditore: "+(S.rvn||"-")]:[],["Cliente: "+(S.cl||"-"),"Sede: "+(S.se||"-")]),prep:["CV: "+(S.cvc||"da associare")].concat(prepMode(S)==="Completa"&&prepMat("mtB")?["Matricola banconote: "+prepMat("mtB")]:[],prepMode(S)==="Completa"&&prepMat("mtM")?["Matricola monete: "+prepMat("mtM")]:[],prepMode(S)==="Completa"&&S.mtD?["Codice impianto: "+S.mtD]:[]),rip:[S.rma||!S.cv?"RMA: "+(S.rma||"-"):"CV: "+S.cv].concat(S.rv?["Rivenditore: "+(S.rvn||"-")]:[],S.cl?["Cliente: "+S.cl]:[]),loc:["Riferimento: "+(S.rf||"-")].concat(S.rv?["Rivenditore: "+(S.rvn||"-")]:[],["Cliente: "+(S.cl||"-"),"Sede: "+(S.se||"-")]),altro:[(S.tp||"Attività")+(S.ti?": "+S.ti:""),S.rf?S.rf+": "+(S.rc||"-"):"Riferimento: -"]};
 hl.rit=["Riferimento: "+(S.rf||"-")].concat(S.rv?["Rivenditore: "+(S.rvn||"-")]:[],["Cliente: "+(S.cl||"-")],S.dv==="In loco"?["Sede: "+(S.se||"-")]:[],["Ritiro: "+(S.dv||"-")+(S.mo?" · "+(S.mo==="Altro"&&S.mos?S.mos:S.mo):"")]);
 hl[view]=["Tecnico: "+(S.tec||"-"),"Data intervento: "+(dIt(S.dt)||dIt(day()))].concat(hl[view]);
 return {title:tt[view],date:fmtDate(dt),
  lines:hl[view].concat(["Voci completate: "+pr.d+" di "+pr.t])}}
function day(){var dt=new Date();return dt.getFullYear()+"-"+p2(dt.getMonth()+1)+"-"+p2(dt.getDate())}
function fcut(t,n){return String(t==null?"":t).replace(/[\\\/:*?"<>|\r\n\t]+/g," ").replace(/\s+/g," ").trim().slice(0,n).trim()}
function fdate(iso){var m=/^(\d{4})-(\d\d)-(\d\d)$/.exec(iso||"");if(m)return m[3]+"-"+m[2]+"-"+m[1].slice(2);var d=new Date();return p2(d.getDate())+"-"+p2(d.getMonth()+1)+"-"+String(d.getFullYear()).slice(2)}
function fnBase(){var o=[],rv=S.rv?fcut(S.rvn,20):"",er="";
 if(view==="loc"){er=fcut(locUnits(S).map(function(u){return String(S[u.p+"er"]||"").trim()}).filter(Boolean).join("-"),12)}
 if(view==="inst"||view==="loc")o=[rv,fcut(S.cl,30),er];
 else if(view==="rit")o=["Ritiro",fcut(S.cl,30)||fcut(S.rf,30),fcut([S.m1,S.a1].filter(Boolean).join(" "),24)];
 else if(view==="rip")o=fcut(S.rma,40)?[fcut(S.rma,40)]:[fcut(S.cv,30),fcut(S.cl,30)];
 else if(view==="prep")o=(S.m==="CI-5"&&prepMode(S)==="Downgrade CI-5")?["Downgrade CI-5"+(dgCount()?" - "+dgCount()+(dgCount()===1?" dispositivo":" dispositivi"):"")]:[fcut(S.cvc,30)||fcut(prepMat("mtM"),30)];
 else o=[fcut(S.ti,40)];
 o=o.filter(Boolean);if(!o.length)o=[V[view].title];
 return o.join(" - ")+" - "+(view==="rip"?fdate():fdate(S.dt))}
function pdfName(){return fnBase()+".pdf"}
function pdfFile(){var bl=V[view].blocks(S);return {u:buildPdf(pdfMeta(bl),pdfRows(bl)),fn:pdfName()}}
function saveFile(blob,fn,ok,ko){
 if(DLP){DLP.save({filename:fn,data:blob}).then(ok,function(e){if(!e||e.code!=="declined")ko()});return}
 try{var a=document.createElement("a"),u=URL.createObjectURL(blob);a.href=u;a.download=fn;document.body.append(a);a.click();a.remove();setTimeout(function(){URL.revokeObjectURL(u)},5000);ok()}catch(e){ko()}}
/* ---------- foto e archivio (IndexedDB, su questo dispositivo) ---------- */
var PH={},IDB=null,ARC=[];
function phRec(f){var th=f.th||f.d;try{return {n:f.n,w:f.w,h:f.h,th:th,tn:f.tn||th,b:atob(th.split(",")[1])}}catch(e){return null}}
function phSave(v){if(!IDB)return;try{var t=IDB.transaction("ph","readwrite"),F=(PH[v]||[]).map(function(f){return {n:f.n,w:f.w,h:f.h,th:f.th,tn:f.tn}});
 if(F.length)t.objectStore("ph").put(F,v);else t.objectStore("ph").delete(v);t.onerror=t.onabort=function(){svWarn(1)}}catch(e){svWarn(1)}}
function arcSort(){ARC.sort(function(a,b){return b.d-a.d})}
function phInit(done){var fin=0;function go(){if(!fin){fin=1;done()}}
 try{if(navigator.storage&&navigator.storage.persist)navigator.storage.persist().catch(function(){})}catch(e){}
 try{var rq=indexedDB.open("glory_archivio",2);
  rq.onupgradeneeded=function(){var d=rq.result;if(!d.objectStoreNames.contains("ph"))d.createObjectStore("ph");if(!d.objectStoreNames.contains("arc"))d.createObjectStore("arc",{keyPath:"id"})};
  rq.onerror=rq.onblocked=go;
  rq.onsuccess=function(){IDB=rq.result;var cnt=0;function one(){if(++cnt===2)go()}
   try{var tr=IDB.transaction(["ph","arc"]),c=tr.objectStore("ph").openCursor(),ra=tr.objectStore("arc").getAll();
    c.onsuccess=function(){var k=c.result;if(!k){one();return}if(!PH[k.key]||!PH[k.key].length)PH[k.key]=(k.value||[]).map(phRec).filter(Boolean);k.continue()};c.onerror=one;
    ra.onsuccess=function(){ARC=(ra.result||[]).filter(function(x){return x&&V[x.v]});arcSort();one()};ra.onerror=one}catch(e){go()}}}catch(e){go()}
 setTimeout(go,4000)}
function arcPut(r,ok,ko){if(!IDB){ko();return}
 try{var t=IDB.transaction("arc","readwrite");t.objectStore("arc").put(r);
  t.oncomplete=function(){ARC=ARC.filter(function(x){return x.id!==r.id});ARC.push(r);arcSort();ok()};t.onerror=t.onabort=function(){ko()}}catch(e){ko()}}
function arcDel(id,ok,ko){if(!IDB){ko();return}
 try{var t=IDB.transaction("arc","readwrite");t.objectStore("arc").delete(id);
  t.oncomplete=function(){ARC=ARC.filter(function(x){return x.id!==id});ok()};t.onerror=t.onabort=function(){ko()}}catch(e){ko()}}
function jpg(file){return new Promise(function(res){var u,im=new Image();try{u=URL.createObjectURL(file)}catch(e){res(null);return}
 im.onload=function(){try{var w=im.naturalWidth,h=im.naturalHeight,k=Math.min(1,1600/Math.max(w,h)),c=document.createElement("canvas");
  c.width=Math.max(1,Math.round(w*k));c.height=Math.max(1,Math.round(h*k));var x=c.getContext("2d");x.fillStyle="#fff";x.fillRect(0,0,c.width,c.height);x.drawImage(im,0,0,c.width,c.height);
  var d=c.toDataURL("image/jpeg",0.82);URL.revokeObjectURL(u);if(d.indexOf("data:image/jpeg;base64,")!==0){res(null);return}
  var tk=Math.min(1,480/Math.max(c.width,c.height)),tc=document.createElement("canvas");tc.width=Math.max(1,Math.round(c.width*tk));tc.height=Math.max(1,Math.round(c.height*tk));tc.getContext("2d").drawImage(c,0,0,tc.width,tc.height);
  res({n:(file.name||"foto.jpg"),w:c.width,h:c.height,b:atob(d.split(",")[1]),th:d,tn:tc.toDataURL("image/jpeg",0.6)})}catch(e){URL.revokeObjectURL(u);res(null)}};
 im.onerror=function(){URL.revokeObjectURL(u);res(null)};im.src=u})}
function photoBox(){var F=PH[view]||(PH[view]=[]),m=el("div","cnt",ui.phMsg||"");m.setAttribute("role","status");ui.phMsg="";
 app.append(el("h2",0,"Foto da allegare"+(F.length?" · "+F.length:"")),el("p","cnt","Ogni foto va in una pagina in fondo al PDF. "+(IDB?"Le foto restano salvate su questo dispositivo finché non azzeri la scheda.":"Le foto restano finché la pagina è aperta: genera il PDF prima di chiuderla.")));
 F.forEach(function(f,j){var r=el("div","rowc"),th=document.createElement("img"),inf=el("div","in");th.src=f.tn||f.th;th.alt="";th.style.cssText="width:56px;height:56px;object-fit:cover;border-radius:8px;border:1px solid var(--ln);flex:none";
  inf.style.cssText="flex:1;min-width:0;align-self:center;overflow-wrap:anywhere;font-size:15px";inf.textContent=(j+1)+". "+f.n;
  var d=ui.phDel===j?btn("nb","Elimina?",function(){F.splice(j,1);phSave(view);ui.phDel=null;render()}):btn("nb","Elimina",function(){ui.phDel=j;render()});
  d.style.cssText+=";color:var(--dg);border-color:var(--dg)"+(ui.phDel===j?";background:var(--dg);color:var(--dgo)":"");d.setAttribute("aria-label","Elimina "+f.n);
  r.append(th,inf,d);app.append(r)});
 var fi=document.createElement("input");fi.type="file";fi.accept="image/jpeg,image/*";fi.multiple=true;fi.hidden=true;
 fi.onchange=function(){var L=Array.prototype.slice.call(fi.files||[]),bad=[];fi.value="";if(!L.length)return;m.textContent="Caricamento foto…";
  Promise.all(L.map(jpg)).then(function(R){R.forEach(function(r,i){if(r)F.push(r);else bad.push(L[i].name)});ui.phMsg=bad.length?"Non lette: "+bad.join(", ")+".":"";phSave(view);render()})};
 app.append(btn("reset ac tight","+ Aggiungi foto",function(){fi.click()}),fi,m)}
function pdfGate(act,lab,m){var r=check(V[view].blocks(S)),all=r.bad.concat(r.warn);m.textContent="";
 if(!all.length){act();return}
 var bx=el("div","box wn"),sg=el("div","seg");bx.setAttribute("role","alert");bx.append(el("b",0,"Prima di generare il PDF, controlla"));wlist(bx,all);
 sg.append(btn("on",lab,function(){m.textContent="";act()}),btn("","Annulla",function(){m.textContent=""}));bx.append(sg);m.append(bx)}
var CANSH=!!(navigator.canShare&&!CL);
function dlPdf(m){var r=pdfFile();saveFile(new Blob([r.u],{type:"application/pdf"}),r.fn,function(){m.textContent="PDF salvato."},function(){m.textContent="Salvataggio non riuscito."})}
function shareFile(blob,fn,type,m,okMsg,ok){var no="Condivisione non disponibile su questo dispositivo: usa Scarica.",file;
 try{file=new File([blob],fn,{type:type})}catch(e){m.textContent=no;return}
 if(!navigator.canShare||!navigator.canShare({files:[file]})){m.textContent=no;return}
 navigator.share({files:[file],title:fn}).then(function(){m.textContent=okMsg;if(ok)ok()},function(e){if(!e||e.name!=="AbortError")m.textContent=no})}
function pdfBox(){photoBox();var m=el("div","cnt","");m.setAttribute("role","status");
 var pv=el("div","pvw");pv.hidden=true;
 var pb=btn("reset ac","Anteprima PDF",function(){pvBuild(pv,pb);pv.hidden=false;pb.textContent="Aggiorna anteprima PDF"});pb.style.marginTop="10px";
 var dd=el("div","dd inl"),db=btn("reset ac tight dbtn",(ui.dd?"Condividi e PDF ▴":"Condividi e PDF ▾"),function(){ui.dd=!ui.dd;dd.hidden=!ui.dd;db.textContent=ui.dd?"Condividi e PDF ▴":"Condividi e PDF ▾";db.setAttribute("aria-expanded",ui.dd?"true":"false")});
 db.setAttribute("aria-expanded",ui.dd?"true":"false");dd.hidden=!ui.dd;ddBuild(dd);
 app.append(pb,db,dd,m,pv)}
function pvBuild(c,pb){var bl=V[view].blocks(S),mt=pdfMeta(bl),R=pdfRows(bl),F=PH[view]||[],h,x,u;c.textContent="";
 h=el("div","pvh");h.append(el("b",0,mt.title),el("span",0,mt.date));c.append(h);
 u=el("div","pvi");mt.lines.forEach(function(l){u.append(el("div",0,l))});c.append(u);
 var stop=0;R.forEach(function(r){
  if(r.k==="h"&&r.x==="Foto allegate")stop=1;if(stop)return;
  if(r.k==="h")c.append(el("div","pvs",r.x));
  else if(r.k==="h3")c.append(el("div","pvt",r.x));
  else if(r.k==="c"){x=el("div","pvc"+(r.d?" on":""),(r.d?"☑ ":"☐ ")+r.x);c.append(x)}
  else if(r.k==="f"){x=el("div","pvf");x.append(el("span",0,r.x),el("b",0,r.v));c.append(x)}
  else if(r.k==="dv"){x=el("div","pvf");x.append(el("span",0,r.x+" · "+r.v),el("b",0,r.m.map(function(q){return (q[1]?"☑ ":"☐ ")+q[0]}).join("  ")));c.append(x)}
  else if(r.k==="tl")c.append(el("div","pvc on",r.x));
  else if(r.k==="nt")c.append(el("div","pvn","Nota: "+r.x));
  else if(r.k==="li")c.append(el("div","pvn",r.x))});
 if(F.length){c.append(el("div","pvs","Foto allegate"));x=el("div","pvp");F.forEach(function(f,j){var i=document.createElement("img");i.src=f.tn||f.th;i.alt=f.n;x.append(i)});c.append(x)}
 var cl=btn("reset tight","Chiudi anteprima",function(){c.hidden=true;c.textContent="";pb.textContent="Anteprima PDF"});c.append(cl)}

/* ---------- genera RMA ---------- */
function rmaLoad(){var o=null;try{o=JSON.parse(lsGet("gla_rmagen"))}catch(e){}return o&&typeof o==="object"&&!Array.isArray(o)?o:{}}
function rmaView(){view="";ttl.textContent="Genera RMA";back.hidden=false;gear.hidden=true;clearPassi();closeOv();app.textContent="";noteTa=null;
 var R=rmaLoad(),out=el("div","rmaout"),om=el("div","cnt","");om.setAttribute("role","status");
 function sv(){lsSet("gla_rmagen",JSON.stringify(R))}
 function upd(){var g=rmaGen(R);out.textContent=g||"—";out.classList.toggle("empty",!g)}
 function fld(id,lab,ph){var f=el("div","fld"),i=document.createElement("input");i.type="text";i.placeholder=ph;i.value=R[id]||"";i.setAttribute("aria-label",lab);f.append(el("label",0,lab),i);
  i.oninput=function(){R[id]=i.value;sv();upd()};app.append(f);return i}
 function seg(id,lab,opts){var f=el("div","fld"),g=el("div","seg");f.append(el("label",0,lab));
  opts.forEach(function(o){var b=btn(R[id]===o?"on":"",o,function(){R[id]=R[id]===o?0:o;sv();rmaView()});b.setAttribute("aria-pressed",R[id]===o?"true":"false");g.append(b)});f.append(g);app.append(f)}
 app.append(el("p","cnt","Per una macchina appena arrivata in laboratorio: compila i dati e copia il codice RMA."));
 var rv=btn("chk"+(R.rv?" on":""),null,function(){R.rv=R.rv?0:1;sv();rmaView()});rv.append(el("span","bx",R.rv?"✓":""),el("span","lb","Tramite rivenditore"));rv.setAttribute("aria-pressed",R.rv?"true":"false");app.append(rv);
 if(R.rv)fld("rvn","Rivenditore","Nome rivenditore");
 fld("cl","Cliente","Nome cliente");
 seg("r1_tp","Tipo di modulo",["Banconote","Monete"]);
 seg("r1_md","Modello",["CI-5","CI-10","CI-10X"]);
 var mi=modInfo(R,"r1_");fld("r1_mat","Matricola"+(mi.sig?" "+mi.sig:""),"Numero di matricola");
 fld("r1_er","Codice errore","Es. 1234");
 app.append(el("h2",0,"Codice RMA"),out);upd();
 var cb=btn("reset ac tight","Copia RMA",function(){var g=rmaGen(R);if(!g){om.textContent="Compila almeno cliente, modello e matricola.";return}cpy(g,function(){cb.textContent="Copiato";setTimeout(function(){cb.textContent="Copia RMA"},1800)},function(){om.textContent="Copia non riuscita: seleziona il codice e copialo a mano."})});
 var ub=btn("reset ac tight","Apri una riparazione con questi dati",function(){var cur=load("rip");if(hasData(cur)&&!ui.rmaOk){ui.rmaOk=1;rmaView();return}rmaToRip(R)});
 var ab=btn("reset ac tight","Archivia RMA: macchina in attesa di riparazione",function(){rmaArc(R,om)});
 app.append(cb,ab,ub,om);
 if(ui.rmaOk)app.append(confirmBox("In Riparazioni in laboratorio c'è già una scheda in corso: verrà sostituita. Continuare?","Sostituisci",function(){ui.rmaOk=0;rmaToRip(R)},function(){ui.rmaOk=0;rmaView()}));
 app.append(btn("reset tight","Nuovo RMA (svuota i campi)",function(){R={};sv();rmaView()}))}
function rmaArc(R,om){var g=rmaGen(R);
 if(!String(R.cl||R.rvn||"").trim()||!R.r1_md||!String(R.r1_mat||"").trim()){om.textContent="Per archiviare servono almeno cliente, modello e matricola.";return}
 if(!IDB){om.textContent="Archivio non disponibile in questo browser.";return}
 var tc=load("rip").tec,s={grm:1};if(tc)s.tec=tc;["rv","rvn","cl","r1_tp","r1_md","r1_mat","r1_er"].forEach(function(k){if(R[k])s[k]=R[k]});s.rma=g;
 var r={id:Date.now(),v:"rip",d:Date.now(),n:g+(R.cl?" - "+fcut(R.cl,30):""),s:s,ph:[],st:"attesa"};
 arcPut(r,function(){lsSet("gla_rmagen","{}");rmaView();var m2=app.querySelector("[role=status]");topMsg="";if(m2)m2.textContent="RMA "+g+" archiviato. Quando fai la riparazione: Archivio → tocca il lavoro → Riapri."},function(){om.textContent="Archiviazione non riuscita."})}
function rmaToRip(R){var tc=load("rip").tec,s={grm:1};if(tc)s.tec=tc;["rv","rvn","cl","r1_tp","r1_md","r1_mat","r1_er"].forEach(function(k){if(R[k])s[k]=R[k]});s.rma=rmaGen(s);
 lsSet("gla_rip",JSON.stringify(s));siSet("rip",0);PH.rip=[];phSave("rip");topMsg="Scheda riparazione aperta con i dati dell'RMA.";location.hash="#rip"}

/* ---------- archivio lavori ---------- */
function arcBox(){app.append(el("h2",0,"Archivio"));var m=el("div","cnt",arcMsg);m.setAttribute("role","status");arcMsg="";
 if(!IDB){app.append(el("p","cnt","Archivio non disponibile in questo browser: usa Scarica backup dal menù."));return}
 if(!ui.arc){app.append(btn("reset ac tight",S._arc?"Aggiorna nell'archivio":"Archivia o metti in pausa",function(){if(!hasData(S)){arcMsg="Scheda vuota: niente da archiviare.";render();return}ui.arc=1;render()}))}
 else{var bx=el("div","box wn"),sg=el("div","seg");bx.dataset.id="arcb";
  bx.append(el("div",0,(S._arc?"Aggiorno nell'archivio il lavoro «":"Salvo nell'archivio di questo dispositivo il lavoro «")+fnBase()+"», con note e foto."));
  sg.append(btn("on","Lavoro concluso",function(){arcSave(1,"fatto")}),btn("","Metti in pausa",function(){arcSave(1,"corso")}),btn("","Salva e continua",function(){arcSave(0,"corso")}),btn("","Annulla",function(){ui.arc=0;render()}));
  bx.append(sg,el("div","cnt","«Lavoro concluso» e «Metti in pausa» svuotano la scheda. Il lavoro in pausa si riprende da Archivio › In corso › Riapri."));app.append(bx)}
 app.append(m)}
function arcSave(clr,st){if(st==="fatto"&&!String(S.tec||"").trim()){ui.arc=0;arcMsg="";topMsg="Per chiudere il lavoro serve il nome del tecnico.";jump("tec");return}
 if(clr)tmHalt(S);var id=S._arc||Date.now(),s=JSON.parse(JSON.stringify(S)),nt="",uu=s._u;delete s._arc;delete s._u;
 try{if(V[view].blocks(S).some(function(x){return x.t==="n"}))nt=noteText()}catch(e){}
 var r={id:id,v:view,d:Date.now(),n:fnBase(),s:s,ph:phOf(view),st:st,nt:nt};if(uu)r.u=uu;
 arcPut(r,function(){ui.arc=0;
  if(clr){var tc=S.tec;S={};if(tc)S.tec=tc;PH[view]=[];phSave(view);siSet(view,0);arcMsg=st==="corso"?"Lavoro messo in pausa: lo ritrovi in Archivio › In corso.":"Lavoro concluso e archiviato. Scheda svuotata."}
  else{S._arc=id;arcMsg="Lavoro salvato nell'archivio (in corso)."}
  save();render()},function(){ui.arc=0;arcMsg="Archiviazione non riuscita: scarica un backup dal menù.";render()})}
function arcApply(r){var s=JSON.parse(JSON.stringify(r.s));s._arc=r.id;s._u=r.u||devId()+"-"+r.id;lsSet("gla_"+r.v,JSON.stringify(s));siSet(r.v,0);PH[r.v]=bkPh(r.ph);phSave(r.v);topMsg="Lavoro riaperto dall'archivio. Quando hai finito usa «Aggiorna nell'archivio» in fondo alla scheda.";location.hash="#"+r.v}
function arcNote(r){if(r.nt)return r.nt;var v0=view,s0=S,t="";view=r.v;S=mig(r.v,JSON.parse(JSON.stringify(r.s)));try{if(V[r.v].blocks(S).some(function(x){return x.t==="n"}))t=noteText()}catch(e){}view=v0;S=s0;return t}
function arcPdf(r,m){var v0=view,s0=S,p0=PH[r.v],out=null;view=r.v;S=mig(r.v,JSON.parse(JSON.stringify(r.s)));PH[r.v]=bkPh(r.ph);
 try{var bl=V[r.v].blocks(S),mt=pdfMeta(bl,r.d);mt.fn=r.n+".pdf";out={u:buildPdf(mt,pdfRows(bl)),fn:r.n+".pdf"}}catch(e){out=null}
 view=v0;S=s0;PH[r.v]=p0;
 if(!out){m.textContent="PDF non riuscito.";return}
 saveFile(new Blob([out.u],{type:"application/pdf"}),out.fn,function(){m.textContent="PDF salvato."},function(){m.textContent="Salvataggio non riuscito."})}
function arcTxt(r){var s=r.s||{};return (r.n+" "+(V[r.v]?V[r.v].title:"")+" "+Object.keys(s).map(function(k){return typeof s[k]==="string"?s[k]:""}).join(" ")).toLowerCase()}
/* ---------- esportazione dell'archivio per il programma sul PC ---------- */
function devId(){var d=lsGet("gla_dev");if(!d){d=Math.random().toString(36).slice(2,8)+Date.now().toString(36).slice(-4);lsSet("gla_dev",d)}return d}
function pcNew(){return ARC.filter(function(r){return !r.xd||r.d>r.xd})}
function pcFile(L){var D=devId(),tec=String((L[0]&&L[0].s&&L[0].s.tec)||lsGet("gla_tec")||"").trim();
 return {t:JSON.stringify({glory:2,pc:1,dev:D,saved:Date.now(),tec:tec,arc:L.map(function(r){var o=JSON.parse(JSON.stringify(r));o.u=r.u||D+"-"+r.id;o.tec=String((r.s&&r.s.tec)||tec||"").trim();delete o.xd;return o})}),
  fn:"Archivio Glory"+(tec?" - "+fcut(tec,30):"")+" - "+L.length+(L.length===1?" lavoro":" lavori")+" - "+fdate()+".txt"}}
function pcMark(L,done){var n=L.length,t=Date.now();if(!n){done();return}var D=devId();lsSet("gla_lastpc",String(t));L.forEach(function(r){var x=JSON.parse(JSON.stringify(r));x.xd=t;x.u=r.u||D+"-"+r.id;arcPut(x,fin,fin)});function fin(){if(--n<=0)done()}}
function pcBox(){var N=pcNew(),bx=el("div","pcx"),m=el("div","cnt","");m.setAttribute("role","status");var gd=GD.ok&&lsGet("gla_gd")==="1";
 function go(L,share,sh){if(!L.length){m.textContent="Niente da esportare.";return}var f=pcFile(L),bl=new Blob([f.t],{type:"text/plain"}),ok=function(){pcMark(L,function(){arcMsg=(L.length===1?"Inviato 1 lavoro":"Inviati "+L.length+" lavori")+(gd&&!sh?" su Google Drive.":" per il PC.");arcView()})};
  /* Google Drive collegato: il file va direttamente nella cartella condivisa */
  if(gd&&!sh&&navigator.onLine){if(!gTokC()){lsSet("gla_gsend",L.length===ARC.length&&L.length!==pcNew().length?"all":"new");gLogin("send");return}
   m.textContent="Invio su Google Drive…";gUp(f.t,f.fn).then(ok,function(e){if(e&&e.message==="login"){lsSet("gla_gsend","new");gLogin("send");return}
    m.textContent="Invio su Google Drive non riuscito. ";m.append(btn("reset tight","Condividi il file",function(){go(L,1,1)}))});return}
  if(share&&CANSH)shareFile(bl,f.fn,"text/plain",m,"",ok);else saveFile(bl,f.fn,ok,function(){m.textContent="Salvataggio non riuscito."})}
 var sg=el("div","seg");sg.append(btn(N.length?"on":"","Invia al PC · "+N.length+(N.length===1?" nuovo":" nuovi"),function(){go(pcNew(),1)}),btn("","Tutto ("+ARC.length+")",function(){go(ARC.slice(),1)}));
 bx.append(sg,m);
 if(GD.ok){var gr=el("div","cnt");if(gd){gr.append(document.createTextNode("Invio diretto su Google Drive · "));gr.append(btn("lnk","Scollega",function(){lsSet("gla_gd","0");arcView()}))}
  else gr.append(btn("reset tight","Collega Google Drive",function(){gLogin("link")}));bx.append(gr)}
 bx._go=function(w){go(w==="all"?ARC.slice():pcNew(),1)};return bx}
function arcView(){if(GBK){var g=GBK;GBK=null;if(g.ok){lsSet("gla_gd","1");if(g.st==="send")GSEND=lsGet("gla_gsend")||"new";else arcMsg="Google Drive collegato: «Invia al PC» carica i lavori direttamente nella cartella."}else arcMsg="Accesso a Google "+(g.err==="access_denied"?"annullato.":"non riuscito.")}
 view="";ttl.textContent="Archivio lavori";back.hidden=false;gear.hidden=true;clearPassi();closeOv();app.textContent="";noteTa=null;
 var m=el("div","cnt",arcMsg);m.setAttribute("role","status");arcMsg="";
 var q=document.createElement("input");q.type="text";q.placeholder="Cerca cliente, CV, RMA, matricola…";q.setAttribute("aria-label","Cerca nell'archivio");q.value=ui.q||"";
 var fs=el("div","fld");fs.append(q);
 var tf=el("div","seg");tf.className="seg fsm";tf.style.marginBottom="12px";
 [["","Tutti"],["att","In attesa"],["cor","In corso"],["fat","Conclusi"],["inst","Installazioni"],["prep","Preparazioni"],["rip","Riparazioni"],["loc","In loco"],["altro","Altro"],["rit","Ritiri"]].forEach(function(o){tf.append(btn((ui.tf||"")===o[0]?"on":"",o[1],function(){ui.tf=o[0];arcView()}))});
 var L=el("div");
 function draw(){L.textContent="";var t=String(q.value||"").toLowerCase().trim(),
   F=ARC.filter(function(r){return (!ui.tf||(ui.tf==="att"?r.st==="attesa":ui.tf==="cor"?r.st==="corso":ui.tf==="fat"?(!r.st||r.st==="fatto"):r.v===ui.tf))&&(!t||arcTxt(r).indexOf(t)>=0)});
  if(!ARC.length){L.append(el("p","cnt","Nessun lavoro archiviato. Dalla scheda usa «Archivia lavoro» a fine intervento."));return}
  if(!F.length){L.append(el("p","cnt","Nessun risultato."));return}
  L.append(el("p","cnt",F.length+(F.length===1?" lavoro":" lavori")));
  F.forEach(function(r){var fat=!r.st||r.st==="fatto",c=btn("card "+(fat?"aok":r.st==="corso"?"acor":"aatt")+(ui.ao===r.id?" arcc":""),null,function(){ui.ao=ui.ao===r.id?0:r.id;ui.ad=0;ui.ap=0;draw()});
   var np=(r.ph&&r.ph.length)||0;
   c.append(el("b",0,(fat?"✓ ":"")+r.n),el("span",0,(r.st==="attesa"?"In attesa di riparazione":(r.st==="corso"?"In corso · ":"Concluso · ")+(V[r.v]?V[r.v].title:r.v))+" · "+fmtDate(new Date(r.d))+(np?" · "+np+" foto":"")));
   c.setAttribute("aria-expanded",ui.ao===r.id?"true":"false");L.append(c);
   if(ui.ao!==r.id)return;
   var sg=el("div","seg");sg.style.marginBottom="10px";
   sg.append(btn("on","Riapri",function(){var cur=load(r.v);if(hasData(cur)&&cur._arc!==r.id){ui.ap=r.id;ui.ad=0;draw()}else arcApply(r)}),
    btn("","Copia note",function(){var t=arcNote(r);if(!t){m.textContent="Questo lavoro non ha note per il rapportino.";return}cpy(t,function(){m.textContent="Note copiate."},function(){m.textContent="Copia non riuscita."})}),
    btn("","PDF",function(){arcPdf(r,m)}),
    btn("","Elimina",function(){ui.ad=r.id;ui.ap=0;draw()}));
   L.append(sg);
   if(ui.ap===r.id)L.append(confirmBox("Nella scheda "+V[r.v].title+" c'è un lavoro in corso non archiviato: verrà sostituito. Continuare?","Sostituisci",function(){arcApply(r)},function(){ui.ap=0;draw()}));
   if(ui.ad===r.id)L.append(confirmBox("Eliminare definitivamente «"+r.n+"» dall'archivio?","Elimina",function(){arcDel(r.id,function(){ui.ad=0;ui.ao=0;arcMsg="Lavoro eliminato dall'archivio.";arcView()},function(){ui.ad=0;arcMsg="Eliminazione non riuscita.";arcView()})},function(){ui.ad=0;draw()}));
   var sp=el("div");sp.style.height="8px";L.append(sp)})}
 q.oninput=function(){ui.q=q.value;draw()};
 var pb=pcBox();app.append(pb,fs,tf,m,L);draw();if(GSEND){var w=GSEND;GSEND="";pb._go(w)}
 if(!IDB)app.append(el("p","cnt","Archivio non disponibile in questo browser."))}

/* ---------- backup della scheda (file) ---------- */
function bkFile(){var F=phOf(view),o=JSON.parse(JSON.stringify(S));if(!o._u&&o._arc)o._u=devId()+"-"+o._arc;
 return {t:JSON.stringify({glory:2,view:view,saved:day(),s:o,ph:F}),fn:"Scheda Glory - "+fnBase()+".txt"}}
function hasData(s){return Object.keys(s).some(function(k){return k!=="tec"&&k!=="_arc"&&k!=="_u"&&k!=="_tp"&&k!=="dt"})}
function phOf(v){return (PH[v]||[]).map(function(f){return {n:f.n,w:f.w,h:f.h,d:f.th}})}
function bkPh(a){var ph=[];(Array.isArray(a)?a:[]).forEach(function(f){try{if(f&&typeof f.d==="string"&&f.d.indexOf("data:image/jpeg;base64,")===0)ph.push({n:String(f.n||"foto.jpg"),w:+f.w||1,h:+f.h||1,b:atob(f.d.split(",")[1]),th:f.d})}catch(e){}});return ph}
function bkOk(s){return s&&typeof s==="object"&&!Array.isArray(s)}
function bkRead(txt){var o,it=[],arc=[];try{o=JSON.parse(txt)}catch(e){return null}
 if(!o||o.glory!==2)return null;
 if(o.all){NEWS.forEach(function(r){var x=o.sc&&o.sc[r[0]];if(x&&bkOk(x.s))it.push({v:r[0],s:x.s,ph:bkPh(x.ph)})});
  if(Array.isArray(o.arc))arc=o.arc.filter(function(x){return x&&x.id&&V[x.v]&&bkOk(x.s)}).map(function(x){return {id:x.id,v:x.v,d:+x.d||Date.now(),n:String(x.n||V[x.v].title),s:x.s,ph:Array.isArray(x.ph)?x.ph:[],st:/^(attesa|corso|fatto)$/.test(x.st)?x.st:undefined,nt:typeof x.nt==="string"?x.nt:""}});
  return (it.length||arc.length)?{all:1,it:it,arc:arc}:null}
 if(!V[o.view]||!bkOk(o.s))return null;
 return {all:0,it:[{v:o.view,s:o.s,ph:bkPh(o.ph)}]}}
function bkAll(){var sc={},n=0;NEWS.forEach(function(r){var s=load(r[0]);if(hasData(s)){sc[r[0]]={s:s,ph:phOf(r[0])};n++}});
 n+=ARC.length;
 return {n:n,t:JSON.stringify({glory:2,all:1,saved:day(),sc:sc,arc:ARC}),fn:"Backup completo - "+fdate()+".json"}}
function bkMark(){lsSet("gla_lastbk",String(Date.now()))}
function bkApply(r){var da="";
 /* scheda passata da un collega: resta lo stesso lavoro (codice _u), il tecnico diventa chi la riceve */
 if(!r.all)r.it.forEach(function(x){var s=x.s,me=tecRm()?String(lsGet("gla_tec")||"").trim():"",t=String(s.tec||"").trim();delete s._arc;
  if(me&&t&&t!==me){s._tp=(Array.isArray(s._tp)?s._tp:[]).filter(function(y){return y!==t&&y!==me}).concat(t);s.tec=me;da=t}});
 r.it.forEach(function(x){lsSet("gla_"+x.v,JSON.stringify(x.s));siSet(x.v,0);PH[x.v]=x.ph;phSave(x.v)});ui.bkPend=null;
 if(r.all){var na=(r.arc||[]).length,parts=[];
  if(r.it.length)parts.push("schede "+r.it.map(function(x){return V[x.v].title}).join(", "));
  if(na)parts.push(na+(na===1?" lavoro":" lavori")+" in archivio");
  bkMsg="Backup completo caricato: "+parts.join(" e ")+".";
  if(!na){home();return}
  var left=na,fail=0;(r.arc||[]).forEach(function(x){arcPut(x,fin,function(){fail++;fin()})});
  function fin(){if(--left)return;if(fail)bkMsg+=" "+fail+" lavori non importati.";home()}
  return}
 var x=r.it[0];topMsg=(da?"Scheda di "+da+" caricata":"Scheda caricata")+": riprendi da dove era rimasta.";
 if(view===x.v){S=x.s;rui();render()}else{location.hash="#"+x.v}}
function pendBox(refresh){var r=ui.bkPend,x=r.it[0],t=r.it.map(function(y){return V[y.v].title}).join(", "),msg;
 if(r.all)msg=(r.it.length?"Il backup completo sostituisce le schede: "+t+". Le altre non vengono toccate. ":"")+((r.arc&&r.arc.length)?"I "+r.arc.length+" lavori del backup vengono aggiunti all'archivio (quelli già presenti vengono aggiornati). ":"")+"Sei sicuro?";
 else{var d=hasData(load(x.v));msg=(view&&view!==x.v?"Il file è una scheda di "+t+": verrà caricata lì. ":"")+(d?"Nella scheda "+t+" c'è un lavoro in corso: verrà sostituito da quello del file. Continuare?":"Caricare il file nella scheda "+t+"?")}
 return confirmBox(msg,r.all?"Carica":(hasData(load(x.v))?"Sostituisci":"Carica"),function(){bkApply(r)},function(){ui.bkPend=null;refresh()})}
function bkUi(refresh,cls){var m=el("div","cnt",bkMsg),fi=document.createElement("input");m.setAttribute("role","status");bkMsg="";
 fi.type="file";fi.accept=DOCACC;fi.hidden=true;
 fi.onchange=function(){var f=fi.files&&fi.files[0];fi.value="";if(!f)return;var rd=new FileReader();
  rd.onload=function(){var r=bkRead(String(rd.result||""));if(!r){bkMsg="File non valido: scegli un backup Glory.";refresh();return}
   if(r.all&&view){bkMsg="È un backup completo: caricalo dal menù principale.";refresh();return}
   var mis=!r.all&&view&&r.it[0].v!==view,busy=r.it.some(function(x){return hasData(load(x.v))});
   if(busy||mis||r.all){ui.bkPend=r;refresh()}else bkApply(r)};
  rd.onerror=function(){bkMsg="Lettura del file non riuscita.";refresh()};rd.readAsText(f)};
 return {m:m,fi:fi,load:btn(cls||"","Carica backup",function(){fi.click()})}}
function bkRow(u,get,empty){var row=el("div","seg");
 row.append(btn("","Scarica backup",function(){var r=get();if(!r){u.m.textContent=empty;return}saveFile(new Blob([r.t],{type:"application/json"}),r.fn,function(){bkMark();u.m.textContent="Backup salvato."},function(){u.m.textContent="Salvataggio non riuscito."})}));
 row.append(u.load);return row}
function bkLast(){var t=+lsGet("gla_lastbk")||0,busy=ARC.length||NEWS.some(function(r){return hasData(load(r[0]))}),d,x;
 if(!t)x=el("div","cnt","Nessun backup eseguito");else{d=new Date(t);x=el("div","cnt","Ultimo backup: "+p2(d.getDate())+"-"+p2(d.getMonth()+1)+"-"+String(d.getFullYear()).slice(2)+" "+p2(d.getHours())+":"+p2(d.getMinutes()))}
 if(busy&&(!t||Date.now()-t>864e5))x.classList.add("bw");return x}

/* ---------- modifiche alla struttura della scheda ---------- */
function delPz(pf,j){var N={},k,m,i,re=new RegExp("^"+pf+"pz(\\d+)$");for(k in S){m=re.exec(k);if(m){i=+m[1];if(i===j)continue;N[pf+"pz"+(i>j?i-1:i)]=S[k]}else N[k]=S[k]}N[pf+"np"]=(+S[pf+"np"]||1)-1;S=N;save()}
function devN(s){if(s.n!=null&&s.n!==""&&!isNaN(+s.n))return +s.n;return Object.keys(s).some(function(k){return /^(m|a|c|mt)1$|^(nt_)?d1_/.test(k)})?1:0}
function devSort(){var n=devN(S),O={"CI-5":0,"CI-10":1,"CI-10X":2},ix=[],mp={},N={},i,k,m,d;for(i=1;i<=n;i++)ix.push(i);
 ix.sort(function(a,b){var x=O[S["m"+a]],y=O[S["m"+b]];x=x==null?9:x;y=y==null?9:y;return x-y||a-b});ix.forEach(function(o,j){mp[o]=j+1});
 for(k in S){m=/^(m|a|c|mt)(\d+)$/.exec(k);d=/^(nt_)?d(\d+)_(.+)$/.exec(k);
  if(m&&mp[+m[2]])N[m[1]+mp[+m[2]]]=S[k];else if(d&&mp[+d[2]])N[(d[1]||"")+"d"+mp[+d[2]]+"_"+d[3]]=S[k];else N[k]=S[k]}
 S=N}
function addDev(md){var n=devN(S);S.n=n+1;S["m"+(n+1)]=md;devSort();save();render()}
function delDev(j){var n=devN(S),N={},k,m,d,i;
 for(k in S){m=/^(m|a|c|mt)(\d+)$/.exec(k);d=/^(nt_)?d(\d+)_(.+)$/.exec(k);
  if(m){i=+m[2];if(i===j)continue;N[m[1]+(i>j?i-1:i)]=S[k]}
  else if(d){i=+d[2];if(i===j)continue;N[(d[1]||"")+"d"+(i>j?i-1:i)+"_"+d[3]]=S[k]}
  else N[k]=S[k]}
 N.n=n-1;S=N;save()}
function devDlg(){var d=ui.dlg,nw=!!d.nw,i=d.i,md=d.md||(nw?d.nw:S["m"+i]),px=PX[md]||"",ov=el("div","ovl"),bx=el("div","dlg"),F={};
 ov.setAttribute("role","dialog");ov.setAttribute("aria-modal","true");
 bx.append(el("h2",0,nw?"Nuovo dispositivo":"Dispositivo "+i));
 if(nw)bx.append(el("p","cnt","Compila le matricole ora oppure più tardi toccando la riga del dispositivo."));
 var msg=el("div","seg mseg");["CI-5","CI-10","CI-10X"].forEach(function(m){var mb=btn(md===m?"on":"",m,function(){d.v={a:F.a.value,c:F.c.value,mt:F.mt.value};d.md=m;render()});mb.setAttribute("aria-pressed",md===m?"true":"false");msg.append(mb)});bx.append(msg);
 [["a","RBW"+px+"- banconote","Numero di matricola"],["c","RCW"+px+"- monete","Numero di matricola"],["mt","Codice impianto","Codice impianto"]].forEach(function(f){var fd=el("div","fld"),inp=document.createElement("input");inp.type="text";inp.placeholder=f[2];inp.value=d.v?(d.v[f[0]]||""):nw?"":(S[f[0]+i]||"");inp.setAttribute("aria-label",f[1]);fd.append(el("label",0,f[1]),inp);bx.append(fd);F[f[0]]=inp;
  if(f[0]!=="mt"){var fr=freeSer(f[0]==="a"?"B":"C",md,nw?0:i);if(fr.length){var cs=el("div","chips");cs.append(el("span",0,"Dal DDT:"));
   fr.forEach(function(n){var ch=btn("chip"+(inp.value===n?" on":""),n,function(){inp.value=n;Array.prototype.forEach.call(cs.querySelectorAll(".chip"),function(z){z.classList.toggle("on",z===ch)})});ch.setAttribute("aria-label","Usa la matricola "+n);cs.append(ch)});bx.append(cs)}}});
 function close(){ui.dlg=null;render()}
 var sg=el("div","seg");sg.append(btn("on",nw?"Aggiungi":"Conferma",function(){var v={a:F.a.value.trim(),c:F.c.value.trim(),mt:F.mt.value.trim()};
   if(nw){var n=devN(S)+1;S.n=n;S["m"+n]=md;["a","c","mt"].forEach(function(k){if(v[k])S[k+n]=v[k]});devSort();save();close();return}
   ["a","c","mt"].forEach(function(k){if(v[k])S[k+i]=v[k];else delete S[k+i]});S["m"+i]=md;devSort();save();
   var nx=nextDev(i);if(nx){ui.dlg={i:nx};pend="cnt";render()}else close()}),btn("","Annulla",close));bx.append(sg);
 if(!nw){if(!d.del)bx.append(btn("reset dgo tight","Elimina dispositivo",function(){ui.dlg.del=1;render()}));
  else bx.append(confirmBox("Eliminare il Dispositivo "+i+" e tutte le sue spunte?","Elimina",function(){delDev(i);close()},function(){ui.dlg.del=0;render()}))}
 ov.append(bx);return ov}
function confirmBox(msg,yes,onYes,onNo){var bx=el("div","box"),sg=el("div","seg");bx.append(el("div",0,msg));sg.append(btn("dgf",yes,onYes),btn("","Annulla",onNo));bx.append(sg);return bx}
function pick(label,n,sel,name,onSel){var bx=el("div","fld");bx.append(el("label",0,label));
 for(var k=1;k<=n;k++)(function(k){var r=btn("chk"+(sel===k?" on dg":""),null,function(){onSel(k)});r.append(el("span","bx",sel===k?"✓":""),el("span","lb",name(k)));bx.append(r)})(k);
 return bx}

/* ---------- installazione come app ---------- */
var BIP=null;
window.addEventListener("beforeinstallprompt",function(e){e.preventDefault();BIP=e;if(started&&!view&&!location.hash.replace("#",""))home()});
window.addEventListener("appinstalled",function(){BIP=null;if(started&&!view&&!location.hash.replace("#",""))home()});

/* ---------- aggiornamenti ---------- */
var NEWV=0,updMsg="";
function updCheck(manual){
 if(manual&&!navigator.onLine){updMsg="Sei offline: collegati a internet e riprova.";home();return}
 if(manual){updMsg="Controllo in corso…";home()}
 fetch(BASE+"version.json?t="+Date.now(),{cache:"no-store"}).then(function(r){return r.ok?r.json():Promise.reject()}).then(function(j){var nv=+(j&&j.ver)||0;
  if(nv>VER){NEWV=nv;updMsg="";if(SOLO&&view)render()}else if(manual)updMsg="L'app è già aggiornata.";
  if(manual||NEWV){if(!view&&!location.hash.replace("#",""))home()}},
  function(){if(manual){updMsg="Controllo non riuscito: verifica la connessione e riprova.";if(!view&&!location.hash.replace("#",""))home()}})}
function updApply(){updMsg="Aggiornamento in corso…";if(!SOLO)home();var p=[];
 try{if(window.caches)p.push(caches.keys().then(function(k){return Promise.all(k.filter(function(x){return /^glory-v/.test(x)}).map(function(x){return caches.delete(x)}))}))}catch(e){}
 try{if(navigator.serviceWorker)p.push(navigator.serviceWorker.getRegistrations().then(function(r){return Promise.all(r.map(function(x){return x.update().catch(function(){})}))}))}catch(e){}
 function go(){try{location.replace(location.pathname+"?v="+(NEWV||Date.now()))}catch(e){location.reload()}}
 Promise.all(p).then(go,go)}

/* ---------- menù ---------- */
var DESC={inst:"Dal contratto alla consegna al cliente",prep:"Configurazione e imballo in magazzino",rip:"Diagnosi, ricambi e collaudo dei moduli",loc:"Guasti, aggiornamenti e collaudo dal cliente",altro:"Lavori fuori dalle schede standard",rit:"Macchine dismesse, rubate o danneggiate"};
function home(){
 view="";ttl.textContent="Glory 2.0";back.hidden=true;gear.hidden=false;clearPassi();closeOv();app.textContent="";noteTa=null;
 if(NEWV)app.append(btn("reset ac tight","È disponibile un aggiornamento: tocca per aggiornare",updApply));
 if(BIP)app.append(btn("reset ac tight","Installa l'app su questo dispositivo",function(){var p=BIP;BIP=null;try{p.prompt();p.userChoice.then(home,home)}catch(e){home()}}));
 var SQ=lsGet("gla_vista")==="passi",tl=el("div","tiles");document.body.classList.toggle("pv",SQ);NEWS.forEach(function(r){var s=load(r[0]),p=prog(V[r[0]].blocks(s),s,1),a=el("a",SQ?"tile":"card"),busy=hasData(s);
  a.href="#"+r[0];a.append(el("b",0,V[r[0]].title));
  if(!SQ){a.append(el("span",0,busy?(s.tmA?"⏱ ":"")+(s._arc?"Lavoro riaperto dall'archivio · ":"Scheda in corso · ")+p.d+" di "+p.t:DESC[r[0]]));app.append(a);return}
  if(busy){var br=el("div","bar"),bi=document.createElement("i");bi.style.width=(p.t?p.d/p.t*100:0)+"%";br.append(bi);a.classList.add("busy");
   a.append(br,el("span",0,(s.tmA?"⏱ ":"")+(s._arc?"Riaperto dall'archivio · ":"In corso · ")+p.d+" di "+p.t+(String(s.cl||s.rma||s.cvc||s.ti||"").trim()?" · "+String(s.cl||s.rma||s.cvc||s.ti).trim():"")))}
  else a.append(el("span",0,DESC[r[0]]));tl.append(a)});if(SQ)app.append(tl);
 app.append(el("h2",0,"RMA"),el("div","cnt","Codice RMA per una macchina appena arrivata."),btn("reset ac tight","Genera RMA",function(){location.hash="#rma"}));
 var NP=pcNew(),lp=+lsGet("gla_lastpc")||0,old=NP.length?Math.min.apply(null,NP.map(function(r){return r.d})):0,gg=NP.length?Math.floor((Date.now()-Math.max(lp,old))/864e5):0,
  ai=el("div","cnt"+(gg>=3?" bw":""),ARC.length?ARC.length+(ARC.length===1?" lavoro archiviato":" lavori archiviati")+(NP.length?" · "+NP.length+" da inviare al PC"+(gg>=3?" · ultimo invio "+(lp?gg+" giorni fa":"mai"):""):""):"Nessun lavoro archiviato. A fine intervento usa «Archivia lavoro» in fondo alla scheda.");
 app.append(el("h2",0,"Archivio"),ai,btn("reset ac tight",NP.length?"Apri archivio · "+NP.length+" da inviare":"Apri archivio lavori",function(){location.hash="#arc"}));
 app.append(el("h2",0,"Backup"));var u=bkUi(home);app.append(bkLast(),el("p","cnt","Il backup completo comprende le schede in corso e tutto l'archivio."),bkRow(u,function(){var r=bkAll();return r.n?r:null},"Niente da salvare: nessuna scheda compilata e archivio vuoto."),u.fi,u.m);if(ui.bkPend)app.append(pendBox(home));
 if(!LS)app.append(el("p","cnt","Questo browser non conserva i dati: genera PDF e note prima di chiudere la pagina."));
 app.append(el("h2",0,"Aggiornamenti"));
 app.append(btn("reset tight"+(NEWV?" ac":""),NEWV?"Aggiorna ora":"Cerca aggiornamenti",function(){if(NEWV)updApply();else updCheck(1)}));
 if(updMsg){var um=el("div","cnt",updMsg);um.setAttribute("role","status");app.append(um)}
 var vp=el("p","cnt","Glory 2.0");vp.title="Build "+VER;vp.style.cssText="text-align:center;margin-top:24px";app.append(vp)}

/* ---------- scheda ---------- */
function rstBox(){
 if(!ui.rst)app.append(btn("reset tight","Azzera la scheda",function(){ui.rst=1;render()}));
 else app.append(confirmBox("Sei sicuro di voler azzerare tutte le voci di questa scheda?"+(S._arc?" Il lavoro resta comunque nell'archivio.":""),"Azzera",function(){var tc=S.tec;S={};if(tc)S.tec=tc;PH[view]=[];phSave(view);siSet(view,0);save();rui();render();window.scrollTo(0,0)},function(){ui.rst=0;render()}))}
function render(){
 if(view==="rip"&&ripAs(S)){var t2=S.r1_tp==="Banconote"?"Monete":S.r1_tp==="Monete"?"Banconote":"";if(t2&&S.r2_tp!==t2||S.r2_md!==S.r1_md){if(t2)S.r2_tp=t2;if(S.r1_md)S.r2_md=S.r1_md;save()}}
 if(view==="rip"&&S.grm&&!S.rmaM){var gg=rmaGen(S);if(S.rma!==gg){S.rma=gg;save()}}
 var bl=V[view].blocks(S),pr=prog(bl,S,1),PS=passi(),cs=0,last=1,list=bl;
 BL=bl;ST=steps(bl);if(PS){cs=curStep();last=cs===ST.length-1;list=ST[cs].it}
 gear.hidden=false;closeOv();
 app.textContent="";noteTa=null;
 if(SOLO&&NEWV)app.append(btn("reset ac tight","È disponibile un aggiornamento: tocca per aggiornare",updApply));
 if(!PS)rstBox();
 if(ui.bkPend)app.append(pendBox(render));
 if(topMsg){var bm=el("div","cnt",topMsg);bm.setAttribute("role","status");app.append(bm);topMsg=""}

 if(PS){app.append(el("div","eyeb","Passo "+(cs+1)+" di "+ST.length),el("h2","ptitle",ST[cs].x));if(ST[cs].end)stepClose()}
 else{var bar=el("div","bar"),fi=document.createElement("i");fi.style.width=(pr.t?pr.d/pr.t*100:0)+"%";bar.append(fi);
  app.append(bar,el("div","cnt",pr.d+" di "+pr.t+" completati"))}
 if(!PS||cs===0)ddtBtn();
 var mg=null;
 list.forEach(function(x){
  if(x.t!=="mat")mg=null;
  if(x.t==="mat"){if(!mg){mg=el("div","mgrid");app.append(mg)}var mc=el("div","mcard");mc.append(el("b",0,x.lab));
   [["a"+x.i,"RBW"+x.p+"- banconote"],["c"+x.i,"RCW"+x.p+"- monete"],["mt"+x.i,"Codice impianto"]].forEach(function(f){var lb=el("label",0,f[1]),inp=document.createElement("input");inp.type="text";inp.value=S[f[0]]||"";inp.setAttribute("aria-label",x.lab+" "+f[1]);
    inp.oninput=function(){S[f[0]]=inp.value;save();if(noteTa)noteTa.value=noteText()};mc.append(lb,inp)});mg.append(mc)}
  else if(x.t==="date"){var fdt=el("div","fld"),di=document.createElement("input");di.type="date";di.value=S.dt||day();di.setAttribute("aria-label",x.x);fdt.dataset.id="dt";fdt.append(el("label",0,x.x),di);di.onchange=function(){S.dt=di.value||day();save()};app.append(fdt)}
  else if(x.t==="h")app.append(el("h2",0,x.x));
  else if(x.t==="h3")app.append(el("h3",0,x.x));
  else if(x.t==="cnt"){var fc=el("div","fld"),sc=el("div","seg"),cc={},q;for(q=1;q<=devN(S);q++)cc[S["m"+q]]=(cc[S["m"+q]]||0)+1;
   fc.append(el("label",0,"Dispositivi: tocca un modello per aggiungerne uno"));
   sc.className="seg cnt3";var MD=["CI-5","CI-10","CI-10X"];
   MD.forEach(function(o){sc.append(el("div","lbl",cc[o]>1?"Dispositivi "+cc[o]:""))});
   MD.forEach(function(o){var bc=btn(cc[o]?"on":"",o,function(){ui.dlg={nw:o};render()});bc.setAttribute("aria-label","Aggiungi un "+o+(cc[o]?" (ora "+cc[o]+")":""));sc.append(bc)});
   fc.dataset.id="cnt";fc.append(sc);app.append(fc);
   for(q=1;q<=devN(S);q++)(function(i){var px=PX[S["m"+i]]||"",r=btn("drow",null,function(){ui.dlg={i:i};render()}),sp=el("span");
    r.append(el("b",0,i+" · "+(S["m"+i]||"?")));
    [["RBW"+px+"-","a"+i],["RCW"+px+"-","c"+i],["Impianto: ","mt"+i]].forEach(function(f,k){var v=String(S[f[1]]||"").trim();if(k===1)sp.append(document.createTextNode(" · "));var e2=el("i",(v?"":"miss")+(k===2?" imp":""),f[0]+(v||"—"));sp.append(e2)});
    r.append(sp,el("em",0,"✎"));r.setAttribute("aria-label","Modifica dispositivo "+i);app.append(r)})(q);
   if(ui.dlg)app.append(devDlg())}
  else if(x.t==="tip"){var tp=el("p","cnt",x.x);tp.style.cssText="font-size:15px;padding:12px;border:1px dashed var(--ln);border-radius:10px;text-align:center";app.append(tp)}
  else if(x.t==="num"){var fn=el("div","fld"),sn2=el("div","seg"),nv=+S[x.id]||0;fn.append(el("label",0,x.x));
   var mi=btn("","−",function(){S[x.id]=Math.max(0,nv-1);save();render()}),pl=btn("","+",function(){S[x.id]=Math.min(x.max,nv+1);save();render()}),vv=el("div","numv",String(nv));
   fn.dataset.id=x.id;mi.setAttribute("aria-label","Diminuisci "+x.x);pl.setAttribute("aria-label","Aumenta "+x.x);vv.setAttribute("aria-live","polite");sn2.append(mi,vv,pl);fn.append(sn2);app.append(fn)}
  else if(x.t==="sw"){var fw=el("div","fld"),rw3=el("div","sw3"),hf=el("div","half");fw.append(el("label",0,"Software"));
   var bo=btn(S.bo==="Sì"?"on":"","SNG Cloud",function(){S.bo=S.bo==="Sì"?0:"Sì";save();render()});bo.setAttribute("aria-pressed",S.bo==="Sì"?"true":"false");
   ["Windows","Android"].forEach(function(o){var bw=btn(S.sng===o?"on":"",o,function(){S.sng=S.sng===o?0:o;save();render()});bw.setAttribute("aria-pressed",S.sng===o?"true":"false");hf.append(bw)});
   var inc=S.bo==="Sì",no=!inc&&S.sng==="Android",ap=!inc&&!no&&S.app,ba=btn(ap?"on":"",inc?"App non necessaria":no?"App non disponibile":"App SNG Cloud",function(){if(inc||no)return;S.app=S.app?0:1;save();render()});ba.setAttribute("aria-pressed",ap?"true":"false");if(inc||no){ba.disabled=true;ba.style.opacity=".5";ba.style.cursor="default"}
   fw.dataset.id="sng";rw3.append(bo,hf,ba);fw.append(rw3,el("div","cnt","Windows = SNG Suite · Android = SNG 3"+(S.bo==="Sì"?" · con SNG Cloud l'app non serve":S.sng==="Android"?" · su Android senza SNG Cloud l'app non c'è":"")));app.append(fw)}
  else if(x.t==="del"){var nn=devN(S);if(nn>=1){
   if(!ui.del)app.append(btn("reset dgo tight","Elimina dispositivo",function(){ui.del=1;ui.delSel=0;render()}));
   else{app.append(pick("Seleziona il dispositivo da eliminare",nn,ui.delSel,function(k){return "Dispositivo "+k+(S["m"+k]?" · "+S["m"+k]:"")},function(k){ui.delSel=k;render()}));
    if(ui.delSel)app.append(confirmBox("Sei sicuro di voler eliminare il Dispositivo "+ui.delSel+"?","Elimina",function(){delDev(ui.delSel);ui.del=0;ui.delSel=0;render()},function(){ui.del=0;ui.delSel=0;render()}));
    else app.append(btn("reset tight","Annulla",function(){ui.del=0;render()}))}}}
  else if(x.t==="addm")app.append(btn("reset ac tight","+ Aggiungi dispositivo",function(){S.dn=(+S.dn||1)+1;save();render()}));
  else if(x.t==="delm"){var nd=+S.dn||1;if(nd>1){
   if(!ui.dm)app.append(btn("reset dgo tight","Elimina dispositivo",function(){ui.dm=1;ui.dmSel=0;render()}));
   else{app.append(pick("Seleziona il dispositivo da eliminare",nd,ui.dmSel,function(k){return "Dispositivo "+k+(S[mrk(k)]?" · RCW50-"+S[mrk(k)]:"")},function(k){ui.dmSel=k;render()}));
    if(ui.dmSel)app.append(confirmBox("Sei sicuro di voler eliminare il Dispositivo "+ui.dmSel+"?","Elimina",function(){delRow(ui.dmSel);ui.dm=0;ui.dmSel=0;render()},function(){ui.dm=0;ui.dmSel=0;render()}));
    else app.append(btn("reset tight","Annulla",function(){ui.dm=0;render()}))}}}
  else if(x.t==="addp")app.append(btn("reset ac tight","+ Aggiungi pezzo",function(){S[x.p+"np"]=(+S[x.p+"np"]||0)+1;save();render()}));
  else if(x.t==="delp"){var np=+S[x.p+"np"]||0;if(np>=1){
   if(ui.pd!==x.p)app.append(btn("reset dgo tight","Elimina pezzo",function(){ui.pd=x.p;ui.pdSel=0;render()}));
   else{app.append(pick("Seleziona il pezzo da eliminare",np,ui.pdSel,function(k){return "Pezzo "+k+(S[x.p+"pz"+k]?" · "+S[x.p+"pz"+k]:"")},function(k){ui.pdSel=k;render()}));
    if(ui.pdSel)app.append(confirmBox("Sei sicuro di voler eliminare il Pezzo "+ui.pdSel+"?","Elimina",function(){delPz(x.p,ui.pdSel);ui.pd=0;ui.pdSel=0;render()},function(){ui.pd=0;ui.pdSel=0;render()}));
    else app.append(btn("reset tight","Annulla",function(){ui.pd=0;render()}))}}}
  else if(x.t==="mod"){
   var AS2=ripAs(S),altro=S.r1_tp==="Banconote"?"monete":"banconote";
   if((+S.rn||1)<2)app.append(btn("reset ac tight","+ Associa modulo "+altro+" (revisione totale)",function(){S.rn=2;S.rva=1;S.r2_tp=S.r1_tp==="Banconote"?"Monete":"Banconote";if(S.r1_md)S.r2_md=S.r1_md;save();pend="r2_mat";render()}));
   else if(!ui.md)app.append(btn("reset dgo tight",AS2?"Togli modulo associato":"Elimina modulo 2",function(){ui.md=1;render()}));
   else app.append(confirmBox(AS2?"Togliere il modulo associato e i suoi dati?":"Sei sicuro di voler eliminare il Modulo 2?","Elimina",function(){var N={},k;for(k in S)if(!/^(nt_)?r2_/.test(k))N[k]=S[k];N.rn=1;delete N.rva;S=N;save();ui.md=0;render()},function(){ui.md=0;render()}))}
  else if(x.t==="tmr"){var ms=tmMs(S),st=S.tmA?"run":S.tmF?"fin":ms?"pau":"",tb=el("div","tmr"+(st==="run"?" run":st==="pau"?" pau":"")),tv=el("div","tv"),tt=el("span","ts",st==="run"?"In corso":st==="pau"?"In pausa":st==="fin"?"Fermato · ore in Manodopera":"Cronometro manodopera"),tn=el("span",0,tmFmt(ms));
   tn.id=st==="run"?"tmv":"";tv.append(tn,tt);var bb=el("div","tmb");tb.append(tv,bb);
   function go(){save();render()}
   if(!st)bb.append(btn("go1","Avvia",function(){S.tmA=Date.now();delete S.tmF;go()}));
   else if(st==="run")bb.append(btn("","Pausa",function(){tmHalt(S);go()}),btn("go1","Stop",function(){tmHalt(S);S.tmF=1;S.ore=tmOre(+S.tmS||0);go()}));
   else if(st==="pau")bb.append(btn("go1","Riprendi",function(){S.tmA=Date.now();go()}),btn("","Stop",function(){S.tmF=1;S.ore=tmOre(+S.tmS||0);go()}));
   else bb.append(btn("","Riprendi",function(){S.tmA=Date.now();delete S.tmF;go()}),btn("","Azzera",function(){delete S.tmS;delete S.tmA;delete S.tmF;go()}));
   tb.dataset.id="tmr";app.append(tb);if(st==="run"&&!tmIv)tmIv=setInterval(tmTick,15000)}
  else if(x.t==="sel"){var fs=el("div","fld"),se=document.createElement("select"),o0=el("option","","Seleziona");fs.append(el("label",0,x.x));o0.value="";se.append(o0);se.setAttribute("aria-label",x.x);
   x.o.forEach(function(v){var op=el("option","",v+(v==="1"?" ora":" ore"));op.value=v;if(S[x.id]===v)op.selected=true;se.append(op)});
   se.onchange=function(){S[x.id]=se.value||0;save();render()};fs.dataset.id=x.id;fs.append(se);app.append(fs)}
  else if(x.t==="n"){app.append(el("h2",0,"Note rapportino"));noteTa=el("textarea");noteTa.readOnly=true;noteTa.style.minHeight="300px";noteTa.value=noteText();noteTa.setAttribute("aria-label","Note per il rapportino");
   var cm=el("div"),cb=btn("reset ac","Copia note",function(){tryCopy(cb,cm)});cb.style.marginTop="10px";app.append(noteTa,cb,cm);
   app.append(btn("reset tight","Mail al magazzino",function(){location.href=magMail(S)}));pdfBox()}
  else if(x.t==="c"){var nk="nt_"+x.id,rw=el("div","rowc"),
    b=btn("chk"+(S[x.id]?" on":""),null,function(){S[x.id]=S[x.id]?0:1;if(x.id==="grm"&&S.grm)S.rmaM=0;save();render()}),
    nb=btn("nb"+(S[nk]?" has":""),"Nota",function(){ui.notes[x.id]=!ui.notes[x.id];ui.foc=ui.notes[x.id]?x.id:null;render()});
   b.setAttribute("aria-pressed",S[x.id]?"true":"false");b.append(el("span","bx",S[x.id]?"✓":""),el("span","lb",x.x));
   nb.setAttribute("aria-label","Nota sulla voce: "+x.x);nb.setAttribute("aria-expanded",ui.notes[x.id]?"true":"false");
   rw.dataset.id=x.id;var hp=helpOf(x.id);rw.append(b);if(hp)rw.append(helpBtn(x.id));rw.append(nb);app.append(rw);if(hp&&ui.help[x.id])app.append(helpBox(x.id));
   if(ui.notes[x.id]){var nt=el("textarea","nta");nt.placeholder="Nota su questa voce: resta nella scheda e nel PDF, non nel rapportino";nt.value=S[nk]||"";nt.setAttribute("aria-label","Nota sulla voce: "+x.x);
    nt.oninput=function(){if(nt.value)S[nk]=nt.value;else delete S[nk];save();nb.className="nb"+(S[nk]?" has":"")};app.append(nt);
    if(ui.foc===x.id){ui.foc=null;setTimeout(function(){try{nt.focus()}catch(e){}},0)}}}
  else if(x.t==="g"){var f=el("div","fld"),sg=el("div","seg"),gh=helpOf(x.id);if(gh){var lr=el("div","hlr");lr.append(el("label",0,x.x),helpBtn(x.id));f.append(lr)}else f.append(el("label",0,x.x));
   x.o.forEach(function(o){var gb=btn(S[x.id]===o?"on":"",o,function(){S[x.id]=S[x.id]===o?0:o;save();render()});gb.setAttribute("aria-pressed",S[x.id]===o?"true":"false");sg.append(gb)});f.dataset.id=x.id;f.append(sg);app.append(f);if(gh&&ui.help[x.id])app.append(helpBox(x.id))}
  else if(x.t==="t"){var ft=el("div","fld"),i=document.createElement(x.area?"textarea":"input"),th=/(^|_)er$|^rf$/.test(x.id)?helpOf(x.id):null;if(th){var tl=el("div","hlr");tl.append(el("label",0,x.x),helpBtn(x.id));ft.append(tl);if(ui.help[x.id])ft.append(helpBox(x.id))}else ft.append(el("label",0,x.x));
   if(!x.area)i.type="text";i.placeholder=x.a;i.setAttribute("aria-label",x.x);
   if(x.id==="rma")rmaEl=i;i.value=S[x.id]||"";var er=null,dgm=view==="prep"&&/^mtM\d*$/.test(x.id)&&prepMode(S)==="Downgrade CI-5";
   if(dgm){er=el("div","cnt","");er.style.color="var(--dg)";i.onblur=function(){if(dupOf(x.id,i.value)){var dq=dupOf(x.id,i.value);i.value=S[x.id]||"";i.style.borderColor="";er.textContent="Matricola non salvata: già inserita nel Dispositivo "+dq}}}
   i.oninput=function(){if(dgm){var dj=dupOf(x.id,i.value);if(dj){i.style.borderColor="var(--dg)";er.textContent="Già inserita nel Dispositivo "+dj+": non viene salvata";return}i.style.borderColor="";er.textContent=""}S[x.id]=i.value;if(view==="rip"&&S.grm){if(x.id==="rma")S.rmaM=1;else if(!S.rmaM&&rmaEl){S.rma=rmaGen(S);rmaEl.value=S.rma}}if(x.id==="tec"&&tecRm())lsSet("gla_tec",i.value.trim());save();if(noteTa)noteTa.value=noteText();if(x.cmp)grow(i)};ft.dataset.id=x.id;ft.append(i);if(er)ft.append(er);
   if(x.id==="tec"){var rl=el("label","tecrm"),rc=document.createElement("input");rc.type="checkbox";rc.checked=tecRm();
    rc.onchange=function(){lsSet("gla_tecrm",rc.checked?"1":"0");if(rc.checked)lsSet("gla_tec",String(S.tec||"").trim());else{try{LS&&LS.removeItem("gla_tec")}catch(e){}}};
    rl.append(rc,document.createTextNode("Ricordami: usa questo nome in tutte le schede"));ft.append(rl)}app.append(ft);if(x.cmp){i.style.minHeight="56px";i.style.overflowY="auto";grow(i)}}
 });
 if(PS&&!last)markAll(list);
 if(!PS||last){if(view==="prep"){app.append(btn("reset tight","Mail al magazzino",function(){location.href=magMail(S)}));pdfBox()}if(!SOLO)arcBox();if(PS)rstBox()}
 passiFrame();pendGo()}

/* ---------- menu Condividi della scheda ---------- */
function ddBuild(dd){dd.textContent="";var m=el("div","cnt","");m.setAttribute("role","status");m.style.margin="6px 8px";
 function it(lab,sub,fn){var b=btn("ddi",null,fn);b.append(el("b",0,lab),el("span",0,sub));dd.append(b)}
 dd.append(el("div","ddh","PDF della checklist"));
 it("Condividi PDF","WhatsApp, email…",function(){pdfGate(function(){var r=pdfFile();shareFile(new Blob([r.u],{type:"application/pdf"}),r.fn,"application/pdf",m,"PDF condiviso.")},"Condividi comunque",m)});
 it("Genera PDF","Crea e salva il PDF della checklist",function(){pdfGate(function(){dlPdf(m)},"Scarica comunque",m)});
 dd.append(el("div","ddh","Scheda da riprendere"));
 it("Condividi scheda","Un collega la carica e continua da qui",function(){if(!hasData(S)){m.textContent="Scheda vuota: niente da condividere.";return}var r=bkFile();shareFile(new Blob([r.t],{type:"text/plain"}),r.fn,"text/plain",m,"Scheda condivisa.")});
 it("Scarica scheda","File da ricaricare più tardi o altrove",function(){if(!hasData(S)){m.textContent="Scheda vuota: niente da scaricare.";return}var r=bkFile();saveFile(new Blob([r.t],{type:"text/plain"}),r.fn,function(){m.textContent="Scheda salvata nei Download: «"+r.fn+"»."},function(){m.textContent="Salvataggio non riuscito."})});
 var fi=document.createElement("input");fi.type="file";fi.accept=DOCACC;fi.hidden=true;
 fi.onchange=function(){var f=fi.files&&fi.files[0];fi.value="";if(!f)return;var rd=new FileReader();
  rd.onload=function(){var r=bkRead(String(rd.result||""));ui.dd=0;
   if(!r){topMsg="File non valido: scegli un file «Scheda Glory» (o un vecchio .json di Glory).";render();return}
   if(r.all){topMsg="È un backup completo: caricalo dal menù principale.";render();return}
   if(hasData(load(r.it[0].v))||r.it[0].v!==view){ui.bkPend=r;render();window.scrollTo(0,0)}else bkApply(r)};
  rd.onerror=function(){m.textContent="Lettura del file non riuscita."};rd.readAsText(f)};
 it("Carica scheda","Riprendi una scheda da file",function(){fi.click()});
 dd.append(fi,m)}

/* ---------- visualizzazione: scheda unica o a passi ---------- */
var SI={},pend=null,MK={},BL=[],ST=[],OV=null,RD={},PJ=null,gear=document.getElementById("gear"),hdr=document.querySelector("header");
function passi(){return !!view&&!SOLO&&lsGet("gla_vista")==="passi"}
function gv(k){return String(S[k]==null?"":S[k]).trim()}
function hasNote(){return BL.some(function(b){return b.t==="n"})}
function steps(bl){var st=[{x:"Dati del lavoro",it:[]}],nn=[];
 bl.forEach(function(b){if(b.t==="h")st.push({x:b.x.replace(/^\d+ · /,""),it:[]});else if(b.t==="n")nn.push(b);else st[st.length-1].it.push(b)});
 st=st.filter(function(s){return s.it.some(function(b){return b.t!=="h3"})});st.push({x:"Chiusura",end:1,it:nn});return st}
function optT(b){return b.opt||b.cmp||/^Facoltativo/.test(b.a||"")||/(_er|^se|^ric|^chp|^rvn)$/.test(b.id)}
function stat(st){var t=0,d=0,i;
 if(st.end){var r=check(BL);return {t:1,d:(r.bad.length||r.warn.length)?0:1}}
 var o=0;st.it.forEach(function(b){if(b.memo||b.opt){if(b.id&&S[b.id])o++;return}
  if(b.t==="c"||b.t==="g"||b.t==="sel"){t++;if(S[b.id])d++}
  else if(b.t==="t"&&!optT(b)){t++;if(gv(b.id))d++}
  else if(b.t==="cnt")for(i=1;i<=devN(S);i++){t+=2;if(gv("a"+i))d++;if(gv("c"+i))d++}});
 return {t:t,d:d,o:o}}
function siSet(v,i){SI[v]=i;lsSet("gla_si",JSON.stringify(SI))}
function curStep(){var i=+SI[view]||0;if(i>=ST.length)i=ST.length-1;if(i<0)i=0;if(SI[view]!==i)siSet(view,i);return i}
function goStep(i){siSet(view,i);ui.help={};render();window.scrollTo(0,0)}
function railBuild(){var n=el("nav","rail"),cur=curStep();n.id="rail";n.setAttribute("aria-label","Passi della scheda");
 ST.forEach(function(st,k){var q=stat(st),c=q.t?(q.d>=q.t?" done":q.d>0?" part":""):(q.o?" done":""),b=btn("dot"+c+(k===cur?" cur":""),st.end?"✓":String(k+1),function(){goStep(k)});
  b.setAttribute("aria-label","Passo "+(k+1)+": "+st.x);if(k===cur)b.setAttribute("aria-current","step");n.append(b)});
 return n}
function dockBuild(){var cur=curStep(),last=cur===ST.length-1,q=stat(ST[cur]),rest=q.t-q.d,d=el("div","dock"),a;d.id="dock";
 var p=btn("ib","‹",function(){goStep(cur-1)});p.disabled=cur===0;p.setAttribute("aria-label","Passo precedente");d.append(p);
 if(hasNote())d.append(btn("mid","Nota",noteDlg));
 var rk=last&&IDB&&!SOLO&&hasData(S)?check(BL):null;
 if(rk&&!rk.bad.length&&!rk.warn.length){a=btn("go",null,function(){ui.arc=1;pend="arcb";render()});a.append(el("b",0,S._arc?"Aggiorna":"Archivia"),el("span",0,"tutto completato"))}
 else if(last){a=btn("go wait",null,function(){location.hash=""});a.append(el("b",0,"Menù"),el("span",0,"torna alle schede"))}
 else{a=btn("go"+(rest>0?" wait":""),null,function(){goStep(cur+1)});a.append(el("b",0,"Avanti"),el("span",0,rest>0?(rest===1?"resta 1 voce qui":"restano "+rest+" voci qui"):ST[cur+1].x))}
 d.append(a);return d}
function chrome(){if(!passi())return;BL=V[view].blocks(S);ST=steps(BL);var r=document.getElementById("rail"),d=document.getElementById("dock");if(r)r.replaceWith(railBuild());if(d)d.replaceWith(dockBuild())}
function clearPassi(){var r=document.getElementById("rail"),d=document.getElementById("dock");if(r)r.remove();if(d)d.remove();document.body.classList.remove("passi");document.body.classList.toggle("pv",!SOLO&&lsGet("gla_vista")==="passi")}
function passiFrame(){clearPassi();if(!passi())return;document.body.classList.add("passi","pv");hdr.append(railBuild());document.body.append(dockBuild())}

/* ---------- salti verso il dato mancante ---------- */
var KT=[[/Almeno un dispositivo/,"cnt"],[/Sistema del gestionale/,"sng"],[/Numero di postazioni/,"nsv"],[/Surplus/,"sur"],[/Controlli preliminari: alimentazione/,"ct1"],[/Esito dei controlli preliminari/,"pes"],[/collaudo finale/,"cfe"],[/Su quale modulo/,"cfq"],[/risolta o non risolta/,"cfx"],[/Contratto full: pulizia/,"rev"],[/nessun aggiornamento/,"ufc"],[/Riferimento CV o RMA/,"rf"],[/Matricola duplicata/,"mtM"]];
function keyOf(t){var m,i;if(MK[t])return MK[t];if((m=/Esito del modulo (\d)/.exec(t)))return "r"+m[1]+"_es";if(/Pulizia: problema rilevato/.test(t))return (/banconote/.test(t)?"r1_":"r2_")+"pp";
 for(i=0;i<KT.length;i++)if(KT[i][0].test(t))return KT[i][1];return ""}
function stepOf(k){var m=/^(m|a|c|mt)(\d+)$/.exec(k),i;if((view==="inst"||view==="rit")&&m)k="cnt";
 for(i=0;i<ST.length;i++)if(ST[i].it.some(function(b){return b.id===k||(k==="cnt"&&b.t==="cnt")||(k==="sng"&&b.t==="sw")}))return i;return -1}
function canJump(k){if(!k)return false;if(!passi())return true;BL=V[view].blocks(S);ST=steps(BL);return stepOf(k)>=0}
function jump(k){if(!canJump(k))return;var m=(view==="inst"||view==="rit")&&/^(m|a|c|mt)(\d+)$/.exec(k);closeOv();
 if(passi())siSet(view,stepOf(k));ui.dd=0;if(m){ui.dlg={i:+m[2]};pend="cnt"}else pend=k;render()}
function pendGo(){if(!pend)return;var k=pend,t=app.querySelector('[data-id="'+k+'"]');pend=null;if(!t)return;
 t.scrollIntoView({block:"center"});t.classList.add("flash");setTimeout(function(){t.classList.remove("flash")},1600);
 var f=t.querySelector("input[type=text],textarea,select");if(f&&!ui.dlg)try{f.focus({preventScroll:true})}catch(e){}}
function firstGap(){var r=check(BL),a=r.bad.concat(r.warn),i,k;
 for(i=0;i<a.length;i++){k=keyOf(a[i]);if(/^(m|a|c|mt)\d+$|mat$|^rma$|^ric$|^mt$/.test(k)&&canJump(k))return k}
 for(i=0;i<a.length;i++){k=keyOf(a[i]);if(canJump(k))return k}return ""}
function gapKeys(){var L=[],i;
 if(view==="rit")for(i=1;i<=devN(S);i++){if(!S["m"+i])L.push("m"+i);if(!S["a"+i])L.push("a"+i);if(!S["c"+i])L.push("c"+i)}
 else if(view==="inst")for(i=1;i<=devN(S);i++){if(!S["m"+i])L.push("m"+i);if(!S["a"+i])L.push("a"+i);if(!S["c"+i])L.push("c"+i);if(!S["mt"+i])L.push("mt"+i)}
 else if(view==="rip"){for(i=1;i<=(+S.rn||1);i++)if(!S["r"+i+"_mat"])L.push("r"+i+"_mat");if(!S.rma)L.push("rma")}
 else if(view==="loc")locUnits(S).forEach(function(u){if(u.m&&!S[u.p+"mat"])L.push(u.p+"mat")});
 return L}
function noteView(t){var d=el("div","notev"),g0=firstGap(),GK=gapKeys(),gi=0;String(t).split(/(…|_{6,}|\[modello\])/).forEach(function(x,i){
  if(i%2){var g=GK[gi++]||(view==="inst"?(/^_/.test(x)?"ric":"sng"):g0);if(!canJump(g))g=g0;var b=btn("gap","manca",function(){jump(g)});b.setAttribute("aria-label","Dato mancante: vai a compilarlo");d.append(b)}else d.append(x)});return d}
function issueBox(cls,title,a){var bx=el("div","box"+cls);bx.append(el("b",0,title));wlist(bx,a);return bx}
function stepClose(){var r=check(BL);
 if(r.bad.length)app.append(issueBox("","Mancano dati fondamentali",r.bad));
 if(r.warn.length)app.append(issueBox(" wn","Da controllare · "+r.warn.length,r.warn));
 if(!r.bad.length&&!r.warn.length)app.append(el("p","allok","Tutto compilato e spuntato."))}
function markAll(list){var todo=list.filter(function(b){return b.t==="c"&&!b.memo&&!b.opt&&!S[b.id]});
 if(todo.length>1)app.append(btn("reset tight","Segna fatte tutte le "+todo.length+" voci di questo passo",function(){todo.forEach(function(b){S[b.id]=1});save();render()}))}

/* ---------- finestre ---------- */
function openOv(build){closeOv();OV=el("div","ovl");OV.setAttribute("role","dialog");OV.setAttribute("aria-modal","true");OV.onclick=function(e){if(e.target===OV)closeOv()};
 var bx=el("div","dlg");build(bx);OV.append(bx);document.body.append(OV)}
function closeOv(){if(OV){OV.remove();OV=null}}
document.addEventListener("keydown",function(e){if(e.key==="Escape"&&OV)closeOv()});
function noteDlg(){openOv(function(bx){var sg=el("div","seg");
 bx.append(el("h2",0,"La nota fin qui"),el("p","cnt","Si aggiorna a ogni voce. Tocca «manca» per andare al dato da compilare."),noteView(noteText()));
 sg.append(btn("on","Vai alla chiusura",function(){closeOv();goStep(ST.length-1)}),btn("","Chiudi",closeOv));bx.append(sg)})}
function gearDlg(){openOv(function(bx){var cur=lsGet("gla_vista")==="passi"?"passi":"unica";
 bx.append(el("h2",0,"Visualizzazione delle schede"),el("p","cnt","Cambia solo come scorri la scheda: voci, note, archivio e PDF restano gli stessi. Puoi cambiarla anche a lavoro iniziato."));
 [["unica","Scheda unica","Tutte le voci in una pagina: scorri liberamente."],["passi","A passi","Una sezione alla volta, con Avanti, la nota sempre a portata e l'elenco di cosa manca."]].forEach(function(o){
  var b=btn("vopt"+(cur===o[0]?" on":""),null,function(){lsSet("gla_vista",o[0]);closeOv();if(view&&V[view]){render();window.scrollTo(0,0)}else route()});
  b.append(el("b",0,o[1]),el("span",0,o[2]));b.setAttribute("aria-pressed",cur===o[0]?"true":"false");bx.append(b)});
 bx.append(btn("reset tight","Chiudi",closeOv))})}
gear.onclick=gearDlg;
try{SI=JSON.parse(lsGet("gla_si"))||{}}catch(e){SI={}}if(typeof SI!=="object"||Array.isArray(SI))SI={};

/* ---------- caricamento del DDT ---------- */
var PXM={"50":"CI-5","100":"CI-10","200":"CI-10X"};
function serOld(t){var re=/R\s?([BC])\s?W\s?[-–]?\s?(200|100|50)\s?[-–—.:]?\s?([0-9][0-9A-Z]{2,})/g,m,o=[];t=String(t||"").toUpperCase();while((m=re.exec(t)))o.push({t:m[1],md:PXM[m[2]],n:m[3]});return o}
/* CI-10US = CI-10 usato: la sigla US non è il modello; banconote o monete dalla descrizione */
function codeOf(s){var m=/^\s*CI\s?-?\s?(10X|10|5)\s?-?\s?(?:([BC])|(US))(?![A-Z0-9])/i.exec(s);return m?{md:"CI-"+m[1].toUpperCase(),t:m[2]?m[2].toUpperCase():"",us:m[3]?1:0}:null}
function typeOf(s){s=String(s).toUpperCase();return /BANCONOT|\bBANCO/.test(s)?"B":/MONET/.test(s)?"C":""}
function parseLines(L){var R={ser:[],mon:""},cur=null,exp=0,seen={},codes=0;
 function add(t,md,n){var k=md+"|"+n+"|"+(cur?cur.q:"");if(!seen[k]){seen[k]=1;R.ser.push({t:t,md:md,n:n,us:cur&&cur.us?1:0,c:cur})}}
 L.forEach(function(raw){var s=String(raw).trim(),c=codeOf(s),m;if(!s)return;
  if(c){cur=c;c.q=codes;if(!c.t)c.t=typeOf(s.replace(/^\s*CI\S*/i,""));exp=0;codes++;return}
  if(cur&&!cur.t&&!exp)cur.t=typeOf(s);
  if(/^MONITOR/i.test(s)){R.mon="Sì";cur=null;exp=0;return}
  if(/codice\s+matricola/i.test(s)){exp=1;m=/codice\s+matricola\s*[:.]?\s*([A-Z0-9][A-Z0-9\-\/]{2,})\s*$/i.exec(s);if(m&&/\d/.test(m[1])&&cur){add(cur.t,cur.md,m[1]);exp=0}return}
  if(exp&&cur&&/^[A-Z0-9][A-Z0-9\-\/]{2,}$/.test(s)&&/\d/.test(s)&&!/^R\s?[BC]\s?W/i.test(s)){add(cur.t,cur.md,s);return}
  exp=0});
 R.ser.forEach(function(x){if(x.c&&x.c.t)x.t=x.c.t;delete x.c});
 R.ser.forEach(function(x){if(x.t)return;var o=R.ser.filter(function(y){return y!==x&&y.md===x.md&&y.us===x.us}),b=o.filter(function(y){return y.t==="B"}).length,c=o.filter(function(y){return y.t==="C"}).length;x.t=b>c?"C":"B"});
 var dd={};R.ser=R.ser.filter(function(x){var k=x.t+x.md+x.n;if(dd[k])return false;dd[k]=1;return true});
 serOld(L.join("\n")).forEach(function(x){if(!dd[x.t+x.md+x.n]){dd[x.t+x.md+x.n]=1;R.ser.push({t:x.t,md:x.md,n:x.n,us:0})}});
 if(codes&&!R.mon)R.mon="No";return R}
function mkLines(P){var L=[],cur=null;P=P.filter(function(p){return String(p.s).trim()}).sort(function(a,b){return a.y-b.y||a.x-b.x});
 P.forEach(function(p){if(!cur||p.y-cur.y>3){cur={y:p.y,p:[]};L.push(cur)}cur.p.push(p)});
 L.forEach(function(l){l.p.sort(function(a,b){return a.x-b.x});l.segs=[];l.p.forEach(function(p){var g=l.segs[l.segs.length-1];if(g&&p.x-g.x2<7){g.s+=(p.x-g.x2>0.8?" ":"")+p.s;g.x2=p.x2}else l.segs.push({x:p.x,x2:p.x2,s:p.s})})});return L}
function parseDoc(LN){var R=parseLines(LN.map(function(l){return l.segs.map(function(g){return g.s}).join("  ")}));
 function find(re){for(var i=0;i<LN.length;i++)for(var j=0;j<LN[i].segs.length;j++)if(re.test(LN[i].segs[j].s.trim()))return {i:i,x:LN[i].segs[j].x};return null}
 function block(a,stop){var o=[],i;for(i=a.i+1;i<stop;i++)LN[i].segs.forEach(function(g){if(g.x>=a.x-12)o.push(g.s.trim())});return o.filter(Boolean)}
 function under(re){var a=find(re),i,best="";if(!a)return "";for(i=a.i+1;i<LN.length&&i<=a.i+2&&!best;i++)LN[i].segs.forEach(function(g){if(!best&&Math.abs(g.x-a.x)<20)best=g.s.trim()});return best}
 function addr(bl){var k=-1,st,city;bl.forEach(function(s,i){if(/^\d{5}\s/.test(s))k=i});if(k<0)return null;
  city=bl[k].replace(/^(\d{5})\s+/,"$1 ").replace(/\s*(-\s*Itali[ae]|\(ITA\)|-\s*IT)\s*$/i,"").trim();
  st=k>0&&(/^(VIA|V\.\s?LE|VIALE|P\.?\s?ZA|PIAZZA|PIAZZALE|CORSO|C\.\s?SO|LARGO|LOC\.?|LOCALIT|STRADA|STR\.|FRAZ|CONTRADA|VICOLO|BORGO|SS\s|S\.S\.)/i.test(bl[k-1])||(k>1&&/\d/.test(bl[k-1])))?bl[k-1]:"";
  return {name:bl.slice(0,st?k-1:k).join(" "),se:(st?st+", ":"")+city}}
 var a=find(/^Intestatario/i),b=find(/^Sede di consegna/i),c=find(/^Codice cliente/i),A,B;
 if(a&&b&&(A=addr(block(a,b.i)))){if(A.name)R.cl=A.name;R.se=A.se}
 if(b&&c){var bk=block(b,c.i);if((B=addr(bk))){R.se=B.se;if(B.name&&B.name!==R.cl){R.int=R.cl;R.cl=B.name}}else if(bk.length)R.se=bk.join(", ")}
 R.ddt=under(/^Numero documento/i);R.dt=under(/^Data doc/i);
 return R}
function gotAny(R){return R&&(R.ser.length||R.cl||R.se)}
function freeSer(t,md,me){var used={},k,f=t==="B"?"a":"c";for(k=1;k<=devN(S);k++)if(k!==me)used[gv(f+k)]=1;
 return (S.ddtm||[]).filter(function(x){return x.t===t&&x.md===md&&!used[x.n]}).map(function(x){return x.n})}
function nextDev(from){if(!(S.ddtm||[]).length)return 0;for(var k=(from||0)+1;k<=devN(S);k++){var md=S["m"+k];if((!gv("a"+k)&&freeSer("B",md,k).length)||(!gv("c"+k)&&freeSer("C",md,k).length))return k}return 0}
function applyDoc(R){var F=R.ser,B=F.filter(function(x){return x.t==="B"}),C=F.filter(function(x){return x.t==="C"}),md=F[0]?F[0].md:"";
 if(R.cl&&(view==="inst"||view==="loc"||view==="rip"))S.cl=R.cl;
 if(R.se&&(view==="inst"||view==="loc"))S.se=R.se;
 if(R.int&&(view==="inst"||view==="loc"||view==="rip")){S.rv=1;S.rvn=R.int}
 else if(R.cl&&(view==="inst"||view==="loc"||view==="rip")){S.rv=0;delete S.rvn}
 if(view==="inst"){if(R.mon)S.mon=R.mon;
  if(R.ddt){S.p5=1;var dn="DDT n. "+R.ddt+(R.dt?" del "+R.dt:"");if(String(S.nte||"").indexOf(dn)<0)S.nte=(gv("nte")?gv("nte")+"\n":"")+dn}
  var tk={};S.ddtm=F.map(function(x){return {t:x.t,md:x.md,n:x.n}});
  var uA={},uC={},q;for(q=1;q<=devN(S);q++){uA[S["m"+q]+gv("a"+q)]=1;uC[S["m"+q]+gv("c"+q)]=1}
  ["CI-5","CI-10","CI-10X"].forEach(function(m){var b=B.filter(function(x){return x.md===m&&!uA[m+x.n]}),c=C.filter(function(x){return x.md===m&&!uC[m+x.n]}),k,i,one=b.length<=1&&c.length<=1;
   for(k=0;k<Math.max(b.length,c.length);k++){for(i=1;i<=devN(S);i++)if(S["m"+i]===m&&!gv("a"+i)&&!gv("c"+i)&&!tk[i])break;
    if(i>devN(S)){S.n=devN(S)+1;i=S.n;S["m"+i]=m}tk[i]=1;if(one){if(b[k])S["a"+i]=b[k].n;if(c[k])S["c"+i]=c[k].n}}});
  devSort()}
 else if(view==="loc"&&F.length){if(!S.md)S.md=md;if(B[0])S.r1_mat=B[0].n;if(C[0])S.r2_mat=C[0].n;if(!S.sc)S.sc=B[0]&&C[0]?"Entrambi i moduli":B[0]?"Modulo banconote":"Modulo monete"}
 else if(view==="rip"&&F.length){F.slice(0,2).forEach(function(x,k){var p="r"+(k+1)+"_";S[p+"tp"]=x.t==="B"?"Banconote":"Monete";S[p+"md"]=x.md;S[p+"mat"]=x.n});if(F.length>1)S.rn=2}
 else if(view==="prep"&&F.length){if(!S.m)S.m=md;if(prepMode(S)==="Downgrade CI-5"&&C.length){C.forEach(function(x,k){S[mrk(k+1)]=x.n});S.dn=Math.max(+S.dn||1,C.length)}else{if(B[0])S.mtB=B[0].n;if(C[0])S.mtM=C[0].n}}
 save()}
function loadPdfJs(){if(PJ)return PJ;var L=document.getElementById("pdfjs-lib"),W=document.getElementById("pdfjs-worker"),lu,wu;
 if(L&&W){lu=URL.createObjectURL(new Blob([L.textContent],{type:"text/javascript"}));wu=URL.createObjectURL(new Blob([W.textContent],{type:"text/javascript"}));
  PJ=import(lu).then(function(lib){return import(wu).then(function(wm){globalThis.pdfjsWorker=wm;lib.GlobalWorkerOptions.workerSrc=wu;return lib})})}
 else{lu=new URL(BASE+"pdf.min.mjs",location.href).href;wu=new URL(BASE+"pdf.worker.min.mjs",location.href).href;PJ=import(lu).then(function(lib){lib.GlobalWorkerOptions.workerSrc=wu;return lib})}
 PJ.catch(function(){PJ=null});return PJ}
function pdfParts(f){return Promise.all([loadPdfJs(),f.arrayBuffer()]).then(function(a){return a[0].getDocument({data:new Uint8Array(a[1])}).promise}).then(function(doc){var P=[],ch=Promise.resolve(),n;
  for(n=1;n<=Math.min(doc.numPages,5);n++)(function(n){ch=ch.then(function(){return doc.getPage(n)}).then(function(pg){var h=pg.getViewport({scale:1}).height;return pg.getTextContent().then(function(tc){
    tc.items.forEach(function(it){if(it.str)P.push({x:it.transform[4],x2:it.transform[4]+(it.width||0),y:(n-1)*2000+h-it.transform[5],s:it.str})})})})})(n);
  return ch.then(function(){return P})})}
function rdShow(){if(OV&&RD.open)readerDlg()}
function rdFile(f){var pdf=/pdf$/i.test(f.type)||/\.pdf$/i.test(f.name);RD.found=null;
 if(!pdf){RD.msg="Carica il PDF del DDT. Se hai solo la carta, incolla il testo qui sotto.";rdShow();return}
 RD.busy=1;RD.msg="Leggo il PDF…";rdShow();
 pdfParts(f).then(function(P){RD.busy=0;if(!P.length){RD.msg="Questo PDF non contiene testo (è una scansione): incolla il testo qui sotto.";rdShow();return}
  var R=parseDoc(mkLines(P));if(gotAny(R)){RD.found=R;RD.msg=""}else RD.msg="Ho letto il PDF ma non riconosco cliente né matricole: l'impaginazione è diversa da quella che conosco.";rdShow()},
  function(){RD.busy=0;RD.msg=navigator.onLine?"Non riesco ad aprire questo PDF. Prova a incollare il testo.":"Il lettore PDF non è ancora salvato sul telefono: apri l'app una volta con internet e riprova.";rdShow()})}
function ddtBtn(){if(view!=="inst")return;app.append(btn("reset ac tight ddtb","Hai il DDT? Caricalo e precompilo",function(){RD={open:1};readerDlg()}))}
function readerDlg(){openOv(function(bx){var R=RD.found;
 bx.append(el("h2",0,R?"Trovato nel DDT":"Precompila dal DDT"));
 if(R){var ul=el("ul","found");function row(k,v){if(!v)return;var li=el("li");li.append(el("span",0,k),el("b",0,v));ul.append(li)}
  if(view!=="prep")row("Rivenditore",R.int);row("Cliente",R.cl);row("Sede",R.se);if(view==="inst")row("Monitor",R.mon);
  R.ser.forEach(function(x){row(x.md+(x.us?" usato":"")+" · "+(x.t==="B"?"banconote":"monete"),"R"+x.t+"W"+PX[x.md]+"-"+x.n)});
  row("DDT",R.ddt?R.ddt+(R.dt?" del "+R.dt:""):"");bx.append(ul);
  var many=view==="inst"&&["CI-5","CI-10","CI-10X"].some(function(m){return R.ser.filter(function(x){return x.md===m&&x.t==="B"}).length>1||R.ser.filter(function(x){return x.md===m&&x.t==="C"}).length>1});
  if(many)bx.append(el("p","tipb","Più dispositivi nello stesso DDT: creo i dispositivi, le matricole le abbini tu toccandole nella finestra di ogni dispositivo, davanti alla macchina."));
  bx.append(el("p","cnt","Controlla con il documento prima di confermare. Tutto resta modificabile a mano."));
  var sg=el("div","seg");sg.append(btn("on","Compila",function(){applyDoc(R);RD={};closeOv();topMsg="Dati del DDT inseriti: controllali.";var nx=view==="inst"?nextDev():0;if(nx){ui.dlg={i:nx};pend="cnt";if(passi())siSet(view,stepOf("cnt"))}render()}),btn("","Rifai",function(){RD.found=null;readerDlg()}));bx.append(sg)}
 else{bx.append(el("p","cnt","Carica il PDF del DDT: leggo cliente, rivenditore, sede, modello, matricole e monitor. Poi confermi tu."));
  var lb=el("label","reset ac tight filebtn"),fi=document.createElement("input");fi.type="file";fi.accept="application/pdf,.pdf";fi.disabled=!!RD.busy;fi.setAttribute("aria-label","Scegli il PDF del DDT");
  fi.onchange=function(){if(fi.files&&fi.files[0])rdFile(fi.files[0])};lb.append(RD.busy?"Sto leggendo…":"Scegli il PDF del DDT",fi);bx.append(lb);
  var m=el("div","cnt",RD.msg||"");m.setAttribute("role","status");bx.append(m);
  var ta=document.createElement("textarea");ta.placeholder="Oppure incolla qui il testo del DDT";ta.value=RD.txt||"";ta.setAttribute("aria-label","Testo del DDT");ta.oninput=function(){RD.txt=ta.value};
  bx.append(ta,btn("reset tight","Cerca nel testo incollato",function(){var f=parseLines(String(RD.txt||"").split(/\n/));if(gotAny(f)){RD.found=f;RD.msg=""}else RD.msg="Nel testo non trovo matricole: servono le righe articolo (es. CI-5B) con il loro «Codice matricola».";readerDlg()}),btn("reset tight","Chiudi",function(){RD={};closeOv()}))}})}

/* ---------- Google Drive online (cartella condivisa dei lavori) ---------- */
var GD={cid:"734772581415-0qsblo2m724m9pjda994173bf36v6r3r.apps.googleusercontent.com",fid:"1Y-gv5GMlXuRe8jY2u8Gf7ZlSkPC3oRba",sc:"https://www.googleapis.com/auth/drive",
 ok:location.protocol==="https:"||location.hostname==="localhost",FOLD:"application/vnd.google-apps.folder"};
function gRedir(){return location.origin+location.pathname.replace(/index\.html$/,"")}
function gTokC(){try{var o=JSON.parse(localStorage.getItem("gla_gtok")||"null");if(o&&o.t&&o.e>Date.now()+60000)return o.t}catch(e){}return ""}
function gLogin(st){var q={client_id:GD.cid,redirect_uri:gRedir(),response_type:"token",scope:GD.sc,include_granted_scopes:"true",state:st||""};
 location.href="https://accounts.google.com/o/oauth2/v2/auth?"+Object.keys(q).map(function(k){return k+"="+encodeURIComponent(q[k])}).join("&")}
/* al ritorno da Google: il token è nell'indirizzo dopo # */
function gBack(nh){var h=location.hash;if(!/(^|[#&])(access_token|error)=/.test(h))return null;var p={};
 h.replace(/^#/,"").split("&").forEach(function(kv){var i=kv.indexOf("=");if(i>0)p[decodeURIComponent(kv.slice(0,i))]=decodeURIComponent(kv.slice(i+1).replace(/\+/g," "))});
 if(p.access_token)try{localStorage.setItem("gla_gtok",JSON.stringify({t:p.access_token,e:Date.now()+(+p.expires_in||3600)*1000}))}catch(e){}
 try{history.replaceState(null,"",location.pathname+location.search+(nh||""))}catch(e){}return {st:p.state||"",ok:!!p.access_token,err:p.error||""}}
function gFetch(u,o){var t=gTokC();if(!t)return Promise.reject(new Error("login"));o=o||{};o.headers=o.headers||{};o.headers.Authorization="Bearer "+t;
 return fetch(u,o).then(function(r){if(r.status===401){try{localStorage.removeItem("gla_gtok")}catch(e){}throw new Error("login")}if(!r.ok)throw new Error("http "+r.status);return r})}
/* carica un file nella cartella (anche grande, con le foto) */
function gUp(text,name,parent,type){type=type||"text/plain";var meta={name:name,parents:[parent||GD.fid],mimeType:type};
 return gFetch("https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable&supportsAllDrives=true",{method:"POST",headers:{"Content-Type":"application/json; charset=UTF-8","X-Upload-Content-Type":type},body:JSON.stringify(meta)})
 .then(function(r){var loc=r.headers.get("Location");if(!loc)return gMulti(meta,text,type);return fetch(loc,{method:"PUT",headers:{"Content-Type":type},body:new Blob([text],{type:type})}).then(function(r2){if(!r2.ok)throw new Error("http "+r2.status);return r2.json()})})}
function gMulti(meta,text,type){var b="glory"+Date.now().toString(36);
 return gFetch("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&supportsAllDrives=true",{method:"POST",headers:{"Content-Type":"multipart/related; boundary="+b},
  body:new Blob(["--"+b+"\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n"+JSON.stringify(meta)+"\r\n--"+b+"\r\nContent-Type: "+type+"\r\n\r\n",text,"\r\n--"+b+"--"])}).then(function(r){return r.json()})}
var GBK=gBack("#arc"),GSEND="";

/* ---------- navigazione ---------- */
function route(){
 var h=location.hash.replace("#","");if(SOLO)h=SOLO;
 if(V[h]){view=h;S=load(h);rui();if(SHP&&!SHP.all&&SHP.it[0].v===h){ui.bkPend=SHP;SHP=null}bkMsg=bkNext;bkNext="";ttl.textContent=V[h].title;back.hidden=!!SOLO;render();window.scrollTo(0,0)}
 else if(h==="arc"){rui();bkMsg="";bkNext="";arcView();window.scrollTo(0,0)}
 else if(h==="rma"){rui();bkMsg="";bkNext="";rmaView();window.scrollTo(0,0)}
 else{ui.bkPend=null;if(SHP&&SHP.all){ui.bkPend=SHP;SHP=null}bkNext="";home();bkMsg="";window.scrollTo(0,0)}}
back.onclick=function(){location.hash=""};
window.addEventListener("hashchange",route);
/* ---------- accesso con password ---------- */
var PWH="2d8d2915503397a4a266bd3e83ea3cc893c657e4510c47f5d6c4d014a14bf025";
function okGet(){try{if(localStorage.getItem("gla_ok")===PWH)return 1}catch(e){}try{if(sessionStorage.getItem("gla_ok")===PWH)return 1}catch(e){}return 0}
function sha(t){try{return crypto.subtle.digest("SHA-256",new TextEncoder().encode(t)).then(function(b){return Array.prototype.map.call(new Uint8Array(b),function(x){return ("0"+x.toString(16)).slice(-2)}).join("")})}catch(e){return Promise.reject(e)}}
function lockScreen(go){ttl.textContent="Glory";back.hidden=true;gear.hidden=true;app.textContent="";
 var w=el("div","lock"),ic=document.createElement("img"),pw=document.createElement("input"),rl=el("label","rm"),rc=document.createElement("input"),m=el("div","cnt","");
 ic.src=BASE+"icon-192.png";ic.alt="";pw.type="password";pw.placeholder="Password";pw.setAttribute("aria-label","Password");pw.autocomplete="current-password";
 rc.type="checkbox";rc.checked=true;rl.append(rc,document.createTextNode("Ricordami su questo dispositivo"));m.setAttribute("role","alert");m.style.color="var(--dg)";
 function tryIn(){var v=String(pw.value||"").toLowerCase().replace(/\s+/g,"");if(!v){m.textContent="Inserisci la password.";return}
  sha(v).then(function(h){if(h!==PWH){m.textContent="Password errata.";pw.select();return}
   try{(rc.checked?localStorage:sessionStorage).setItem("gla_ok",PWH)}catch(e){}go()},function(){m.textContent="Questo browser non supporta l'accesso: aggiorna Chrome."})}
 pw.onkeydown=function(e){if(e.key==="Enter")tryIn()};
 w.append(ic,el("h2",0,"Glory 2.0"),el("p","cnt","Strumento interno: inserisci la password per entrare."),pw,rl,btn("reset ac tight","Entra",tryIn),m);
 app.append(w);setTimeout(function(){try{pw.focus()}catch(e){}},50)}
var started=0;
var SHP=null;
/* file arrivato con "Condividi" › Glory (WhatsApp, email, File…) */
function shareIn(){if(!window.caches)return;
 caches.open("glory-share").then(function(c){return c.match("pending").then(function(rs){if(!rs)return;
  return rs.text().then(function(t){c.delete("pending");var r=bkRead(t);
   if(!r){bkMsg="Il file condiviso non è una scheda Glory: usa un file «Scheda Glory» o un backup.";location.hash="";route();return}
   if(r.all){SHP=r;bkMsg="Backup ricevuto: confermi il caricamento qui sotto.";if(location.hash){location.hash=""}else route();return}
   var v=r.it[0].v;
   if(hasData(load(v))){SHP=r;if(location.hash==="#"+v)route();else location.hash="#"+v}
   else bkApply(r)})})}).catch(function(){})}
function startApp(){if(started)return;started=1;try{if(location.search)history.replaceState(null,"",location.pathname+location.hash)}catch(e){}route();shareIn();if(navigator.onLine)setTimeout(function(){updCheck(0)},1500)}
window.removeEventListener("hashchange",route);
window.addEventListener("hashchange",function(){if(started)route()});
phInit(function(){if(okGet())startApp();else lockScreen(startApp)});

/* ---------- funzionamento offline ---------- */
if("serviceWorker" in navigator&&location.protocol==="https:"&&!CL){window.addEventListener("load",function(){navigator.serviceWorker.register(BASE+"sw.js",{scope:BASE||"./"}).catch(function(){})})}
